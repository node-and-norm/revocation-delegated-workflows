# Package validation

Checked 31 October 2026. This validates the documentation package, not the scientific truth of its contents or application-level behavior.

## Workbook

The editable workbook was authored with artifact-tool. Its five worksheets were inspected and rendered for visual review; source-backed IDs, dates, values, native tables, dropdowns, freeze panes and status formatting were checked. A final formula-error scan and saved-XLSX reinspection were performed. The record has no research-result calculations or scoring. See the separately retained authoring validation if a future edit needs detailed comparison.

This package has not been opened in desktop Excel or Obsidian. File validation and render review do not establish every native-application interaction or automatic synchronization.

## Shared record and portability

- 16 trace records, 6 artifact records, 12 disclosure rules, 9 open questions and 6 source references have unique study-specific RV identifiers.
- JSON schemas and CSV row/field values reconcile. Markdown decision entries are generated from the same trace rows.
- Every local Markdown link and Canvas file target resolves inside this notebook. No absolute workspace path is a notebook link.
- The Canvas has unique node/edge IDs and valid edge references. It is an optional navigation view, not a separate research dataset.
- The workbook in Attachments is byte-identical to the separately delivered workbook. Specification and qualification ZIP attachments are byte-identical to their verified originals.
- The notebook contains ordinary Markdown, a Canvas file, JSON/CSV exports and attachments. No notebook automation, Obsidian configuration, plugins or real credentials are supplied. Attached qualification ZIPs intentionally preserve the research source and test scripts.
- SHA256SUMS covers every notebook file except itself. The enclosing ZIP is separately hashed after creation and passes ZIP integrity checks.

## Prior-record preservation

The earlier approval-study workbook, structured JSON and portable notebook ZIP were inspected read-only and match their pre-task hashes. This does not claim inspection or reconciliation of the existing Mac vault. Frozen qualification v0.1 also retains its original ZIP bytes. The new v0.2 artifact is separate.

| Preserved file | SHA-256 |
| --- | --- |
| AI_Use_and_Research_Decision_Traceability_v0.10.xlsx | `2fd41c25c4f8962d1b0a4db2c9aeb477773decbf034c8e65ff54eba08e39c0a5` |
| traceability_content_v010.json | `712e8a05c36d5f293b0a5bff74996a894ece42e19b5a0ab59cbb6d292eeacacb` |
| research-decision-obsidian-vault-v0.1.zip | `c56d40f24370ddbf97ad98032dea3bfc6c8f02608c38b70e206823559c7c02c7` |
| qualification_revocation_v01.zip | `ce289cb5b8a4402fd08c6db25b00fc41866f9f8e0637730c1757e706f1c09d66` |

## Scope of research-evidence checks

For this documentation snapshot, the specification and both qualification READMEs, summaries and final review reports were inspected. Original qualification execution was not repeated merely to package the notebook. v0.2 completion is based on final attempt04 and separate AI reviewer replay03, not on an earlier pending run. The record preserves both versions' checker corrections and does not combine their counts into research samples.

The literature notes retain the specification's pinned references and reading status; they are not a newly conducted literature review. Hashes establish byte identity, not correctness, authorship, independent human validation or authenticated event time.
