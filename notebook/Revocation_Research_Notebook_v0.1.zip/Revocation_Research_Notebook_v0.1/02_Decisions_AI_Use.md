# Decisions and substantive AI use

These entries are generated from the same [structured JSON](Records/revocation_traceability_content_v01.json) as the Excel DecisionTrace. Exact quotations and paraphrases are labeled. Event dates retain their available precision. They are selected observable decisions, not a complete transcript or internal AI reasoning.

## RV-TR-001

**Event UTC:** 2026-10-31 17:47:19 UTC

**Record type:** Retrospective

**Human reference and request:** 2026-10-31 17:47:19 UTC; Sentinel_629e8490cf8481918441fc96624d67a3

Exact quote: “Let's go with one shared research program with the three questions tested in sequence.”

**AI contribution:** Focused the shared frontier-AI assurance program on the first question: whether withdrawing permission prevents a new protected commit in one delegated workflow.

**Decision and brief reason:** Keep only Q1 active. Evidence veracity (Q2) and oversight scaling (Q3) are deferred; AGI readiness is long-term motivation, not an outcome.

**Source / response reference:** 2026-10-31 17:47:19 UTC; Sentinel_629e8490cf8481918441fc96624d67a3; RV-A-001, page 1

**Affected artifact / section:** RV-A-001 v0.1: program and question

**Checks actually recorded:** The preserved specification states the single active question and exclusions.

**Reported or unverified checks:** No evidence-veracity, oversight-scaling or AGI-readiness result is established.

**Human status:** Explicit request

**Human evidence / scope:** The user selected sequential questions. This does not validate the resulting method or claims.

**Remaining limits:** No general claim about all AI workflows or AGI readiness.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-002

**Event UTC:** 2026-10-31 17:47:19 UTC

**Record type:** Retrospective

**Human reference and request:** 2026-10-31 17:47:19 UTC; Sentinel_629e8490cf8481918441fc96624d67a3

Exact quote: “let's hone in on one and really get good at it and produce really good findings or discoveries. Yes, really rock-solid quality.”

**AI contribution:** Treated measurement validity, failure preservation and bounded claims as priorities rather than increasing the number of studies.

**Decision and brief reason:** Prefer a reliable narrow foundation over an unsupported novelty claim.

**Source / response reference:** 2026-10-31 17:47:19 UTC; Sentinel_629e8490cf8481918441fc96624d67a3; 2026-10-31 17:48:56 UTC; Sentinel_540651e0030c8191951994b1ee3a2ff9

**Affected artifact / section:** RV-A-001 and RV-A-002: scope and qualification

**Checks actually recorded:** User-visible quality preference and subsequent instruction to proceed are recorded.

**Reported or unverified checks:** The preference does not establish that any result is novel or independently validated.

**Human status:** Explicit request

**Human evidence / scope:** The user requested depth and quality; at 17:48:56 said, “Let's go ahead and accelerate it, proceed.”

**Remaining limits:** Proceeding does not itself approve model costs, public release or every future research stage.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-003

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** Research framing under RV-TR-001; no separate human factual review recorded.

**AI contribution:** Compared revocation, delegated authorization, cancellation/effect gates and auditability work; rejected adaptivity alone as a differentiator.

**Decision and brief reason:** Novelty remains unestablished. Related work already addresses major proposed mechanisms and adaptive evaluations.

**Source / response reference:** RV-A-001, pages 1 and 6; RV-S-001 through RV-S-005

**Affected artifact / section:** RV-A-001: related work and novelty gate

**Checks actually recorded:** The specification contains versioned primary-source references and scoped comparisons.

**Reported or unverified checks:** These literature summaries are carried forward from the specification; they were not newly re-reviewed for this documentation package.

**Human status:** Not recorded

**Human evidence / scope:** No claim of citation-by-citation human verification.

**Remaining limits:** No new revocation method, upstream vulnerability or uniquely unexplored contrast is established.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-004

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** Continue the focused question; exact human wording for this source inspection is not recorded here.

**AI contribution:** Compared three candidate families for the stronger final sink-commit endpoint; inspected the pinned Stop Means Stop artifact.

**Decision and brief reason:** No verified drop-in candidate for the stronger endpoint. An unchanged admission-boundary artifact can only be a conditional admission-replication candidate.

**Source / response reference:** RV-A-001, page 5; RV-S-006; pin 4bcb42cb52aa46be5714af5d28c516caa5e13e39

**Affected artifact / section:** RV-A-001: Gate 0

**Checks actually recorded:** Recorded source inspection: soundgate releases before the effect callback; native task.cancel / asyncio.to_thread and mediated spawned-thread / gate.cancel paths are unmatched.

**Reported or unverified checks:** No installation or execution of the pinned upstream artifact; no runtime conformance result.

**Human status:** Not recorded

**Human evidence / scope:** No human source-code verification recorded.

**Remaining limits:** Admission is not protected commit. This contract mismatch is not an upstream defect discovery; the pinned snapshot postdates the paper.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-005

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** Prior user direction: focus Q1 and proceed (RV-TR-001 and RV-TR-002).

**AI contribution:** Authored a six-page protocol with an authority contract, finite scenarios, independent observation and decision gates.

**Decision and brief reason:** Freeze the design separately from subsequent narrower qualification. A specification is not evidence that its requirements were implemented.

**Source / response reference:** RV-A-001; document checksum in Artifacts

**Affected artifact / section:** RV-A-001 v0.1: whole specification

**Checks actually recorded:** Documentation preparation re-extracted the document and verified its SHA-256 and byte count.

**Reported or unverified checks:** Original source-review and document-layout checks are not rerun by this ledger.

**Human status:** Not recorded

**Human evidence / scope:** No exhaustive human review of the final specification recorded.

**Remaining limits:** The document itself authorizes no model call, installation, repository edit or publication; later executed qualification has a separate narrower scope.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-006

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** Research continuation within the bounded foundation; specific qualifying-run authorization wording is not reproduced here.

**AI contribution:** Built a model-free SQLite transaction and evidence-oracle fixture rather than silently substituting admission for final commit.

**Decision and brief reason:** Use deterministic measurement qualification to test the instrument before considering an agent-system experiment.

**Source / response reference:** RV-A-002: README.md and qualification_summary.json

**Affected artifact / section:** RV-A-002 v0.1: harness, oracle and fixture contract

**Checks actually recorded:** The frozen package records five schedules in two arms, with separate attempt, effect, revocation and acknowledgement events.

**Reported or unverified checks:** No upstream system or adaptive agent is evaluated.

**Human status:** Not recorded

**Human evidence / scope:** No inference of human methods validation from permission to continue.

**Remaining limits:** C2 is controller-mediated process handoff, not actual delegation. Trusted workers contain the gate and can write the database.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-007

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** No separate human approval of individual results recorded.

**AI contribution:** Executed the initial fixture and unit suite; retained the original source and outputs. A cleanup-only revision followed.

**Decision and brief reason:** Keep attempts 01 and 02 as historical evidence, without retroactively crediting them with later checks.

**Source / response reference:** RV-A-002: runs/attempt01, runs/attempt02, qualification_summary.json

**Affected artifact / section:** RV-A-002: preserved attempt history

**Checks actually recorded:** Each early attempt met 10 fixture expectations and 13 then-existing tests. Attempt02 changed defensive process cleanup only.

**Reported or unverified checks:** The initial tests missed four oracle false-pass classes found later.

**Human status:** Not recorded

**Human evidence / scope:** No human result verification recorded.

**Remaining limits:** A then-passing test suite did not establish oracle adequacy; early artifacts remain unchanged.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-008

**Event UTC:** 2026-10-31

**Record type:** Correction

**Human reference and request:** Quality priority recorded in RV-TR-002.

**AI contribution:** Separate AI-assisted review preserved four false-pass counterexamples: duplicate without prior effect, unmatched attempt 999, wrong prepared binding and boolean sequence number.

**Decision and brief reason:** Treat these as oracle defects requiring repair, not as failures of the transaction enforcement gate.

**Source / response reference:** RV-A-002: independent_review/REVIEW.md and counterexamples01.json

**Affected artifact / section:** RV-A-002: oracle.py; initial review evidence

**Checks actually recorded:** The final review identifies the four accepted malformed traces and the affected evidence checks.

**Reported or unverified checks:** Separate AI review is not independent human validation.

**Human status:** Not recorded

**Human evidence / scope:** No claim that Mark personally reproduced the counterexamples.

**Remaining limits:** The review is finite; discovering these defects does not show exhaustive corruption detection.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-009

**Event UTC:** 2026-10-31

**Record type:** Correction

**Human reference and request:** Continuation of the recorded quality and foundation request.

**AI contribution:** Added strict schema/types, outcome/attempt coverage, preparation binding, duplicate provenance and retry-order checks; preserved attempts 01/02 and ran corrected attempt03.

**Decision and brief reason:** Complete only the stated v0.1 finite instrument qualification after correction verification.

**Source / response reference:** RV-A-002: qualification_summary.json; independent_review/REVIEW.md; corrected replay and checks

**Affected artifact / section:** RV-A-002 v0.1: final attempt03

**Checks actually recorded:** 18 unit tests; 10 arm-by-schedule fixtures; 74 reviewer oracle correction/deletion assertions; 36 direct-database/observer assertions. All stated final checks passed.

**Reported or unverified checks:** These overlapping engineering checks are not independent research samples, statistical estimates or human validation.

**Human status:** Not recorded

**Human evidence / scope:** No exhaustive human verification or publication approval recorded.

**Remaining limits:** The admission-only arm is an intentionally seeded stale-authority race. The result is neither an upstream vulnerability nor a new mechanism.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-010

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** Foundation focus; no claim expansion requested.

**AI contribution:** Separated attempted actions, actual committed effects and late acknowledgements; retained liveness and intentional positive-violation controls.

**Decision and brief reason:** A commit before the durable fence is permitted even when acknowledged later. An incomplete observation cannot count as a safe stop.

**Source / response reference:** RV-A-001, pages 2–4; RV-A-002: README.md and final results

**Affected artifact / section:** RV-A-001/RV-A-002: endpoint and result interpretation

**Checks actually recorded:** Admission-only C1/C2/C3 produced seeded post-fence effects; commit-fenced produced none there. Both arms produced one legitimate effect in C0/C4.

**Reported or unverified checks:** No exhaustive interleavings, crash durability, remote effects or adversarial confinement were tested.

**Human status:** Not recorded

**Human evidence / scope:** No human endpoint validation recorded.

**Remaining limits:** C3 is three attempts of one logical effect, not three independent samples. Trusted SQLite ordering is the measured boundary.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-011

**Event UTC:** 2026-10-31 18:40:34 UTC

**Record type:** Contemporaneous

**Human reference and request:** 2026-10-31 18:40:34 UTC; Sentinel_70e4082931ec819184a2f584ae1227ed

Exact quote: “Let's continue where we left off”. Paraphrase: asks for a solid foundation for the established revocation and delegated-workflows study.

**AI contribution:** Scoped v0.2 to model-free one-edge protocol delegation, gateway-owned writes, server-bound IPC identity and a separate observer.

**Decision and brief reason:** Address v0.1 topology and code-path mediation limits without rewriting the frozen v0.1 evidence.

**Source / response reference:** RV-A-003: PROTOCOL.md; 2026-10-31 18:40:34 UTC; Sentinel_70e4082931ec819184a2f584ae1227ed

**Affected artifact / section:** RV-A-003 v0.2: bounded qualification protocol

**Checks actually recorded:** Protocol specifies parent-requested child-specific grants, child-bound channel identity and atomic current-epoch check plus commit in the fenced arm.

**Reported or unverified checks:** Implementation, execution and review were pending at initial capture; see RV-TR-012 for the final snapshot state.

**Human status:** Explicit request

**Human evidence / scope:** The user requested continuation and a solid foundation; dictation is paraphrased, not silently presented as an exact corrected quote.

**Remaining limits:** Same-OS-user accessible filesystem is not malicious-process confinement. No model, actual user data, remote sink or broader hierarchy.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-012

**Event UTC:** 2026-10-31

**Record type:** Contemporaneous

**Human reference and request:** Continuation of RV-TR-011; no new human validation recorded.

**AI contribution:** Implemented and qualified a model-free one-edge parent-to-child protocol grant, gateway-owned writes, server-bound IPC identities and a separate read-only observer; corrected three causal-treatment checker weaknesses after separate AI review.

**Decision and brief reason:** Complete only the declared v0.2 finite instrument qualification on final attempt04. Keep its source/results/review separate from frozen v0.1 and any future agent experiment.

**Source / response reference:** RV-A-003: qualification_summary.json; SCENARIOS.json; runs/attempt04; independent_review/REVIEW.md and replay03. Report SHA-256 1947ae775f7232e1cf3512d0e95fda3d063b8f6c851c9696a431b3978525dea7.

**Affected artifact / section:** RV-A-003 v0.2

**Checks actually recorded:** 18 fixtures (9 schedules × 2 arms); 19 current unit tests; 18 legacy v0.1 tests separately; 349 reviewer semantic/database assertions; 36 actual IPC assertions. Final source cleared by separate AI review. Summary, manifest, review and ZIP hash inspected for this record.

**Reported or unverified checks:** Discovery and direct invocation repeat the same 19 tests, not 38 distinct tests. All engineering counts overlap and are not independent research samples, population estimates or human validation.

**Human status:** Not recorded

**Human evidence / scope:** No human validation of implementation, results or manuscript claims recorded.

**Remaining limits:** One-edge deterministic protocol delegation; gateway-only write code, but same OS user is not hostile-process confinement. Inert SQLite sink, trusted same-host observer, direct delivery as worker evidence. No model, remote service, distributed revocation or novelty claim.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-013

**Event UTC:** 2026-10-31 18:42:01 UTC

**Record type:** Contemporaneous

**Human reference and request:** 2026-10-31 18:42:01 UTC; Sentinel_c9dbc13c82f48191a8e842518c2859d9

Exact quote: “I'm assuming that you're keeping all of this documented in the background so that we can update the GitHub repository or whatever it is that we need to create to showcase this work.” Paraphrase: the existing Excel and Obsidian records belonged to the old study; asks what to do for the new one.

**AI contribution:** Created a new study-specific ledger and portable Markdown notebook using the established traceability conventions.

**Decision and brief reason:** Give the revocation study its own identity. Cross-reference prior approval work rather than relabeling its results or altering its records.

**Source / response reference:** 2026-10-31 18:42:01 UTC; Sentinel_c9dbc13c82f48191a8e842518c2859d9; RV-A-004 through RV-A-006

**Affected artifact / section:** RV-A-004/RV-A-005/RV-A-006: new research record

**Checks actually recorded:** Prior approval workbook, JSON and notebook hashes captured read-only for a before/after preservation check.

**Reported or unverified checks:** No automatic chat capture, synchronization, local Obsidian installation or Mac update is established.

**Human status:** Explicit request

**Human evidence / scope:** The user requested documentation continuity for the new study; not a claim that all background work is already published.

**Remaining limits:** Selected decision record, not a complete transcript or immutable audit. Private identifiers require review before release.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-014

**Event UTC:** 2026-10-31

**Record type:** Contemporaneous

**Human reference and request:** Repository/showcase question in RV-TR-013.

**AI contribution:** Prepared a proposed private-first repository layout and documentation/claim checklist without creating or changing a repository.

**Decision and brief reason:** Distinguish current verified artifacts from a proposed future canonical GitHub repository. No repository URL is invented.

**Source / response reference:** 2026-10-31 18:42:01 UTC; Sentinel_c9dbc13c82f48191a8e842518c2859d9; GitHub proposal note in RV-A-006

**Affected artifact / section:** RV-A-006: GitHub structure proposal

**Checks actually recorded:** The package contains a proposal only. Current evidence is the versioned specification and qualification packages.

**Reported or unverified checks:** No new-study repository creation, push, public publication or public-safety claim has occurred.

**Human status:** Not recorded

**Human evidence / scope:** No separate repository-creation or publication approval recorded.

**Remaining limits:** Public-safe summary: Research in development; deterministic measurement qualification only; no agent-system evaluation or novelty established.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-015

**Event UTC:** 2026-10-31

**Record type:** Contemporaneous

**Human reference and request:** Documentation request in RV-TR-013.

**AI contribution:** Generated workbook and notebook views from the same structured trace record; included canonical artifact copies and inspectable JSON/CSV exports.

**Decision and brief reason:** Keep one coherent record. The notebook workbook attachment is the same file bytes, not a second independently maintained dataset.

**Source / response reference:** RV-A-005: shared structured record; QA.md and SHA256SUMS accompanying RV-A-006

**Affected artifact / section:** RV-A-004/RV-A-005/RV-A-006

**Checks actually recorded:** Final artifact QA is recorded in QA.md: IDs, row counts, links, hashes, workbook renders and frozen-record preservation.

**Reported or unverified checks:** The package has not been opened in desktop Excel or Obsidian; no app-level synchronization is claimed.

**Human status:** Not recorded

**Human evidence / scope:** No human review or release approval of these new documentation artifacts recorded.

**Remaining limits:** Edits in Excel and Markdown do not automatically reconcile. Preserve snapshots and intentionally update the shared source before a new export.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-016

**Event UTC:** 2026-10-31

**Record type:** Correction

**Human reference and request:** Quality and foundation requests recorded in RV-TR-002 and RV-TR-011.

**AI contribution:** Separate AI review found three v0.2 causal-treatment false qualifications despite zero effects: wrong denial cause, no issued child grant, and no successful preparation/admission.

**Decision and brief reason:** Zero effects alone do not prove that revocation caused a stop. Require the declared grant, admission and denial-cause dependencies before qualifying a treatment.

**Source / response reference:** RV-A-003: independent_review/counterexamples01.json; independent_review/REVIEW.md; qualification_summary.json attempt history.

**Affected artifact / section:** RV-A-003 v0.2: oracle and causal-treatment validation

**Checks actually recorded:** Three preserved examples are now nonqualified: wrong denial cause retains the observational no-effect endpoint but fails treatment qualification; missing grant and missing admission are INVALID. Final 19 tests and 18 fixtures passed. Reviewer checks include three regressions within 349 assertions.

**Reported or unverified checks:** No enforcement bypass was found by these counterexamples. An initially passing suite did not establish causal-treatment validity.

**Human status:** Not recorded

**Human evidence / scope:** No human reproduction or validation of these findings recorded.

**Remaining limits:** Attempts01/02 retain the original weakness; attempt03 corrects dependencies and treatment checks; attempt04 fixes test-runner placement so direct execution includes all 19 tests. Three v0.2 classes are separate from four v0.1 oracle defects, not seven research samples.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31
