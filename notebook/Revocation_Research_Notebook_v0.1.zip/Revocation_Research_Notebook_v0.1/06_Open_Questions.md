# Open questions and next gates

These match the editable OpenQuestions worksheet and [CSV](Records/open_questions.csv). No decorative scores or automatic completion claims are used.

## RV-Q-001 — Decision-relevant contribution

**Status:** Open

**Question / outcome:** What specific implementation boundary or assurance decision remains unmeasured after the closest prior work?

**Evidence / dependency:** RV-A-001 Gate 0; RV-S-001/RV-S-002/RV-S-003

**Next gate / action:** State the decision and comparison before claiming a new study contribution.

**Boundary:** Novelty is not established.

## RV-Q-002 — v0.2 instrument qualification

**Status:** Completed within scope

**Question / outcome:** Completed the declared one-edge delegated gateway fixture: final results match the scenario manifest and separate AI review found no remaining blocker for that finite scope.

**Evidence / dependency:** RV-A-003; RV-TR-012

**Next gate / action:** Preserve the qualified package; use RV-Q-003 onward for remaining research gates.

**Boundary:** Completion applies only to the finite model-free fixture.

## RV-Q-003 — Confinement and trust

**Status:** Open

**Question / outcome:** Is assumed worker code-path mediation sufficient for the next question, or is a separately confined boundary necessary?

**Evidence / dependency:** RV-A-002 limits; RV-A-003 protocol

**Next gate / action:** Choose an explicit threat model before extending beyond trusted same-host workers.

**Boundary:** Same OS user is not malicious-process confinement.

## RV-Q-004 — Model-phase justification

**Status:** Deferred

**Question / outcome:** Could a model phase answer anything not already forced to zero by a correct complete mediator?

**Evidence / dependency:** RV-A-001 Gate 2

**Next gate / action:** Define an informative question or stop; do not substitute denied attempts for realized effects.

**Boundary:** No adaptive-agent experiment has run.

## RV-Q-005 — Human review

**Status:** Open

**Question / outcome:** Which claims, source comparisons, method definitions and artifacts has Mark personally checked?

**Evidence / dependency:** DecisionTrace human-status and evidence columns

**Next gate / action:** Record claim-level review and remaining reservations.

**Boundary:** No exhaustive human validation inferred.

## RV-Q-006 — Repository and release

**Status:** Awaiting authorization

**Question / outcome:** Should a separate private study repository be created, and which redacted materials may later be public?

**Evidence / dependency:** GitHub structure proposal; RV-TR-014

**Next gate / action:** Obtain specific authorization; then check repository content and links before release.

**Boundary:** No new repository URL or publication exists.

## RV-Q-007 — Notebook maintenance

**Status:** Open

**Question / outcome:** Which copy is the next working source after Mark edits the workbook or Markdown?

**Evidence / dependency:** RV-A-005; maintenance rules

**Next gate / action:** Inspect user edits, reconcile into the structured source and save a new version.

**Boundary:** No automatic Excel–Obsidian–GitHub synchronization.

## RV-Q-008 — Q2 evidence veracity

**Status:** Deferred

**Question / outcome:** When should evidence truth and authenticity become an active research question?

**Evidence / dependency:** RV-TR-001; RV-A-001 page 1

**Next gate / action:** Revisit only after the Q1 decision gate, not as an implicit extension.

**Boundary:** The observer is not independently authenticated or host-tamper-proof.

## RV-Q-009 — Q3 oversight scaling

**Status:** Deferred

**Question / outcome:** When should scaling of human oversight become an active research question?

**Evidence / dependency:** RV-TR-001; RV-A-001 page 1

**Next gate / action:** Revisit only after the preceding questions and an explicit study design.

**Boundary:** No human-benefit or oversight-scaling outcome measured.
