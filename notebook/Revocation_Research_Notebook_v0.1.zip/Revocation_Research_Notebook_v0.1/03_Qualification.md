# Qualification and corrections

**These are deterministic measurement qualifications, not agent-system evaluations.** Detailed source, fixture outputs, SQLite observations, logs, reviews and checksums live in the linked versioned packages. Counts below are navigational summaries, not a second research dataset or a denominator for statistical claims.

## Qualification v0.1 — frozen

[Canonical v0.1 package](Attachments/qualification_revocation_v01.zip) · RV-A-002 · SHA-256 `ce289cb5b8a4402fd08c6db25b00fc41866f9f8e0637730c1757e706f1c09d66`

Final corrected attempt03 qualified **10 finite arm-by-schedule fixtures** and passed **18 unit tests**. Separate AI-assisted review recorded **74 oracle correction/deletion assertions** and **36 direct-database/observer assertions**. These overlap; they are not independent research samples or human validation.

The intentionally weak admission-only arm produced a seeded post-fence effect in C1/C2/C3. The commit-fenced arm produced none there. Both arms produced the required legitimate effect in C0 and C4. C3 retries are continuations of one logical operation. The positive violation control checks detection; it is not a safety pass.

### Preserved errors and correction history

- **Attempt01:** 13 initial tests and 10 expected fixture results, but four oracle false-pass classes were not covered.
- **Attempt02:** cleanup-only revision; same pre-review oracle limitations.
- **Separate review:** accepted a duplicate without a prior effect, an unmatched attempt 999 outcome, a wrong prepared binding and a boolean sequence number.
- **Attempt03:** corrected schema/types, outcome coverage, preparation binding, duplicate provenance and retry sequence; added regressions and preserved earlier source/results.

These were evidence-oracle defects, not demonstrated transaction-gate failures. Read `qualification_summary.json`, `independent_review/REVIEW.md` and retained counterexamples inside the ZIP for exact evidence. No failed run has been silently relabeled as having passed the later controls.

### v0.1 scope limits

C2 is controller-mediated process handoff, not actual child delegation. Trusted workers contain the enforcement code and have write access to the database. The protected effect is an inert local SQLite row. There is one root, epoch change and logical effect key; no regrant, partial revocation, external service or model call. Same-host observation is neither independently authenticated nor tamper-proof. No exhaustive interleavings, end-to-end crash durability or hostile-process containment is established.

## Qualification v0.2

[Canonical v0.2 package](Attachments/qualification_revocation_v02.zip) · RV-A-003 · SHA-256 `7355be609c634bdf48de8b3582ea4018f2e48ed0a47d421afbb073d24190d386`

**Final finite qualification complete after correction and separate AI-assisted review.** Final attempt04 contains **18 fixtures: nine schedules in two arms**, including ten negative-authority-control fixtures. **19 current tests** and **18 legacy v0.1 tests** passed separately. Reviewer replay reproduced all 18 fixtures and the same 19 tests; **349 semantic/database assertions** and **36 real-IPC assertions** passed. Discovery and direct invocation run the same 19 tests, not 38 distinct tests. These counts overlap and must not be summed into a sample size or accuracy estimate.

Admission-only produced the deliberately seeded post-fence effect in C1/C3; the fenced arm produced none there. Both arms produced legitimate effects in C0/C2. Five authority-negative schedules in both arms rejected for their specified causes. Final manifests reconcile labels, effects and attempt counts. Inspect `qualification_summary.json`, `SCENARIOS.json`, `runs/attempt04` and `independent_review/REVIEW.md` inside the ZIP.

This is actual one-edge protocol delegation: the parent requests a child-specific grant through its own bound channel, the gateway issues it, and the child uses its own channel. It is not an autonomous agent evaluation or malicious-worker containment result.

### v0.2 causal-treatment correction

Separate AI review found three initially accepted qualifications despite no committed effect: **wrong denial cause, no issued child grant, and no successful preparation/admission**. A zero-effect endpoint alone does not establish that revocation caused the stop. These are distinct from the four v0.1 oracle classes and must not be pooled into a research sample count. No enforcement bypass was demonstrated by these counterexamples.

The three retained counterexamples are now nonqualified. Wrong-cause denial still has the observational no-effect endpoint but fails treatment qualification. Missing child-grant and admission dependencies are INVALID. Attempt03 added these dependency and treatment checks; attempt04 moved the test-runner entry point below all classes so direct invocation includes all 19 tests. Attempts01/02, counterexamples and all source snapshots remain preserved. Final reviewer clearance applies to this corrected source only.

### Remaining v0.2 boundary

One protocol-delegation edge is not a broad delegated-agent system. IPC identity is derived from the server channel, not an actor string, but same-OS-user processes and an accessible filesystem do not prove malicious-process confinement. Parent-child delivery evidence is not independently measured by the database observer. A delayed explicit application acknowledgement is not the already-delivered gateway response. There is no LLM/API call, remote effect, population estimate or universal-safety claim.

## Future agent experiment

**Not run.** Qualifying an instrument does not automatically justify or authorize a model phase. See [open questions](06_Open_Questions.md) and [protocol gates](01_Protocol.md).
