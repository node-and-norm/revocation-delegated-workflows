# Protocol and claim boundary

**Active Q1:** Does withdrawing permission prevent a new protected commit in one delegated workflow?

The canonical design is [Testing Revocation in Delegated Workflows v0.1](Attachments/Testing_Revocation_in_Delegated_Workflows_v0.1.docx) (RV-A-001). This note is a navigation summary, not a replacement protocol or authorization to execute every planned stage.

## Authority and endpoint

The design binds one task, root authority, epoch, input hashes, allowed append operation, sink, output schema, logical effect key and bounded delegation depth. Full revocation disables the root and descendants. The durable revocation fence **F** and protected append must share an ordered transaction domain. A new protected append committed after F under the retired authority is the primary violation.

- A proposal, queue insertion, admission, cancellation notice or denied attempt is not a committed effect.
- A pre-fence commit remains permitted even if acknowledged afterward.
- The user request and the installed fence are distinct events.
- Missing or conflicting observations are incomplete/invalid evidence, not a safe stop.
- Remote effects with admission followed by later settlement would require a new contract; the local result does not silently cover them.

## Why the research stayed narrow

The [closest literature](05_Literature.md) already covers cancellation races, delegated revocation, external effect gates and adaptive evaluations. Novelty is not established. The pinned soundgate artifact's gate releases before its effect callback, and its native and mediated worker paths are not a matched final-commit comparison. The unchanged artifact is only a conditional admission-boundary replication candidate, not a verified drop-in implementation of the stronger endpoint. This is a contract mismatch, not an upstream defect discovery.

## Gates

1. **Purpose and fit:** identify a specific decision-relevant boundary not already answered by prior work. A newer model/version number is insufficient.
2. **Instrument qualification:** test causal order, liveness, known violations, malformed/missing evidence, mediation paths and sink inventory; preserve corrections and failures.
3. **Conditional model phase:** proceed only if model behavior can answer something deterministic controls cannot. A correct complete mediator already forces zero realized violations. Do not substitute denied-proposal counts for the primary endpoint after the fact.

Any future model phase needs its own approved exact model/provider, data, cost ceiling and episode budget, plus an informative prespecified estimand. None has run. Q2/Q3 remain deferred.

## Implemented versus planned

The source specification proposes an externally mediated harmless card-summary workflow. [Qualification v0.1](03_Qualification.md) is narrower: an inert SQLite row, controller-mediated handoff and trusted workers with direct write access. v0.2 addresses one-edge protocol delegation and gateway-owned writes under a same-host trusted-code assumption; it still does not establish malicious-worker confinement, full design conformance or an agent-system result.

Traceability: [RV-TR-001 through RV-TR-006](02_Decisions_AI_Use.md), [RV-TR-010 through RV-TR-012](02_Decisions_AI_Use.md).
