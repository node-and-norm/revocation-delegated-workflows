# Maintenance and disclosure

## One coherent history

1. Inspect the latest user-edited workbook and notebook before changing anything.
2. Reconcile substantive changes into the shared JSON using stable RV identifiers.
3. Preserve the prior snapshot and canonical raw/code packages. Append correction reasons and actual checks.
4. Export matching workbook, Markdown and CSV views as a new version.
5. Verify file hashes and all cross-links; replace the current pointer only after those checks.

There is no automatic Excel–Obsidian–GitHub synchronization, background full-conversation capture or local-vault update. This package is private; it has not been approved for release.

## Research disclosure rules

### RV-DR-001 — Substantive AI use

**Recorded guidance or definition:** Disclose source comparison, scope selection, protocol/code/oracle authoring, execution, critique, corrections and documentation—not grammar only.

**Apply to this study:** Use the decision trace to identify substantive contributions.

**Evidence / access qualification:** OpenAI assistant (alfred); exact underlying model version not recorded or verified.

**Checked UTC:** 2026-10-31

**Publication action:** Prepare an honest methods disclosure; human authors remain responsible.

### RV-DR-002 — Human review scope

**Recorded guidance or definition:** A request, permission to proceed, positive feedback, factual verification and release approval are distinct evidence states.

**Apply to this study:** Use Verified specified claims or Approved for release only with explicit scoped evidence.

**Evidence / access qualification:** No independent human validation or release approval of this record is documented.

**Checked UTC:** 2026-10-31

**Publication action:** Record actual human review before reliance or publication.

### RV-DR-003 — No novelty inflation

**Recorded guidance or definition:** Research in development; deterministic measurement qualification only; no agent-system evaluation or novelty established.

**Apply to this study:** Do not turn a seeded stale-authority race or source-contract mismatch into a new method or upstream vulnerability claim.

**Evidence / access qualification:** See RV-A-001 Gate 0 and RV-A-002 review.

**Checked UTC:** 2026-10-31

**Publication action:** Use this bounded summary in a future reviewed public description.

### RV-DR-004 — Primary endpoint

**Recorded guidance or definition:** Measure a new protected commit after the durable revocation fence. A denied proposal or late acknowledgement is not that endpoint.

**Apply to this study:** Preserve attempt, admission, effect and acknowledgement distinctions.

**Evidence / access qualification:** The local SQLite transaction domain is narrower than remote admission/settlement.

**Checked UTC:** 2026-10-31

**Publication action:** Require a protocol amendment before changing the endpoint or adapter.

### RV-DR-005 — Counts and denominators

**Recorded guidance or definition:** Fixture, unit-test, mutation and direct-database assertions overlap and are engineering checks, not independent research samples.

**Apply to this study:** Do not pool counts across arms, versions or prior approval studies into an accuracy estimate.

**Evidence / access qualification:** C3 retries share one logical effect. No population or power claim.

**Checked UTC:** 2026-10-31

**Publication action:** Label each count by its actual unit and scope.

### RV-DR-006 — Version and failure preservation

**Recorded guidance or definition:** Retain original source, failures, counterexamples, corrections and regression evidence.

**Apply to this study:** Keep v0.1 attempts 01–03 frozen; keep v0.2 separate.

**Evidence / access qualification:** Earlier passing tests are not retroactively credited with later controls.

**Checked UTC:** 2026-10-31

**Publication action:** Append corrections with stable IDs and affected versions.

### RV-DR-007 — Incomplete observations

**Recorded guidance or definition:** Missing evidence, failed controls, timeouts or observer errors do not establish a safe stop.

**Apply to this study:** Retain failure status and causal evidence; do not remove failed assignments from interpretation.

**Evidence / access qualification:** A qualified positive-violation control is detector validation, not a safety pass.

**Checked UTC:** 2026-10-31

**Publication action:** Stop and diagnose unexpected protected effects before expansion.

### RV-DR-008 — Publication and private data

**Recorded guidance or definition:** The working record is private and selected. No public publication or repository creation is implied.

**Apply to this study:** Review private message/Library identifiers and artifact content before any public extract.

**Evidence / access qualification:** No target venue selected; current venue policy must be checked at submission time.

**Checked UTC:** 2026-10-31

**Publication action:** Get explicit release authorization and prepare a separate redacted copy.

### RV-DR-009 — Checksum meaning

**Recorded guidance or definition:** A matching SHA-256 identifies checked bytes; it does not prove truth, authorship or authenticated event time.

**Apply to this study:** Use external SHA256SUMS for the self-referential workbook/record/package.

**Evidence / access qualification:** No signing, notarization or tamper-proof audit is claimed.

**Checked UTC:** 2026-10-31

**Publication action:** Keep semantic validation separate from integrity checks.

### RV-DR-010 — One study record

**Recorded guidance or definition:** Workbook and Markdown are views of one shared JSON source, with matching trace IDs.

**Apply to this study:** Reconcile edits deliberately and export a new version; there is no automatic sync.

**Evidence / access qualification:** Notebook attachment is byte-identical to the separately delivered workbook.

**Checked UTC:** 2026-10-31

**Publication action:** Do not maintain competing copies or silently overwrite user edits.

### RV-DR-011 — Prior-work boundary

**Recorded guidance or definition:** Approval Evidence Sufficiency is a different study with its own IDs and evidence.

**Apply to this study:** Cross-reference WC-001, WC-002 and the static export inspection as methods background only.

**Evidence / access qualification:** WC-001 Python model; WC-002 extracted .NET methods; full lifecycle and export restart not run.

**Checked UTC:** 2026-10-31

**Publication action:** Do not relabel prior results as revocation observations.

### RV-DR-012 — Future agent phase

**Recorded guidance or definition:** A later model phase requires a remaining non-tautological question, frozen design, exact model/data/cost/budget approval and valid observation.

**Apply to this study:** No agent experiment follows automatically from deterministic qualification.

**Evidence / access qualification:** Q2/Q3 stay deferred. Same-host fixture evidence does not imply universal mediation or confinement.

**Checked UTC:** 2026-10-31

**Publication action:** Reopen the design gate before any model call or broader experiment.

## Add a future entry

Use the workbook's blank trace template or the JSON schema. Record event time at supported precision, visible human request or an explicitly labeled paraphrase, substantive AI contribution, short decision reason, source locator, affected version, checks actually performed, unverified checks, scoped human status and remaining limits. Do not record internal operational instructions or irrelevant private data.
