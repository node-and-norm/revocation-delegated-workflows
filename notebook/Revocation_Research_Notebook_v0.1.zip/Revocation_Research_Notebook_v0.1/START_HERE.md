---
title: Revocation in Delegated AI Workflows
study_id: RV-2026-01
record_version: v0.1
as_of: 2026-10-31
status: private-working-record
---

# Revocation in Delegated AI Workflows

**Research in development; deterministic measurement qualification only; no agent-system evaluation or novelty established.**

This is Mark Banasihan's separate study record for Q1 of the shared frontier-AI assurance program. It does not rename or replace Approval Evidence Sufficiency. Q2 evidence veracity and Q3 oversight scaling remain deferred; AGI readiness is long-term motivation.

## Start here

- [Study protocol and claim boundary](01_Protocol.md)
- [Decisions and substantive AI use](02_Decisions_AI_Use.md)
- [Qualification status and retained corrections](03_Qualification.md)
- [Artifact registry](04_Artifacts.md) and [literature notes](05_Literature.md)
- [Open questions and next gates](06_Open_Questions.md)
- [Proposed GitHub structure — not an existing repository](07_GitHub_Proposal.md)
- [Maintenance and disclosure rules](08_Maintenance_Disclosure.md)
- [Prior-study cross-reference](09_Prior_Work.md)
- [Research map](Research_Map.canvas)

The [editable Excel workbook](Attachments/Revocation_AI_Use_and_Research_Decision_Traceability_v0.1.xlsx) is a byte-identical convenience copy of the separately delivered workbook. The [structured JSON](Records/revocation_traceability_content_v01.json) supplies both workbook and Markdown views. These are one record, not competing datasets. Raw fixture data, code and detailed results remain in the qualification packages; this notebook does not maintain an independent results table.

## Current stage

| Item | Status |
| --- | --- |
| Specification v0.1 | Preserved design; not a completed experiment |
| Qualification v0.1 | Completed within its narrower trusted transaction/oracle scope; frozen |
| Qualification v0.2 | Completed within the separately reviewed finite model-free scope |
| Future agent-system experiment | Not run; requires a separate informative question and approval |
| New-study GitHub repository | Proposed only; no URL, creation, push or publication |
| Existing local Obsidian vault | Not modified; this is a portable new notebook |

## Open the notebook

Unzip the archive, keep its folder structure intact, and open the `Revocation_Research_Notebook_v0.1` folder as a vault in Obsidian. Open `START_HERE.md`. Every note is ordinary Markdown and can also be read in a text editor. The optional map uses the standard `.canvas` format; no community plugins, scripts, Sync, Publish or supplied configuration are needed.

This package has not been opened in the Obsidian application or desktop Excel. File structure, relative links and workbook renders were checked; see [QA](QA.md). It does not access a Mac or install anything.

**Private and selected:** message and Library identifiers are source locators, not public links. No public release is authorized. Before sharing, review claims, redact private identifiers and obtain explicit release approval. Hashes identify bytes, not truth, authorship or authenticated event time.
