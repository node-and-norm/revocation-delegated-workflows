# Prior work: Approval Evidence Sufficiency

This is a **different study**. Its existing workbook, structured record and notebook were inspected read-only for conventions and left unchanged. The revocation study uses RV-prefixed IDs; it does not continue the earlier TR/A/DR sequences or reuse the old Library identity.

| Prior artifact or checkpoint | What can be carried forward | What cannot be claimed here |
| --- | --- | --- |
| WC-001 | Finite Python model of action-binding evidence; useful binding and uncertainty lessons | Revocation observations, an upstream runtime evaluation or independent samples |
| WC-002 | Extracted .NET verification methods on constructed configuration worlds | Full coordinator lifecycle, a deployed system or delegated revocation behavior |
| 30 October export/retention inspection | Static source findings on selected retained evidence and configuration | An executed restart test or new revocation result |
| AI-use traceability workbook v0.10 | Stable IDs, scoped human-review vocabulary, checks-versus-claims distinction and failure/version history conventions | Automatic approval, a new-study ledger or permission to publish |
| Earlier portable Obsidian notebook | Navigable Markdown decision map and source boundaries | A current synchronized local vault or a revocation notebook |

Prior workbook Library identity: `libfile_f5daadbd9c7081918b6844d6b7013916`, version 10. This is a private locator, not a public URL. The earlier working local-vault history is separate from the read-only portable snapshot inspected here; this task does not claim to have reconciled the local Mac vault.

Preservation checks in [QA](QA.md) identify the exact prior files inspected. The old study's sources, executions and results remain attributable only to their recorded scopes. The new record does not duplicate them as current experimental evidence.
