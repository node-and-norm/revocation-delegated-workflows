# Artifact registry

Current evidence consists of the verified, versioned artifacts below. GitHub is only a proposed future canonical repository. The XLSX, source JSON and ZIP use external checksums to avoid circular self-hashes. Blank values mean not available/not self-embedded, not zero.

## RV-A-001 — Testing Revocation in Delegated Workflows

[Open included artifact](Attachments/Testing_Revocation_in_Delegated_Workflows_v0.1.docx)

**Version:** v0.1

**Format:** DOCX

**Library reference:** libfile_54a59b0a9c3c81919b59a3e3883a0d5b, version 1

**First delivered UTC:** 2026-10-31 18:00:13 UTC

**Delivery message:** Sentinel_3a76e1144c308191bd1548f381e7c19c

**Relevant scope / section:** Six-page research specification; active Q1, endpoint and gates

**Evidence / check status:** SHA-256 and size rechecked during documentation preparation

**SHA-256:** dc0ade776a556befd523d92cc73dda9ea557eb92b3679bb9898366b4b946af69

**Bytes:** 46562

**Remaining limits:** Design, not execution. Linked in Attachments; source-review details are recorded, not re-performed here.

## RV-A-002 — Deterministic Revocation Measurement Qualification

[Open included artifact](Attachments/qualification_revocation_v01.zip)

**Version:** v0.1

**Format:** ZIP

**Library reference:** libfile_f6ade2000eec8191a5a28ec06d48f070, version 0

**First delivered UTC:** 2026-10-31 18:16:19 UTC

**Delivery message:** Sentinel_298317db44f48191a235e837658b8768

**Relevant scope / section:** Frozen attempts 01–03, source, raw results, oracle, review and checksums

**Evidence / check status:** Final bounded qualification complete after four oracle corrections; 10 fixtures and 18 final unit tests

**SHA-256:** ce289cb5b8a4402fd08c6db25b00fc41866f9f8e0637730c1757e706f1c09d66

**Bytes:** 161833

**Remaining limits:** Controller-mediated handoff; trusted worker-writable database. Not actual delegation, external gateway validation or an agent evaluation.

## RV-A-003 — Delegated Gateway Measurement Qualification

[Open included artifact](Attachments/qualification_revocation_v02.zip)

**Version:** v0.2

**Format:** ZIP

**Library reference:** New artifact; Library identity to be assigned at delivery

**First delivered UTC:** Not embedded / not yet available

**Delivery message:** Included with this documentation delivery; no earlier delivery message recorded

**Relevant scope / section:** Model-free one-edge delegation; server-bound IPC identity; gateway-owned database; separate observer

**Evidence / check status:** Final attempt04 qualified and separately AI-reviewed after three causal-treatment corrections. ZIP hash and 508,334-byte size rechecked; detailed manifests and review retained.

**SHA-256:** 7355be609c634bdf48de8b3582ea4018f2e48ed0a47d421afbb073d24190d386

**Bytes:** 508334

**Remaining limits:** One-edge deterministic protocol delegation; gateway-only write code, but same OS user is not hostile-process confinement. Inert SQLite sink, trusted same-host observer, direct delivery as worker evidence. No model, remote service, distributed revocation or novelty claim.

## RV-A-004 — Revocation AI Use and Research Decision Traceability

[Open included artifact](Attachments/Revocation_AI_Use_and_Research_Decision_Traceability_v0.1.xlsx)

**Version:** v0.1

**Format:** XLSX

**Library reference:** New identity; not the old approval-study workbook

**First delivered UTC:** Not embedded / not yet available

**Delivery message:** Prepared for current delivery; no earlier delivery message

**Relevant scope / section:** Editable decision/AI-use ledger, artifacts, disclosure rules and open questions

**Evidence / check status:** Artifact-tool authoring and QA recorded in QA.md; checksum in external SHA256SUMS

**SHA-256:** Not embedded / not yet available

**Bytes:** Not embedded / not yet available

**Remaining limits:** No self-referential checksum inside the workbook. No desktop Excel opening or automatic synchronization claimed.

## RV-A-005 — Revocation structured traceability record

[Open included artifact](Records/revocation_traceability_content_v01.json)

**Version:** v0.1

**Format:** JSON and CSV

**Library reference:** Included in this documentation package

**First delivered UTC:** Not embedded / not yet available

**Delivery message:** Prepared for current delivery; no earlier delivery message

**Relevant scope / section:** Single structured source for workbook and Markdown views

**Evidence / check status:** ID, schema and row-count validation; checksum in external SHA256SUMS

**SHA-256:** Not embedded / not yet available

**Bytes:** Not embedded / not yet available

**Remaining limits:** Editable snapshot, not complete conversation capture or immutable audit. Self-checksum excluded to avoid a circular record.

## RV-A-006 — Revocation research notebook

[Open included artifact](START_HERE.md)

**Version:** v0.1

**Format:** Markdown notebook ZIP

**Library reference:** New identity; not the old approval-study vault

**First delivered UTC:** Not embedded / not yet available

**Delivery message:** Prepared for current delivery; no earlier delivery message

**Relevant scope / section:** Portable Obsidian-compatible notes, canonical artifact copies, shared source and identical workbook copy

**Evidence / check status:** Relative-path and package-integrity checks recorded in QA.md; checksum supplied with delivery

**SHA-256:** Not embedded / not yet available

**Bytes:** Not embedded / not yet available

**Remaining limits:** Not installed in an existing vault or opened in Obsidian. Private; no repository or public publication.
