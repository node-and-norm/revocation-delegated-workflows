# Proposed GitHub structure

**Proposal only. No new-study repository has been created, updated or published, and no repository URL is asserted.** Current verified evidence is the attached specification and qualification packages. A future repository could become the canonical project location only after explicit authorization and verified integration.

## A private-first layout

Suggested name, not an existing repository: `revocation-delegated-workflows`.

```text
README.md
STATUS.md
protocol/
  v0.1/Testing_Revocation_in_Delegated_Workflows_v0.1.docx
qualification/
  v0.1/                     # frozen source, runs, failures, review
  v0.2/                     # separate version; only after final clearance
research-record/
  Revocation_AI_Use_and_Research_Decision_Traceability_v0.1.xlsx
  revocation_traceability_content_v01.json
  csv/
  notebook/                 # Markdown view of the same record
related-work.md
DISCLOSURE.md
CHANGELOG.md
SHA256SUMS
```

Use the package manifests when importing verified artifacts. Retain raw results, failed counterexamples and source snapshots. Do not recreate or hand-transcribe a separate results dataset in the notebook. Retain the old approval-study repository and record identity unchanged; link it as prior work only if the intended audience has access.

## What the first README should say

> Research in development; deterministic measurement qualification only; no agent-system evaluation or novelty established.

State Q1, the protected-commit endpoint, the trusted same-host boundary, version status, finite controls, known corrections and what has not been run. Explain the difference between specification, qualification, replication and any future extension. Identify the actual AI contribution and the lack of independent human validation. A local freeze is not external preregistration.

## Before any repository write

1. Obtain authorization for the destination/account, repository name and private visibility.
2. Confirm the final v0.2 source/results/review and checksum state, or label it pending.
3. Import verified artifacts without changing historical source or failed evidence.
4. Verify relative paths, checksum manifest, readable entry point and reproduction instructions after integration.

## Before a public showcase

Obtain separate explicit release approval; review claims and licenses, remove private message/Library identifiers and unrelated paths, and prepare a redacted release copy. Select a venue, if relevant, and check its current disclosure rules. Do not imply that repository visibility, file integrity or AI review authenticates unobserved events or establishes scientific validity.
