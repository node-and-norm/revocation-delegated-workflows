# Literature and source notes

These notes preserve the relevance and reading status recorded in the [v0.1 specification](Attachments/Testing_Revocation_in_Delegated_Workflows_v0.1.docx). They are not a newly expanded literature review or an assertion of novelty. Primary URLs and exact source versions are retained. No new upstream runtime reproduction was performed while preparing this notebook.

## RV-S-001 — Authorization Revocation for Long-Running AI Agents

**Pinned source:** arXiv:2609.21284v1

[Primary source](https://arxiv.org/html/2609.21284v1)

**Relevance and decision:** Prior work on root-scoped quiescence, cancellation, cuts, sink fencing and restart. Replication is not a new mechanism.

**Reading status:** Full-text sections 3 and 6–8 recorded in RV-A-001. Carried forward; not re-reviewed for this package.

## RV-S-002 — DelegateGuard

**Pinned source:** arXiv:2610.16005v1

[Primary source](https://arxiv.org/html/2610.16005v1)

**Relevance and decision:** Prior work on external mediation, attenuated capabilities and cascading revocation, including adaptive evaluation. Adaptivity alone is not a contribution.

**Reading status:** Full-text sections 2–6 and limits recorded in RV-A-001. Carried forward; not re-reviewed for this package.

## RV-S-003 — Stop Means Stop

**Pinned source:** arXiv:2607.14166v3

[Primary source](https://arxiv.org/pdf/2607.14166v3)

**Relevance and decision:** Closest empirical overlap: model-free framework probes, live-model reachability and an external effect gate.

**Reading status:** Full-text sections 2–5 and 6.4 recorded in RV-A-001. Carried forward; not re-reviewed for this package.

## RV-S-004 — Auditable Agents

**Pinned source:** arXiv:2604.05485v4

[Primary source](https://arxiv.org/html/2604.05485v4)

**Relevance and decision:** Separates execution evidence from accountability claims. This study defers evidence veracity and human accountability.

**Reading status:** Full-text sections 2, 4 and 7 recorded in RV-A-001. Carried forward; not re-reviewed for this package.

## RV-S-005 — Recursive Language Models

**Pinned source:** arXiv:2512.24601v3

[Primary source](https://arxiv.org/html/2512.24601v3)

**Relevance and decision:** Inference-time scaffolding context; recursion does not itself establish self-improvement. Not a measured system in this study.

**Reading status:** Introduction and section 2 recorded in RV-A-001. Carried forward; not re-reviewed for this package.

## RV-S-006 — Stop Means Stop source artifact

**Pinned source:** Commit 4bcb42cb52aa46be5714af5d28c516caa5e13e39

[Primary source](https://github.com/sajjadanwar0/soundgate-paper/tree/4bcb42cb52aa46be5714af5d28c516caa5e13e39)

**Relevance and decision:** Gate 0 conditional fit for admission only. Gate release precedes callback; native/mediated paths unmatched. No upstream defect or drop-in final-commit fit established.

**Reading status:** Read-only inspection of langgraph_probes.py, e2e_langgraph.py and README recorded in RV-A-001. Not executed; snapshot postdates paper.

## Background distinctions

BlueDot curriculum and AI Security Institute context motivated the broader assurance program; they are background, not evaluated interventions or evidence of an AGI-readiness result. The exact curriculum/unit references are not established in this portable record. Recursive Language Models supplies an inference-scaffolding distinction; recursion is not, by itself, recursive self-improvement.

No paper or framework summary here should be treated as citation-by-citation human verification. Review the primary sources before formal publication.
