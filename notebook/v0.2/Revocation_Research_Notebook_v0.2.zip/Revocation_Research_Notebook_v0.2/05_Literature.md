# Literature and source status

The source IDs match the shared JSON and workbook ReadMe. Historical reading status is retained or explicitly updated. These notes do not establish novelty, exact executable replication or citation-by-citation human validation.

## RV-S-001: Authorization Revocation for Long-Running AI Agents

**Version:** arXiv:2609.21284v1

[Primary source](https://arxiv.org/html/2609.21284v1)

**Relevance:** Prior work on root-scoped quiescence, cancellation, cuts, sink fencing and restart. Replication is not a new mechanism.

**Reading status:** Original full-text review recorded in specification v0.1. Selected scope/late-effect passages rechecked 2026-11-03 for the integration comparison; no novelty validation.

## RV-S-002: DelegateGuard

**Version:** arXiv:2610.16005v1

[Primary source](https://arxiv.org/html/2610.16005v1)

**Relevance:** Prior work on external mediation, attenuated capabilities and cascading revocation, including adaptive evaluation. Adaptivity alone is not a contribution.

**Reading status:** Full-text sections 2–6 and limits recorded in RV-A-001. Carried forward; not re-reviewed for this package.

## RV-S-003: Stop Means Stop

**Version:** arXiv:2607.14166v3

[Primary source](https://arxiv.org/pdf/2607.14166v3)

**Relevance:** Closest empirical overlap: model-free framework probes, live-model reachability and an external effect gate.

**Reading status:** Full-text sections 2–5 and 6.4 recorded in RV-A-001. Carried forward; not re-reviewed for this package.

## RV-S-004: Auditable Agents

**Version:** arXiv:2604.05485v4

[Primary source](https://arxiv.org/html/2604.05485v4)

**Relevance:** Separates execution evidence from accountability claims. This study defers evidence veracity and human accountability.

**Reading status:** Full-text sections 2, 4 and 7 recorded in RV-A-001. Carried forward; not re-reviewed for this package.

## RV-S-005: Recursive Language Models

**Version:** arXiv:2512.24601v3

[Primary source](https://arxiv.org/html/2512.24601v3)

**Relevance:** Inference-time scaffolding context; recursion does not itself establish self-improvement. Not a measured system in this study.

**Reading status:** Introduction and section 2 recorded in RV-A-001. Carried forward; not re-reviewed for this package.

## RV-S-006: Stop Means Stop source artifact

**Version:** Commit 4bcb42cb52aa46be5714af5d28c516caa5e13e39

[Primary source](https://github.com/sajjadanwar0/soundgate-paper/tree/4bcb42cb52aa46be5714af5d28c516caa5e13e39)

**Relevance:** Gate 0 conditional fit for admission only. Gate release precedes callback; native/mediated paths unmatched. No upstream defect or drop-in final-commit fit established.

**Reading status:** Read-only inspection of langgraph_probes.py, e2e_langgraph.py and README recorded in RV-A-001. Not executed; snapshot postdates paper.

## RV-S-007: Permission to Retry: A Study of Authorization and Recovery in AI Agent Workflows

**Version:** arXiv:2610.31916v1

[Primary source](https://arxiv.org/html/2610.31916v1)

**Relevance:** Native-host recovery and authority/effect conformance directly overlap. Its admitted-first-delivery contract differs from the local atomic fence; no superiority claim.

**Reading status:** November 1 source review; selected full-text contract/implementation passages rechecked November 3.

## RV-S-008: Revocation Is Not Complete at Receipt

**Version:** arXiv:2610.15991v1

[Primary source](https://arxiv.org/html/2610.15991v1)

**Relevance:** Receipt, enforcement and effect prevention are separate in existing work. Causal controls and evidence auditing are not claimed as this pilot’s inventions.

**Reading status:** Selected abstract/introduction and outcome-contract passages checked November 3; not an executable replication.

## RV-S-009: Official personal-assistant subagents tutorial

**Version:** docs commit 64063c67975bdc79bcb251027cf9016975865671

[Primary source](https://github.com/langchain-ai/docs/blob/64063c67975bdc79bcb251027cf9016975865671/src/oss/langchain/multi-agent/subagents-personal-assistant.mdx)

**Relevance:** Source of supervisor → manage_email → email agent → HITL → send_email path. Synthetic local effects, SQLite persistence and process replacement are documented adaptations.

**Reading status:** Pinned source reviewed November 1; actual tested versions and source evidence belong to the pilot package.

## Scope of the comparison

Permission to Retry already evaluates native-host recovery with authority and effect evidence. Root-Scoped Quiescence covers late actions and sink enforcement. Revocation Is Not Complete at Receipt separates receipt, enforcement and effects. These overlaps support a conformance integration, not an invention claim. A local atomic sink contract is different from admitting a remote request that may settle later. Different contracts cannot support a simple outperformance claim.

BlueDot, AI Security Institute context and Recursive Language Models remain background distinctions, not measured interventions or evidence of AGI readiness.
