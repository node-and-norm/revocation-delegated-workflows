# Protocol and active question

**Q1:** Does withdrawing authority prevent a new protected effect after the durable revocation fence in the tested delegated workflow?

The [original design](Attachments/Testing_Revocation_in_Delegated_Workflows_v0.1.docx) remains RV-A-001 v0.1. The prospective integration protocol is RV-A-010, retained under integration/v0.3/PROTOCOL.md in the [pilot archive](Attachments/revocation_integration_pilot_v03_20261103.zip). These are different version sequences and scopes.

## Integration contract

The pilot uses the actual create_agent supervisor, manage_email tool, email create_agent, HumanInTheLoopMiddleware and synthetic send_email path. Scripted model outputs depend on persisted message history. The upstream-style InMemorySaver baseline is qualified before substituting a top-level SQLite checkpointer and a fresh worker process.

The worker pauses at an actual HITL interrupt and exits gracefully. A newly constructed worker restores the thread/checkpoint and pending action before approval. Trusted controller constants reattach principal, grant, ticket and operation. The checkpoint restores task state, not authoritative permission. The gateway remains alive and authority stays outside checkpoint storage.

Eight fixed cases cross direct-reference/framework path, no prior effect/prior effect, and live/revoked authority. Both paths use the same adapter and unchanged commit-fenced gateway. The optional prior effect is reference setup, not native framework execution. No weaker diagnostic gateway arm was added.

## Measure the effect and the attempted action separately

Independent read-only sink observations and ordered gateway records establish whether an operation committed. A resumed attempt can produce an effect, be denied for revocation, return a duplicate disposition, fail for another reason or remain unresolved. An existing pre-fence effect is different from a new post-fence mutation.

Missing gateway receipt, terminal response, checkpoint evidence or binding agreement is unresolved. Live controls must complete usefully. The historical policy checks revocation before duplicate lookup, so returning a prior result after revocation was not silently introduced.

## Why the scope remains bounded

The [related literature](05_Literature.md) already covers authority/recovery and effect-level revocation distinctions. The November 1 HOLD on claiming a novel study is preserved. Mark’s November 3 approval selected a bounded integration milestone. It did not establish novelty or authorize an expanding model campaign.

The prospective protocol was written on November 3 before measured collection. It was not backdated to the earlier recommendation. This local freeze is not external preregistration.

Gateway restart, arbitrary worker crashes, remote provider effects, hostile-worker isolation and autonomous model behavior are not qualified. A different effect contract or next experiment needs its own justified question and approved scope.
