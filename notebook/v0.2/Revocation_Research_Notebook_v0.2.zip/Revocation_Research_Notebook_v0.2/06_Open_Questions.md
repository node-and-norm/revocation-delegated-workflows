# Open questions and next gates

Statuses are evidence states, not scores. The completed pilot is bounded; unresolved contribution and human-review questions remain visible.

## RV-Q-001: Decision-relevant contribution

**Status:** Contribution HOLD

**Question / outcome:** Direct prior work overlaps the core authority/recovery and effect-level distinction. Is any narrower implementation question left after the approved conformance pilot?

**Evidence / dependency:** RV-A-001 Gate 0; RV-S-001/RV-S-002/RV-S-003

**Next gate / action:** Use the pilot’s actual evidence to decide whether to stop, report conformance, or justify a narrowly scoped extension.

**Boundary:** A framework integration is not a new mechanism or novelty proof.

## RV-Q-002: v0.2 instrument qualification

**Status:** Completed within scope

**Question / outcome:** Completed the declared one-edge delegated gateway fixture: final results match the scenario manifest and separate AI review found no remaining blocker for that finite scope.

**Evidence / dependency:** RV-A-003; RV-TR-012

**Next gate / action:** Preserve the qualified package; use RV-Q-003 onward for remaining research gates.

**Boundary:** Completion applies only to the finite model-free fixture.

## RV-Q-003: Confinement and trust

**Status:** Open

**Question / outcome:** Is assumed worker code-path mediation sufficient for the next question, or is a separately confined boundary necessary?

**Evidence / dependency:** RV-A-002 limits; RV-A-003 protocol

**Next gate / action:** Choose an explicit threat model before extending beyond trusted same-host workers.

**Boundary:** Same OS user is not malicious-process confinement.

## RV-Q-004: Model-phase justification

**Status:** Deferred

**Question / outcome:** Could a model phase answer anything not already forced to zero by a correct complete mediator?

**Evidence / dependency:** RV-A-001 Gate 2

**Next gate / action:** Define an informative question or stop; do not substitute denied attempts for realized effects.

**Boundary:** No adaptive-agent experiment has run.

## RV-Q-005: Human review

**Status:** Open

**Question / outcome:** Which claims, source comparisons, method definitions and artifacts has Mark personally checked?

**Evidence / dependency:** DecisionTrace human-status and evidence columns

**Next gate / action:** Record claim-level review and remaining reservations.

**Boundary:** No exhaustive human validation inferred.

## RV-Q-006: Repository and release

**Status:** Private repository established

**Question / outcome:** Private repository exists; current v0.2 documentation and v0.3 pilot integration await verified upload at this capture.

**Evidence / dependency:** GitHub structure proposal; RV-TR-014

**Next gate / action:** Preserve prior snapshots and verify the final remote tree after approved upload. Public release still needs separate authorization.

**Boundary:** Verified baseline c7eebe8e049d9379da323827d024f08c1c13a1cd; no later commit invented.

## RV-Q-007: Notebook maintenance

**Status:** Maintained

**Question / outcome:** Current Space v0 workbook/notebook matched preserved originals before this update. Current v0.2 exports share one source.

**Evidence / dependency:** RV-A-005; maintenance rules

**Next gate / action:** Reconcile later user edits before appending another version.

**Boundary:** No automatic synchronization. Earlier versions stay in history and the private repository.

## RV-Q-008: Q2 evidence veracity

**Status:** Deferred

**Question / outcome:** When should evidence truth and authenticity become an active research question?

**Evidence / dependency:** RV-TR-001; RV-A-001 page 1

**Next gate / action:** Revisit only after the Q1 decision gate, not as an implicit extension.

**Boundary:** The observer is not independently authenticated or host-tamper-proof.

## RV-Q-009: Q3 oversight scaling

**Status:** Deferred

**Question / outcome:** When should scaling of human oversight become an active research question?

**Evidence / dependency:** RV-TR-001; RV-A-001 page 1

**Next gate / action:** Revisit only after the preceding questions and an explicit study design.

**Boundary:** No human-benefit or oversight-scaling outcome measured.

## RV-Q-010: Bounded integration pilot

**Status:** Completed within scope

**Question / outcome:** Completed: the actual supervisor/subagent HITL path resumed persistent checkpoints in fresh workers, reached the gateway and matched all eight declared outcomes while live controls completed.

**Evidence / dependency:** RV-A-010/RV-A-011; RV-TR-022 through RV-TR-025

**Next gate / action:** Preserve the final evidence and stop at the approved finite scope; evaluate any next question separately.

**Boundary:** No autonomous model, remote-provider contract, hostile confinement or gateway crash-recovery claim.
