---
title: Revocation in Delegated AI Workflows
study_id: RV-2026-01
record_version: v0.2
as_of_utc: 2026-11-03
status: private-working-record
---

# Revocation in Delegated AI Workflows

The bounded synthetic integration pilot passed all eight declared cases after separate AI review. It exercised actual supervisor/subagent approval-resume machinery; no new revocation mechanism, autonomous-model result or AGI-readiness outcome is established.

The approved pilot exercised the actual supervisor/email-subagent approval-resume path using scripted synthetic messages. [Read the result and its limits](10_Integration_Pilot.md). Earlier instrument qualifications and the contribution HOLD remain part of the history.

## Find the evidence

- [Protocol and active question](01_Protocol.md)
- [Decisions and AI use](02_Decisions_AI_Use.md)
- [Frozen v0.1 and v0.2 qualifications](03_Qualification.md)
- [Artifact registry](04_Artifacts.md)
- [Literature and source status](05_Literature.md)
- [Open questions and next gates](06_Open_Questions.md)
- [Private repository status](07_Repository_Status.md)
- [Maintenance and disclosure](08_Maintenance_Disclosure.md)
- [Prior approval-study boundary](09_Prior_Work.md)
- [Integration pilot v0.3](10_Integration_Pilot.md)
- [Optional research map](Research_Map.canvas)

The [current Excel workbook](Attachments/Revocation_AI_Use_and_Research_Decision_Traceability_v0.2.xlsx) is byte-identical to the separately delivered file. [JSON](Records/revocation_traceability_content_v02.json) and the five CSV files are the shared source and inspectable views. Code and raw observations stay in the linked canonical evidence archives, rather than being maintained as another notebook dataset.

## Version guide

- Specification v0.1: broader research design.
- Qualification v0.1: frozen transaction/oracle fixture with controller-mediated handoff.
- Qualification v0.2: frozen one-edge delegated gateway fixture.
- Integration v0.3: completed bounded synthetic framework pilot, with the gateway kept alive during worker replacement.
- Workbook/notebook v0.2: this updated documentation snapshot.

Q1 remains active. Q2 evidence veracity and Q3 oversight scaling stay deferred. No new revocation mechanism, autonomous-model result or AGI-readiness outcome is established.

## Use this notebook

Unzip the archive, keep the folder structure intact, and open the Revocation_Research_Notebook_v0.2 folder as a vault in Obsidian. Start with this note. The files also work as ordinary Markdown in a text editor. No supplied plugins, scripts or Obsidian settings are needed; attached research archives intentionally contain their source and test scripts.

This portable notebook does not update the existing Mac vault. Desktop Excel and Obsidian were not opened. See [QA](QA.md) for rendered workbook and file/link checks. The prior notebook and workbook remain preserved versions.

Private source-message and Space identifiers are locators, not public links. The [repository](https://github.com/node-and-norm/revocation-delegated-workflows) is private. This capture precedes verification of the new pilot/documentation upload; no later commit is invented. Public release requires separate authorization and review.
