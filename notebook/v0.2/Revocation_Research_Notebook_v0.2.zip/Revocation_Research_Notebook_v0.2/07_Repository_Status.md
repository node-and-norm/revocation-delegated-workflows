# Private repository status

The [private revocation repository](https://github.com/node-and-norm/revocation-delegated-workflows) exists. The November 3 baseline check verified main commit c7eebe8e049d9379da323827d024f08c1c13a1cd, with all 44 files matching the prepared November 1 tree. This record precedes verification of the new pilot/documentation upload.

The v0.1 workbook and notebook described a proposed repository because that was true at their capture. Those files are preserved. Current views update the status without changing the historical trace rows.

## Approved update layout

- integration/v0.3: compact pilot code, exact dependency references and reproduction instructions.
- archives: one complete pilot evidence ZIP, retaining raw records, qualifications, failures and review.
- docs/decisions/2026-11-03-bounded-integration-pilot.md: current decision and evidence boundary.
- docs/traceability/v0.2: current workbook, shared JSON and CSV views.
- notebook/v0.2: this portable notebook ZIP.

The earlier qualifications, decision notes and v0.1 records remain unchanged. Root README and integrity manifest can point to the current versions after integration. No later commit ID is asserted here, and the notebook does not automatically synchronize with GitHub.

Private integration is different from public release. No website change, public publication or open-source license grant is included. Public sharing would need a separate review of claims, permissions, source rights and private identifiers.
