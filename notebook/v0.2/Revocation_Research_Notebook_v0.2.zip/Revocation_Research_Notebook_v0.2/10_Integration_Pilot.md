# Integration conformance pilot v0.3

**Completed within the reviewed finite scope:** all eight assigned cases qualified. Four resumed revoked attempts reached the gateway and were denied for revocation, with no new post-fence effects. All four live controls completed: two new authorized effects and two duplicate responses retaining prior effects. All four framework cases restored real persisted checkpoints in fresh worker processes while the gateway stayed alive.

[Open the full canonical evidence archive](Attachments/revocation_integration_pilot_v03_20261103.zip) (RV-A-011). It retains the prospective protocol, exact source/dependencies, baseline and restart qualification, raw measured records and databases, checker, tests, errors and final review. This note is a summary, not a separately maintained results dataset.

## Measured contrast

Each outcome occurred once in the direct reference and once in the native framework path:

- No prior effect, live authority: one authorized effect; resumed attempt disposition effect.
- No prior effect, revoked authority: no effect; resumed attempt denied for revocation.
- Prior effect, live authority: the existing effect remains; resumed attempt returns duplicate without another mutation.
- Prior effect, revoked authority: the legitimate pre-fence effect remains; resumed attempt is denied for revocation.

The checker labels the live/prior operation authorized_effect because there is no revocation fence, while its resumed-attempt disposition is duplicate. The prior effect is setup evidence and is not credited to framework execution. These are eight fixed cases, not independent population samples.

## Preserved qualification errors and corrections

1. Baseline attempt01 executed, but JSON serialization could not encode native Interrupt dataclasses. The dataclass serializer was corrected and the failed attempt retained.
2. Review required worker failure records before assertions, a read-only observer and explicit controller-rebinding disclosure.
3. Two checker false passes accepted malformed delegation scope and admission grant evidence. Complete expected transcript, binding and effect checks were added; original counterexamples remain preserved.
4. A fabricated post-fence mutation lacked newly required controller revocation evidence and returned unresolved. The test fixture was corrected and its failed log retained.
5. Nonempty checkpoint/interrupt provenance, worker binding and tool-request agreement became required before collection.

Final separate AI review independently regraded all eight saved cases and passed the same 18 instrument tests. Actual sink databases matched recorded snapshots, and checkpoint IDs were verified in the durable databases. These reviews and later archive checks do not add measured cases. The archive was also corrected before delivery to include its unchanged historical gateway dependency; extracted-archive tests and saved-case regrading passed.

## What the result establishes

This establishes that the declared control and measurement survived the actual supervisor/subagent persistence and middleware path for this small synthetic comparison. The upstream in-memory baseline was qualified before adding the persistent authority integration. Existing literature already covers the underlying recovery, authority and effect distinctions. The result is useful integration conformance, not a new security mechanism or evidence of superiority over different provider contracts.

## Limits and stop

One deterministic operation on a trusted host. Scripted models do not call a provider or demonstrate autonomous planning. SQLite and graceful worker replacement are explicit adaptations. The gateway remains alive, and trusted constants reattach identity/grant/ticket/operation. No arbitrary crash recovery, gateway restart, remote mail, network partition, hostile-worker confinement, population estimate or general assurance result is claimed. Review is AI-assisted, not independent human validation. Stop at this approved finite pilot.

The comparison and approval are traced in RV-TR-020/RV-TR-021. The protocol was written before measured collection. The November 1 contribution HOLD is preserved; no novelty claim follows from successful integration. Future work requires a specific unanswered question and a separate scope decision.
