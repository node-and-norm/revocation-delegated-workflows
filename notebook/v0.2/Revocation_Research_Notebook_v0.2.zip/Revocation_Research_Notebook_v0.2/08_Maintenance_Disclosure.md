# Maintenance and disclosure

Use one shared JSON source for matching workbook and Markdown views. Inspect current Space files for user edits before each update, append stable RV IDs, preserve failures and old snapshots, then verify current files and links before changing a repository pointer. There is no automatic synchronization or complete background conversation capture.

The following disclosure rules retain their original v0.1 text and dates. Later actual status is recorded in the current ReadMe and decision trace; a historical pending statement is not silently rewritten.

## RV-DR-001: Substantive AI use

**Recorded guidance or definition:** Disclose source comparison, scope selection, protocol/code/oracle authoring, execution, critique, corrections and documentation—not grammar only.

**Apply to this study:** Use the decision trace to identify substantive contributions.

**Evidence / access qualification:** OpenAI assistant (alfred); exact underlying model version not recorded or verified.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Prepare an honest methods disclosure; human authors remain responsible.

## RV-DR-002: Human review scope

**Recorded guidance or definition:** A request, permission to proceed, positive feedback, factual verification and release approval are distinct evidence states.

**Apply to this study:** Use Verified specified claims or Approved for release only with explicit scoped evidence.

**Evidence / access qualification:** No independent human validation or release approval of this record is documented.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Record actual human review before reliance or publication.

## RV-DR-003: No novelty inflation

**Recorded guidance or definition:** Research in development; deterministic measurement qualification only; no agent-system evaluation or novelty established.

**Apply to this study:** Do not turn a seeded stale-authority race or source-contract mismatch into a new method or upstream vulnerability claim.

**Evidence / access qualification:** See RV-A-001 Gate 0 and RV-A-002 review.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Use this bounded summary in a future reviewed public description.

## RV-DR-004: Primary endpoint

**Recorded guidance or definition:** Measure a new protected commit after the durable revocation fence. A denied proposal or late acknowledgement is not that endpoint.

**Apply to this study:** Preserve attempt, admission, effect and acknowledgement distinctions.

**Evidence / access qualification:** The local SQLite transaction domain is narrower than remote admission/settlement.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Require a protocol amendment before changing the endpoint or adapter.

## RV-DR-005: Counts and denominators

**Recorded guidance or definition:** Fixture, unit-test, mutation and direct-database assertions overlap and are engineering checks, not independent research samples.

**Apply to this study:** Do not pool counts across arms, versions or prior approval studies into an accuracy estimate.

**Evidence / access qualification:** C3 retries share one logical effect. No population or power claim.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Label each count by its actual unit and scope.

## RV-DR-006: Version and failure preservation

**Recorded guidance or definition:** Retain original source, failures, counterexamples, corrections and regression evidence.

**Apply to this study:** Keep v0.1 attempts 01–03 frozen; keep v0.2 separate.

**Evidence / access qualification:** Earlier passing tests are not retroactively credited with later controls.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Append corrections with stable IDs and affected versions.

## RV-DR-007: Incomplete observations

**Recorded guidance or definition:** Missing evidence, failed controls, timeouts or observer errors do not establish a safe stop.

**Apply to this study:** Retain failure status and causal evidence; do not remove failed assignments from interpretation.

**Evidence / access qualification:** A qualified positive-violation control is detector validation, not a safety pass.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Stop and diagnose unexpected protected effects before expansion.

## RV-DR-008: Publication and private data

**Recorded guidance or definition:** The working record is private and selected. No public publication or repository creation is implied.

**Apply to this study:** Review private message/Library identifiers and artifact content before any public extract.

**Evidence / access qualification:** No target venue selected; current venue policy must be checked at submission time.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Get explicit release authorization and prepare a separate redacted copy.

## RV-DR-009: Checksum meaning

**Recorded guidance or definition:** A matching SHA-256 identifies checked bytes; it does not prove truth, authorship or authenticated event time.

**Apply to this study:** Use external SHA256SUMS for the self-referential workbook/record/package.

**Evidence / access qualification:** No signing, notarization or tamper-proof audit is claimed.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Keep semantic validation separate from integrity checks.

## RV-DR-010: One study record

**Recorded guidance or definition:** Workbook and Markdown are views of one shared JSON source, with matching trace IDs.

**Apply to this study:** Reconcile edits deliberately and export a new version; there is no automatic sync.

**Evidence / access qualification:** Notebook attachment is byte-identical to the separately delivered workbook.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Do not maintain competing copies or silently overwrite user edits.

## RV-DR-011: Prior-work boundary

**Recorded guidance or definition:** Approval Evidence Sufficiency is a different study with its own IDs and evidence.

**Apply to this study:** Cross-reference WC-001, WC-002 and the static export inspection as methods background only.

**Evidence / access qualification:** WC-001 Python model; WC-002 extracted .NET methods; full lifecycle and export restart not run.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Do not relabel prior results as revocation observations.

## RV-DR-012: Future agent phase

**Recorded guidance or definition:** A later model phase requires a remaining non-tautological question, frozen design, exact model/data/cost/budget approval and valid observation.

**Apply to this study:** No agent experiment follows automatically from deterministic qualification.

**Evidence / access qualification:** Q2/Q3 stay deferred. Same-host fixture evidence does not imply universal mediation or confinement.

**Source URL:** 

**Checked UTC:** 2026-10-31

**Publication action:** Reopen the design gate before any model call or broader experiment.
