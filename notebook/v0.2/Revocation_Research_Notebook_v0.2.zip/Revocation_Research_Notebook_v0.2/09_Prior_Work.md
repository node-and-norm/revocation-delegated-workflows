# Prior approval-study boundary

Approval Evidence Sufficiency remains a separate study. Its workbook, notebook, repository and results were not edited for this pilot. Revocation records use RV identifiers and retain their own version history.

- WC-001 was a finite Python model of action-binding evidence.
- WC-002 exercised extracted .NET verification methods on constructed configurations, rather than the full coordinator lifecycle.
- The October 30 export/retention inspection was static source analysis; restart behavior was not executed.

Those earlier artifacts can inform binding, configuration and uncertainty-handling practices. They are not v0.3 revocation observations or independent samples for this comparison. Existing findings stay attributed to their original scope.

The portable notebook does not inspect or reconcile the current Mac vault. [QA](QA.md) records preservation checks for the relevant frozen files and the v0.1 revocation documentation.
