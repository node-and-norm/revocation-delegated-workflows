# Documentation validation

Checked November 3, 2026. These checks validate the updated documentation and its source alignment. They do not establish independent human validation or expand the pilot's scope.

## Workbook

The five-sheet workbook was updated with artifact-tool. All sheets and relevant detail ranges were rendered and visually reviewed. Native tables, filters, frozen headers/IDs, dropdowns, typed dates and byte counts were checked. Saved-file values reconcile with the shared JSON. There are no study-result formulas, rankings or decorative scores.

The first 16 decision traces, six artifact rows and 12 disclosure rules retain their original values. Later entries append the contribution HOLD, bounded approval, prospective protocol, actual results, instrument corrections and package checks. Current ReadMe, open questions and source-reading status explicitly reflect later evidence.

Desktop Excel and Obsidian were not opened. Rendered and native-file checks do not prove every application interaction or establish automatic synchronization.

## Shared record and portability

- 27 trace entries, 14 artifacts, 12 disclosure rules, 10 open questions and nine source references reconcile between JSON and CSV views.
- Relevant historical rows match the v0.1 JSON exactly. All IDs are unique within their tables.
- The current workbook attachment is byte-identical to the separately delivered file. The specification, earlier qualification archives and final pilot archive are unchanged copies.
- Every local Markdown link and Canvas file target resolves inside this notebook. No absolute workspace path is a notebook link.
- The notebook includes no Obsidian configuration, plugins or automation. The research evidence ZIPs intentionally contain their source and test scripts.
- SHA256SUMS covers all notebook files except itself. The outer ZIP passes archive integrity checks and is separately hashed after creation.

## Evidence basis and limits

The final integration RESULTS.json, protocol-freeze record, independent reviewer JSON, current README, package metadata and canonical dated decision note were inspected. The final archive includes its exact historical gateway dependency, making it runnable after extraction with the declared dependencies. Its 18-test rerun and eight-case regrade are package checks, not additional measured cases.

The pilot has eight fixed measured runs. Four revoked attempts were denied for revocation, four live controls completed with effects/duplicates, and no post-fence effect was observed. All four framework cases restored real checkpoints in fresh workers. The gateway stayed alive, trusted constants rebound identity/grant/ticket/operation, and models were scripted. Separate review is AI-assisted, not human validation.

Current Space workbook and notebook version 0 matched the preserved local v0.1 bytes before updating. No intervening user edits were found. Earlier revocation documentation, qualification archives and the prior approval-study records remain unchanged. This is not a claim to have checked or updated the Mac vault.

## Publication boundary

The existing private repository baseline was verified before this update. This documentation capture precedes verification of the new remote integration. It does not claim a later commit, public release, website change or new license grant. Historical source-message and Space identifiers remain private.

Checksums identify bytes, not truth, authorship, authenticated event time or independent human review.
