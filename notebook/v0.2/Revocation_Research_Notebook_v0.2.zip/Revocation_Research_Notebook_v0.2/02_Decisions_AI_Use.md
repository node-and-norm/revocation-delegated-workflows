# Decisions and AI use

The first 16 trace entries are preserved unchanged from v0.1. Later entries record the private repository, contribution HOLD, approved pilot and actual evidence. These are selected observable decisions, not a complete transcript or internal reasoning. Exact quotations and paraphrases remain labeled.

## RV-TR-001

**Event UTC:** 2026-10-31 17:47:19 UTC

**Record type:** Retrospective

**Human reference and request:** 2026-10-31 17:47:19 UTC; Sentinel_629e8490cf8481918441fc96624d67a3

Exact quote: “Let's go with one shared research program with the three questions tested in sequence.”

**AI contribution:** Focused the shared frontier-AI assurance program on the first question: whether withdrawing permission prevents a new protected commit in one delegated workflow.

**Decision and brief reason:** Keep only Q1 active. Evidence veracity (Q2) and oversight scaling (Q3) are deferred; AGI readiness is long-term motivation, not an outcome.

**Source / response reference:** 2026-10-31 17:47:19 UTC; Sentinel_629e8490cf8481918441fc96624d67a3; RV-A-001, page 1

**Affected artifact / section:** RV-A-001 v0.1: program and question

**Checks actually recorded:** The preserved specification states the single active question and exclusions.

**Reported or unverified checks:** No evidence-veracity, oversight-scaling or AGI-readiness result is established.

**Human status:** Explicit request

**Human evidence / scope:** The user selected sequential questions. This does not validate the resulting method or claims.

**Remaining limits:** No general claim about all AI workflows or AGI readiness.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-002

**Event UTC:** 2026-10-31 17:47:19 UTC

**Record type:** Retrospective

**Human reference and request:** 2026-10-31 17:47:19 UTC; Sentinel_629e8490cf8481918441fc96624d67a3

Exact quote: “let's hone in on one and really get good at it and produce really good findings or discoveries. Yes, really rock-solid quality.”

**AI contribution:** Treated measurement validity, failure preservation and bounded claims as priorities rather than increasing the number of studies.

**Decision and brief reason:** Prefer a reliable narrow foundation over an unsupported novelty claim.

**Source / response reference:** 2026-10-31 17:47:19 UTC; Sentinel_629e8490cf8481918441fc96624d67a3; 2026-10-31 17:48:56 UTC; Sentinel_540651e0030c8191951994b1ee3a2ff9

**Affected artifact / section:** RV-A-001 and RV-A-002: scope and qualification

**Checks actually recorded:** User-visible quality preference and subsequent instruction to proceed are recorded.

**Reported or unverified checks:** The preference does not establish that any result is novel or independently validated.

**Human status:** Explicit request

**Human evidence / scope:** The user requested depth and quality; at 17:48:56 said, “Let's go ahead and accelerate it, proceed.”

**Remaining limits:** Proceeding does not itself approve model costs, public release or every future research stage.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-003

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** Research framing under RV-TR-001; no separate human factual review recorded.

**AI contribution:** Compared revocation, delegated authorization, cancellation/effect gates and auditability work; rejected adaptivity alone as a differentiator.

**Decision and brief reason:** Novelty remains unestablished. Related work already addresses major proposed mechanisms and adaptive evaluations.

**Source / response reference:** RV-A-001, pages 1 and 6; RV-S-001 through RV-S-005

**Affected artifact / section:** RV-A-001: related work and novelty gate

**Checks actually recorded:** The specification contains versioned primary-source references and scoped comparisons.

**Reported or unverified checks:** These literature summaries are carried forward from the specification; they were not newly re-reviewed for this documentation package.

**Human status:** Not recorded

**Human evidence / scope:** No claim of citation-by-citation human verification.

**Remaining limits:** No new revocation method, upstream vulnerability or uniquely unexplored contrast is established.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-004

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** Continue the focused question; exact human wording for this source inspection is not recorded here.

**AI contribution:** Compared three candidate families for the stronger final sink-commit endpoint; inspected the pinned Stop Means Stop artifact.

**Decision and brief reason:** No verified drop-in candidate for the stronger endpoint. An unchanged admission-boundary artifact can only be a conditional admission-replication candidate.

**Source / response reference:** RV-A-001, page 5; RV-S-006; pin 4bcb42cb52aa46be5714af5d28c516caa5e13e39

**Affected artifact / section:** RV-A-001: Gate 0

**Checks actually recorded:** Recorded source inspection: soundgate releases before the effect callback; native task.cancel / asyncio.to_thread and mediated spawned-thread / gate.cancel paths are unmatched.

**Reported or unverified checks:** No installation or execution of the pinned upstream artifact; no runtime conformance result.

**Human status:** Not recorded

**Human evidence / scope:** No human source-code verification recorded.

**Remaining limits:** Admission is not protected commit. This contract mismatch is not an upstream defect discovery; the pinned snapshot postdates the paper.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-005

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** Prior user direction: focus Q1 and proceed (RV-TR-001 and RV-TR-002).

**AI contribution:** Authored a six-page protocol with an authority contract, finite scenarios, independent observation and decision gates.

**Decision and brief reason:** Freeze the design separately from subsequent narrower qualification. A specification is not evidence that its requirements were implemented.

**Source / response reference:** RV-A-001; document checksum in Artifacts

**Affected artifact / section:** RV-A-001 v0.1: whole specification

**Checks actually recorded:** Documentation preparation re-extracted the document and verified its SHA-256 and byte count.

**Reported or unverified checks:** Original source-review and document-layout checks are not rerun by this ledger.

**Human status:** Not recorded

**Human evidence / scope:** No exhaustive human review of the final specification recorded.

**Remaining limits:** The document itself authorizes no model call, installation, repository edit or publication; later executed qualification has a separate narrower scope.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-006

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** Research continuation within the bounded foundation; specific qualifying-run authorization wording is not reproduced here.

**AI contribution:** Built a model-free SQLite transaction and evidence-oracle fixture rather than silently substituting admission for final commit.

**Decision and brief reason:** Use deterministic measurement qualification to test the instrument before considering an agent-system experiment.

**Source / response reference:** RV-A-002: README.md and qualification_summary.json

**Affected artifact / section:** RV-A-002 v0.1: harness, oracle and fixture contract

**Checks actually recorded:** The frozen package records five schedules in two arms, with separate attempt, effect, revocation and acknowledgement events.

**Reported or unverified checks:** No upstream system or adaptive agent is evaluated.

**Human status:** Not recorded

**Human evidence / scope:** No inference of human methods validation from permission to continue.

**Remaining limits:** C2 is controller-mediated process handoff, not actual delegation. Trusted workers contain the gate and can write the database.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-007

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** No separate human approval of individual results recorded.

**AI contribution:** Executed the initial fixture and unit suite; retained the original source and outputs. A cleanup-only revision followed.

**Decision and brief reason:** Keep attempts 01 and 02 as historical evidence, without retroactively crediting them with later checks.

**Source / response reference:** RV-A-002: runs/attempt01, runs/attempt02, qualification_summary.json

**Affected artifact / section:** RV-A-002: preserved attempt history

**Checks actually recorded:** Each early attempt met 10 fixture expectations and 13 then-existing tests. Attempt02 changed defensive process cleanup only.

**Reported or unverified checks:** The initial tests missed four oracle false-pass classes found later.

**Human status:** Not recorded

**Human evidence / scope:** No human result verification recorded.

**Remaining limits:** A then-passing test suite did not establish oracle adequacy; early artifacts remain unchanged.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-008

**Event UTC:** 2026-10-31

**Record type:** Correction

**Human reference and request:** Quality priority recorded in RV-TR-002.

**AI contribution:** Separate AI-assisted review preserved four false-pass counterexamples: duplicate without prior effect, unmatched attempt 999, wrong prepared binding and boolean sequence number.

**Decision and brief reason:** Treat these as oracle defects requiring repair, not as failures of the transaction enforcement gate.

**Source / response reference:** RV-A-002: independent_review/REVIEW.md and counterexamples01.json

**Affected artifact / section:** RV-A-002: oracle.py; initial review evidence

**Checks actually recorded:** The final review identifies the four accepted malformed traces and the affected evidence checks.

**Reported or unverified checks:** Separate AI review is not independent human validation.

**Human status:** Not recorded

**Human evidence / scope:** No claim that Mark personally reproduced the counterexamples.

**Remaining limits:** The review is finite; discovering these defects does not show exhaustive corruption detection.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-009

**Event UTC:** 2026-10-31

**Record type:** Correction

**Human reference and request:** Continuation of the recorded quality and foundation request.

**AI contribution:** Added strict schema/types, outcome/attempt coverage, preparation binding, duplicate provenance and retry-order checks; preserved attempts 01/02 and ran corrected attempt03.

**Decision and brief reason:** Complete only the stated v0.1 finite instrument qualification after correction verification.

**Source / response reference:** RV-A-002: qualification_summary.json; independent_review/REVIEW.md; corrected replay and checks

**Affected artifact / section:** RV-A-002 v0.1: final attempt03

**Checks actually recorded:** 18 unit tests; 10 arm-by-schedule fixtures; 74 reviewer oracle correction/deletion assertions; 36 direct-database/observer assertions. All stated final checks passed.

**Reported or unverified checks:** These overlapping engineering checks are not independent research samples, statistical estimates or human validation.

**Human status:** Not recorded

**Human evidence / scope:** No exhaustive human verification or publication approval recorded.

**Remaining limits:** The admission-only arm is an intentionally seeded stale-authority race. The result is neither an upstream vulnerability nor a new mechanism.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-010

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** Foundation focus; no claim expansion requested.

**AI contribution:** Separated attempted actions, actual committed effects and late acknowledgements; retained liveness and intentional positive-violation controls.

**Decision and brief reason:** A commit before the durable fence is permitted even when acknowledged later. An incomplete observation cannot count as a safe stop.

**Source / response reference:** RV-A-001, pages 2–4; RV-A-002: README.md and final results

**Affected artifact / section:** RV-A-001/RV-A-002: endpoint and result interpretation

**Checks actually recorded:** Admission-only C1/C2/C3 produced seeded post-fence effects; commit-fenced produced none there. Both arms produced one legitimate effect in C0/C4.

**Reported or unverified checks:** No exhaustive interleavings, crash durability, remote effects or adversarial confinement were tested.

**Human status:** Not recorded

**Human evidence / scope:** No human endpoint validation recorded.

**Remaining limits:** C3 is three attempts of one logical effect, not three independent samples. Trusted SQLite ordering is the measured boundary.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-011

**Event UTC:** 2026-10-31 18:40:34 UTC

**Record type:** Contemporaneous

**Human reference and request:** 2026-10-31 18:40:34 UTC; Sentinel_70e4082931ec819184a2f584ae1227ed

Exact quote: “Let's continue where we left off”. Paraphrase: asks for a solid foundation for the established revocation and delegated-workflows study.

**AI contribution:** Scoped v0.2 to model-free one-edge protocol delegation, gateway-owned writes, server-bound IPC identity and a separate observer.

**Decision and brief reason:** Address v0.1 topology and code-path mediation limits without rewriting the frozen v0.1 evidence.

**Source / response reference:** RV-A-003: PROTOCOL.md; 2026-10-31 18:40:34 UTC; Sentinel_70e4082931ec819184a2f584ae1227ed

**Affected artifact / section:** RV-A-003 v0.2: bounded qualification protocol

**Checks actually recorded:** Protocol specifies parent-requested child-specific grants, child-bound channel identity and atomic current-epoch check plus commit in the fenced arm.

**Reported or unverified checks:** Implementation, execution and review were pending at initial capture; see RV-TR-012 for the final snapshot state.

**Human status:** Explicit request

**Human evidence / scope:** The user requested continuation and a solid foundation; dictation is paraphrased, not silently presented as an exact corrected quote.

**Remaining limits:** Same-OS-user accessible filesystem is not malicious-process confinement. No model, actual user data, remote sink or broader hierarchy.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-012

**Event UTC:** 2026-10-31

**Record type:** Contemporaneous

**Human reference and request:** Continuation of RV-TR-011; no new human validation recorded.

**AI contribution:** Implemented and qualified a model-free one-edge parent-to-child protocol grant, gateway-owned writes, server-bound IPC identities and a separate read-only observer; corrected three causal-treatment checker weaknesses after separate AI review.

**Decision and brief reason:** Complete only the declared v0.2 finite instrument qualification on final attempt04. Keep its source/results/review separate from frozen v0.1 and any future agent experiment.

**Source / response reference:** RV-A-003: qualification_summary.json; SCENARIOS.json; runs/attempt04; independent_review/REVIEW.md and replay03. Report SHA-256 1947ae775f7232e1cf3512d0e95fda3d063b8f6c851c9696a431b3978525dea7.

**Affected artifact / section:** RV-A-003 v0.2

**Checks actually recorded:** 18 fixtures (9 schedules × 2 arms); 19 current unit tests; 18 legacy v0.1 tests separately; 349 reviewer semantic/database assertions; 36 actual IPC assertions. Final source cleared by separate AI review. Summary, manifest, review and ZIP hash inspected for this record.

**Reported or unverified checks:** Discovery and direct invocation repeat the same 19 tests, not 38 distinct tests. All engineering counts overlap and are not independent research samples, population estimates or human validation.

**Human status:** Not recorded

**Human evidence / scope:** No human validation of implementation, results or manuscript claims recorded.

**Remaining limits:** One-edge deterministic protocol delegation; gateway-only write code, but same OS user is not hostile-process confinement. Inert SQLite sink, trusted same-host observer, direct delivery as worker evidence. No model, remote service, distributed revocation or novelty claim.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-013

**Event UTC:** 2026-10-31 18:42:01 UTC

**Record type:** Contemporaneous

**Human reference and request:** 2026-10-31 18:42:01 UTC; Sentinel_c9dbc13c82f48191a8e842518c2859d9

Exact quote: “I'm assuming that you're keeping all of this documented in the background so that we can update the GitHub repository or whatever it is that we need to create to showcase this work.” Paraphrase: the existing Excel and Obsidian records belonged to the old study; asks what to do for the new one.

**AI contribution:** Created a new study-specific ledger and portable Markdown notebook using the established traceability conventions.

**Decision and brief reason:** Give the revocation study its own identity. Cross-reference prior approval work rather than relabeling its results or altering its records.

**Source / response reference:** 2026-10-31 18:42:01 UTC; Sentinel_c9dbc13c82f48191a8e842518c2859d9; RV-A-004 through RV-A-006

**Affected artifact / section:** RV-A-004/RV-A-005/RV-A-006: new research record

**Checks actually recorded:** Prior approval workbook, JSON and notebook hashes captured read-only for a before/after preservation check.

**Reported or unverified checks:** No automatic chat capture, synchronization, local Obsidian installation or Mac update is established.

**Human status:** Explicit request

**Human evidence / scope:** The user requested documentation continuity for the new study; not a claim that all background work is already published.

**Remaining limits:** Selected decision record, not a complete transcript or immutable audit. Private identifiers require review before release.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-014

**Event UTC:** 2026-10-31

**Record type:** Contemporaneous

**Human reference and request:** Repository/showcase question in RV-TR-013.

**AI contribution:** Prepared a proposed private-first repository layout and documentation/claim checklist without creating or changing a repository.

**Decision and brief reason:** Distinguish current verified artifacts from a proposed future canonical GitHub repository. No repository URL is invented.

**Source / response reference:** 2026-10-31 18:42:01 UTC; Sentinel_c9dbc13c82f48191a8e842518c2859d9; GitHub proposal note in RV-A-006

**Affected artifact / section:** RV-A-006: GitHub structure proposal

**Checks actually recorded:** The package contains a proposal only. Current evidence is the versioned specification and qualification packages.

**Reported or unverified checks:** No new-study repository creation, push, public publication or public-safety claim has occurred.

**Human status:** Not recorded

**Human evidence / scope:** No separate repository-creation or publication approval recorded.

**Remaining limits:** Public-safe summary: Research in development; deterministic measurement qualification only; no agent-system evaluation or novelty established.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-015

**Event UTC:** 2026-10-31

**Record type:** Contemporaneous

**Human reference and request:** Documentation request in RV-TR-013.

**AI contribution:** Generated workbook and notebook views from the same structured trace record; included canonical artifact copies and inspectable JSON/CSV exports.

**Decision and brief reason:** Keep one coherent record. The notebook workbook attachment is the same file bytes, not a second independently maintained dataset.

**Source / response reference:** RV-A-005: shared structured record; QA.md and SHA256SUMS accompanying RV-A-006

**Affected artifact / section:** RV-A-004/RV-A-005/RV-A-006

**Checks actually recorded:** Final artifact QA is recorded in QA.md: IDs, row counts, links, hashes, workbook renders and frozen-record preservation.

**Reported or unverified checks:** The package has not been opened in desktop Excel or Obsidian; no app-level synchronization is claimed.

**Human status:** Not recorded

**Human evidence / scope:** No human review or release approval of these new documentation artifacts recorded.

**Remaining limits:** Edits in Excel and Markdown do not automatically reconcile. Preserve snapshots and intentionally update the shared source before a new export.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-016

**Event UTC:** 2026-10-31

**Record type:** Correction

**Human reference and request:** Quality and foundation requests recorded in RV-TR-002 and RV-TR-011.

**AI contribution:** Separate AI review found three v0.2 causal-treatment false qualifications despite zero effects: wrong denial cause, no issued child grant, and no successful preparation/admission.

**Decision and brief reason:** Zero effects alone do not prove that revocation caused a stop. Require the declared grant, admission and denial-cause dependencies before qualifying a treatment.

**Source / response reference:** RV-A-003: independent_review/counterexamples01.json; independent_review/REVIEW.md; qualification_summary.json attempt history.

**Affected artifact / section:** RV-A-003 v0.2: oracle and causal-treatment validation

**Checks actually recorded:** Three preserved examples are now nonqualified: wrong denial cause retains the observational no-effect endpoint but fails treatment qualification; missing grant and missing admission are INVALID. Final 19 tests and 18 fixtures passed. Reviewer checks include three regressions within 349 assertions.

**Reported or unverified checks:** No enforcement bypass was found by these counterexamples. An initially passing suite did not establish causal-treatment validity.

**Human status:** Not recorded

**Human evidence / scope:** No human reproduction or validation of these findings recorded.

**Remaining limits:** Attempts01/02 retain the original weakness; attempt03 corrects dependencies and treatment checks; attempt04 fixes test-runner placement so direct execution includes all 19 tests. Three v0.2 classes are separate from four v0.1 oracle defects, not seven research samples.

**Publication handling:** Review before release

**Captured UTC:** 2026-10-31

## RV-TR-017

**Event UTC:** 2026-11-03

**Record type:** Retrospective

**Human reference and request:** Private research upload authorization is recorded in the repository README. The original authorizing message is not reproduced here.

**AI contribution:** Reconciled the previously proposed repository with its later private creation and verified baseline.

**Decision and brief reason:** Record the later repository status without rewriting the October 31 workbook and notebook captures.

**Source / response reference:** https://github.com/node-and-norm/revocation-delegated-workflows; verified main c7eebe8e049d9379da323827d024f08c1c13a1cd

**Affected artifact / section:** Existing v0.1 records and private repository

**Checks actually recorded:** Fresh remote baseline verification on November 3 matched all 44 files to the November 1 prepared tree. Current Space workbook and notebook remain version 0 and match the frozen bytes.

**Reported or unverified checks:** This documentation capture precedes the new pilot upload. A later remote commit is not yet asserted.

**Human status:** Scope authorization

**Human evidence / scope:** The prior README records permission for private research upload; public release remains unapproved.

**Remaining limits:** Repository existence and file integrity do not establish scientific validity. Existing v0.1 proposed-repository wording remains historical.

**Publication handling:** Review before release

**Captured UTC:** 2026-11-03

## RV-TR-018

**Event UTC:** 2026-10-31

**Record type:** Retrospective

**Human reference and request:** Earlier research continuation; exact message not reproduced in this entry.

**AI contribution:** Selected checkpointed LangGraph continuation as a candidate integration and corrected an external-effect atomicity claim in supplied architecture text.

**Decision and brief reason:** A transaction recording intent before a separate HTTP effect does not atomically fence that effect. Choose a documented workflow and preserve the effect boundary.

**Source / response reference:** RV-A-007; official documentation and source URLs retained in that dated note

**Affected artifact / section:** RV-A-007: checkpointed-workflow candidate

**Checks actually recorded:** Read-only documentation/source assessment recorded; no framework installation or run at that stage.

**Reported or unverified checks:** A candidate framework is not a contribution or demonstrated framework defect.

**Human status:** Not recorded

**Human evidence / scope:** No specific human verification of the architecture correction recorded.

**Remaining limits:** Ordinary continuation, process replacement and replay were candidate mechanisms, not completed tests.

**Publication handling:** Review before release

**Captured UTC:** 2026-11-03

## RV-TR-019

**Event UTC:** 2026-11-01

**Record type:** Retrospective

**Human reference and request:** A choice between bounded conformance work and continued search remained pending at this dated capture.

**AI contribution:** Narrowed the candidate to the official personal-assistant email branch and compared checkpoint recovery, current authority and effect scoring with prior work.

**Decision and brief reason:** HOLD on freezing a novel-study protocol. A source-qualified tutorial candidate is not a runtime-qualified or novel contribution.

**Source / response reference:** RV-A-008; Permission to Retry; pinned tutorial and middleware sources

**Affected artifact / section:** RV-A-008: workflow selection and contribution gate

**Checks actually recorded:** The dated source note records tutorial, agent/middleware and graph candidate pins. Original note preserved unchanged.

**Reported or unverified checks:** No framework/model was installed or new experiment run in the November 1 assessment. Abstract screening of other papers was not a full methods review.

**Human status:** Not recorded

**Human evidence / scope:** The note records an AI recommendation, not a human decision to take either route.

**Remaining limits:** The stronger local commit fence differs from prior remote-provider contracts; this does not establish superiority or novelty.

**Publication handling:** Review before release

**Captured UTC:** 2026-11-03

## RV-TR-020

**Event UTC:** 2026-11-03 00:31:03 UTC

**Record type:** Retrospective

**Human reference and request:** The comparison recommendation was communicated to Mark; the exact approving reply is recorded separately in RV-TR-021.

**AI contribution:** Recommended staying with revocation and testing one small reproducible integration through the actual supervisor/subagent path. Dropped a separate attribution-audit direction as insufficiently differentiated.

**Decision and brief reason:** Use bounded integration conformance as the next milestone. Direct prior work already covers authority/recovery and effect-level controls; do not promise discovery.

**Source / response reference:** Sentinel_a3c97254bed08191a90f280c9005f24b; 2026-11-03 00:31:03 UTC (November 2 in the researcher’s local conversation); RV-A-009; RV-S-001, RV-S-007, RV-S-008

**Affected artifact / section:** RV-A-009: comparison and decision summary

**Checks actually recorded:** Compared Permission to Retry, Root-Scoped Quiescence and Revocation Is Not Complete at Receipt. Selected passages and source metadata rechecked during documentation.

**Reported or unverified checks:** Comparison was complete before the new pilot; no new experiment had run at the time of the recommendation.

**Human status:** Not recorded

**Human evidence / scope:** No human approval inferred from delivery of the comparison alone.

**Remaining limits:** A successful integration can validate this application boundary. Unexpected results need diagnosis before any narrower contribution claim.

**Publication handling:** Review before release

**Captured UTC:** 2026-11-03

## RV-TR-021

**Event UTC:** 2026-11-03 00:43:06 UTC

**Record type:** Contemporaneous

**Human reference and request:** Sentinel_7c68a372e02881918450b7b41a6ab05f; 2026-11-03 00:43:06 UTC

Exact quote: “Yes, please go ahead. Thank you, Alfred.”

**AI contribution:** Proposed a bounded synthetic supervisor/subagent pilot, reproducibility evidence and updated AI-use documentation; then proceeded after the user approved.

**Decision and brief reason:** Approval covers the stated bounded pilot with synthetic data and no paid model calls.

**Source / response reference:** Assistant question at 2026-11-03 00:42 UTC: “Shall I proceed with that bounded pilot, using synthetic data and no paid model calls?”; Sentinel_7c68a372e02881918450b7b41a6ab05f; 2026-11-03 00:43:06 UTC

**Affected artifact / section:** RV-A-010/RV-A-011 and updated study documentation

**Checks actually recorded:** The visible approving reply directly follows the bounded proposal.

**Reported or unverified checks:** Approval to run is distinct from factual review, endorsement of later results or approval for public release.

**Human status:** Explicit request

**Human evidence / scope:** The user authorized this specific pilot and the proposed reproducibility/documentation work.

**Remaining limits:** No live email/calendar, website change, Mac access or autonomous model evaluation is in scope.

**Publication handling:** Review before release

**Captured UTC:** 2026-11-03

## RV-TR-022

**Event UTC:** 2026-11-03

**Record type:** Contemporaneous

**Human reference and request:** Bounded-pilot approval in RV-TR-021.

**AI contribution:** Wrote the v0.3 protocol before measured collection, with upstream qualification gates and a fixed eight-case comparison.

**Decision and brief reason:** Test path × prior-effect history × authority state, using the unchanged commit-fenced gateway and independently inspected sink. Keep qualification attempts separate from measured collection.

**Source / response reference:** RV-A-010: integration/v0.3/PROTOCOL.md

**Affected artifact / section:** RV-A-010: prospective protocol

**Checks actually recorded:** Protocol inspected: direct reference/framework fresh-worker path; prior effect absent/present; authority live/revoked. Baseline InMemorySaver precedes the SqliteSaver adaptation.

**Reported or unverified checks:** The protocol date is November 3. It is not backdated to the November 1 contribution HOLD or presented as external preregistration.

**Human status:** Not recorded

**Human evidence / scope:** No separate claim-level human method validation recorded.

**Remaining limits:** Gateway stays alive. Graceful process exit/reconstruction at an interrupt is not arbitrary crash recovery or gateway restart.

**Publication handling:** Review before release

**Captured UTC:** 2026-11-03

## RV-TR-023

**Event UTC:** 2026-11-03

**Record type:** Contemporaneous

**Human reference and request:** Proceed under RV-TR-021.

**AI contribution:** Implemented the actual create_agent supervisor/subagent HITL path with scripted state-derived model messages. Qualified upstream-style InMemorySaver pause/resume before the explicit SqliteSaver and fresh-worker adaptation.

**Decision and brief reason:** The native baseline and durable worker-replacement gates passed before interpreting the eight-case comparison. Keep setup/instrument failures separate from measured results.

**Source / response reference:** RV-A-011: qualification evidence and run history

**Affected artifact / section:** RV-A-011: upstream baseline and restart qualification

**Checks actually recorded:** Successful baseline captures actual interrupt/resume and one recorder effect. Fresh-process qualification restores the same checkpoint and pending interrupt. Exact dependencies, 42 official wheel hashes, license texts and installed-source comparison are retained.

**Reported or unverified checks:** No provider model client or external email/calendar was used. A native framework path exercised with scripted responses is not autonomous-model evaluation.

**Human status:** Not recorded

**Human evidence / scope:** No independent human runtime validation recorded.

**Remaining limits:** SqliteSaver and process replacement are documented tutorial adaptations. Trusted constants reattach principal/grant/ticket/operation outside checkpoint state. The historical gateway remains alive; arbitrary dynamic credential recovery and gateway restart are untested.

**Publication handling:** Review before release

**Captured UTC:** 2026-11-03

## RV-TR-024

**Event UTC:** 2026-11-03

**Record type:** Contemporaneous

**Human reference and request:** Bounded comparison approved in RV-TR-021.

**AI contribution:** Collected the fixed eight-case matrix and scored actual sink effects separately from resumed-attempt dispositions using recorded gateway/checkpoint evidence.

**Decision and brief reason:** The existing local atomic commit-fenced contract conformed in all eight assigned cases. Keep the result scoped to this deterministic integration and its declared trust assumptions.

**Source / response reference:** RV-A-010 protocol; RV-A-011 measured results

**Affected artifact / section:** RV-A-011: measured comparison

**Checks actually recorded:** 8/8 cases qualified: 4 direct references and 4 native framework restarts. Two live/no-prior attempts created one effect each; two live/prior attempts returned duplicates. Four revoked resumed attempts were denied for revocation; two retained a legitimate pre-fence effect. Zero post-fence effects.

**Reported or unverified checks:** Eight fixed cases are not a random sample, failure-rate estimate, universal safety result or comparison of independent security mechanisms.

**Human status:** Not recorded

**Human evidence / scope:** No human verification of measured results recorded.

**Remaining limits:** All four framework cases had distinct initial/resumed worker PIDs and actual persisted checkpoint IDs. The initial historical effect is reference setup, not credited as framework execution. Gateway policy and source remain unchanged.

**Publication handling:** Review before release

**Captured UTC:** 2026-11-03

## RV-TR-025

**Event UTC:** 2026-11-03

**Record type:** Correction

**Human reference and request:** Quality focus and bounded-pilot approval; no separate approval of individual fixes inferred.

**AI contribution:** Separate AI review found two checker false passes before measured collection and required complete transcript/binding evidence, read-only sink observation and retained worker failure records. The implementer corrected the checker and synthetic mutation fixtures.

**Decision and brief reason:** Final review passed on the retained measured evidence and final source. Preserve the initial counterexamples and all qualification errors; no measured revocation failure was demonstrated by these instrument defects.

**Source / response reference:** RV-A-011: independent review and preserved correction history

**Affected artifact / section:** RV-A-011: checker, regression tests and review

**Checks actually recorded:** Final reviewer independently regraded 8/8 cases and passed the same 18 instrument tests. Read-only database inspection matched raw snapshots, found zero post-fence effects and verified checkpoint IDs in all four framework runs. Source-freeze hashes remained unchanged. Reviewer JSON SHA-256 b1e808841f66ad76f736c7532a624fa33d178b8e60bf8a988b51575b73383ed3.

**Reported or unverified checks:** Review was separate AI-assisted work, not independent human validation. Repeating the 18 tests or regrading the eight saved cases adds no new measured runs.

**Human status:** Not recorded

**Human evidence / scope:** The researcher’s request to proceed does not validate the code or review.

**Remaining limits:** The initial false passes accepted malformed delegation scope and admission grant evidence. Other qualification errors included native Interrupt serialization and a synthetic post-fence mutation missing controller revocation evidence. All precede measured collection and remain retained.

**Publication handling:** Review before release

**Captured UTC:** 2026-11-03

## RV-TR-026

**Event UTC:** 2026-11-03

**Record type:** Contemporaneous

**Human reference and request:** Documentation was included in the approved pilot proposal.

**AI contribution:** Appended the integration decision, authorization, protocol, actual execution/review and limits to one shared research record.

**Decision and brief reason:** Preserve v0.1 snapshots and original trace/artifact/disclosure rows. Export matching v0.2 workbook and portable Markdown views.

**Source / response reference:** RV-A-012/RV-A-013/RV-A-014; documentation QA and external checksums

**Affected artifact / section:** Updated workbook, shared JSON/CSV and notebook

**Checks actually recorded:** Current Space baseline matched preserved local v0.1 bytes; final artifact QA records renders, values, links and copy identity.

**Reported or unverified checks:** This snapshot precedes verification of its later repository integration. There is no automatic Excel/Obsidian/GitHub synchronization.

**Human status:** Not recorded

**Human evidence / scope:** No new human factual review or public release approval inferred.

**Remaining limits:** No approval-study files changed. Current repository status supersedes proposed wording only in current views; historical entries remain unchanged.

**Publication handling:** Review before release

**Captured UTC:** 2026-11-03

## RV-TR-027

**Event UTC:** 2026-11-03

**Record type:** Correction

**Human reference and request:** Reproducibility package included in the approved pilot scope.

**AI contribution:** Corrected the pre-delivery archive to include its exact historical gateway dependency and root extraction instructions.

**Decision and brief reason:** Make the standalone evidence archive runnable after extraction while preserving measured code, protocol, results and review bytes.

**Source / response reference:** RV-A-011; package metadata and extracted-archive validation

**Affected artifact / section:** RV-A-011: final standalone archive

**Checks actually recorded:** Extracted archive passed the same 18 instrument tests and regraded all eight retained cases. Historical gateway SHA-256 matches its frozen source.

**Reported or unverified checks:** No additional measured run was collected during package verification.

**Human status:** Not recorded

**Human evidence / scope:** No human execution or result validation inferred.

**Remaining limits:** Reproduction uses a platform-specific dependency lock. Package integrity and reruns do not enlarge the original claim.

**Publication handling:** Review before release

**Captured UTC:** 2026-11-03
