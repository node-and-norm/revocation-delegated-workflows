# Artifact registry

Original RV-A-001 through RV-A-006 rows remain unchanged historical records. Current artifacts begin with the later decision notes and v0.3 pilot. Historical v0.1 workbook/notebook bytes remain in Space version history and the private repository; this notebook bundles only the current workbook convenience copy.

RV-A-009 is the canonical dated decision note prepared at docs/decisions/2026-11-03-bounded-integration-pilot.md for the approved repository update. Its exact source hash is recorded below. It is not given an unverified new-commit URL in this capture. The pilot archive supplies the full prospective protocol and execution evidence.

## RV-A-001: Testing Revocation in Delegated Workflows

[Open included artifact or verified source](Attachments/Testing_Revocation_in_Delegated_Workflows_v0.1.docx)

**Version:** v0.1

**Format:** DOCX

**Library reference:** libfile_54a59b0a9c3c81919b59a3e3883a0d5b, version 1

**First delivered UTC:** 2026-10-31 18:00:13 UTC

**Delivery message:** Sentinel_3a76e1144c308191bd1548f381e7c19c

**Relevant scope / section:** Six-page research specification; active Q1, endpoint and gates

**Evidence / check status:** SHA-256 and size rechecked during documentation preparation

**SHA-256:** dc0ade776a556befd523d92cc73dda9ea557eb92b3679bb9898366b4b946af69

**Bytes:** 46562

**Remaining limits:** Design, not execution. Linked in Attachments; source-review details are recorded, not re-performed here.

## RV-A-002: Deterministic Revocation Measurement Qualification

[Open included artifact or verified source](Attachments/qualification_revocation_v01.zip)

**Version:** v0.1

**Format:** ZIP

**Library reference:** libfile_f6ade2000eec8191a5a28ec06d48f070, version 0

**First delivered UTC:** 2026-10-31 18:16:19 UTC

**Delivery message:** Sentinel_298317db44f48191a235e837658b8768

**Relevant scope / section:** Frozen attempts 01–03, source, raw results, oracle, review and checksums

**Evidence / check status:** Final bounded qualification complete after four oracle corrections; 10 fixtures and 18 final unit tests

**SHA-256:** ce289cb5b8a4402fd08c6db25b00fc41866f9f8e0637730c1757e706f1c09d66

**Bytes:** 161833

**Remaining limits:** Controller-mediated handoff; trusted worker-writable database. Not actual delegation, external gateway validation or an agent evaluation.

## RV-A-003: Delegated Gateway Measurement Qualification

[Open included artifact or verified source](Attachments/qualification_revocation_v02.zip)

**Version:** v0.2

**Format:** ZIP

**Library reference:** New artifact; Library identity to be assigned at delivery

**First delivered UTC:** 

**Delivery message:** Included with this documentation delivery; no earlier delivery message recorded

**Relevant scope / section:** Model-free one-edge delegation; server-bound IPC identity; gateway-owned database; separate observer

**Evidence / check status:** Final attempt04 qualified and separately AI-reviewed after three causal-treatment corrections. ZIP hash and 508,334-byte size rechecked; detailed manifests and review retained.

**SHA-256:** 7355be609c634bdf48de8b3582ea4018f2e48ed0a47d421afbb073d24190d386

**Bytes:** 508334

**Remaining limits:** One-edge deterministic protocol delegation; gateway-only write code, but same OS user is not hostile-process confinement. Inert SQLite sink, trusted same-host observer, direct delivery as worker evidence. No model, remote service, distributed revocation or novelty claim.

## RV-A-004: Revocation AI Use and Research Decision Traceability

**Version:** v0.1

**Format:** XLSX

**Library reference:** New identity; not the old approval-study workbook

**First delivered UTC:** 

**Delivery message:** Prepared for current delivery; no earlier delivery message

**Relevant scope / section:** Editable decision/AI-use ledger, artifacts, disclosure rules and open questions

**Evidence / check status:** Artifact-tool authoring and QA recorded in QA.md; checksum in external SHA256SUMS

**SHA-256:** 

**Bytes:** 

**Remaining limits:** No self-referential checksum inside the workbook. No desktop Excel opening or automatic synchronization claimed.

## RV-A-005: Revocation structured traceability record

**Version:** v0.1

**Format:** JSON and CSV

**Library reference:** Included in this documentation package

**First delivered UTC:** 

**Delivery message:** Prepared for current delivery; no earlier delivery message

**Relevant scope / section:** Single structured source for workbook and Markdown views

**Evidence / check status:** ID, schema and row-count validation; checksum in external SHA256SUMS

**SHA-256:** 

**Bytes:** 

**Remaining limits:** Editable snapshot, not complete conversation capture or immutable audit. Self-checksum excluded to avoid a circular record.

## RV-A-006: Revocation research notebook

**Version:** v0.1

**Format:** Markdown notebook ZIP

**Library reference:** New identity; not the old approval-study vault

**First delivered UTC:** 

**Delivery message:** Prepared for current delivery; no earlier delivery message

**Relevant scope / section:** Portable Obsidian-compatible notes, canonical artifact copies, shared source and identical workbook copy

**Evidence / check status:** Relative-path and package-integrity checks recorded in QA.md; checksum supplied with delivery

**SHA-256:** 

**Bytes:** 

**Remaining limits:** Not installed in an existing vault or opened in Obsidian. Private; no repository or public publication.

## RV-A-007: Checkpointed-workflow candidate decision

[Open included artifact or verified source](https://github.com/node-and-norm/revocation-delegated-workflows/blob/c7eebe8e049d9379da323827d024f08c1c13a1cd/docs/decisions/2026-10-31-checkpointed-workflow-candidate.md)

**Version:** 2026-10-31

**Format:** Markdown

**Library reference:** https://github.com/node-and-norm/revocation-delegated-workflows/blob/c7eebe8e049d9379da323827d024f08c1c13a1cd/docs/decisions/2026-10-31-checkpointed-workflow-candidate.md

**First delivered UTC:** 

**Delivery message:** Prepared for this record; historical sources retain their original dates

**Relevant scope / section:** Dated framework candidate and effect-boundary correction

**Evidence / check status:** Historical source note preserved byte-for-byte

**SHA-256:** ea6bdde82dc79ec190a98f15267f5446b31bc4b975d9f043db17502253cdf497

**Bytes:** 7882

**Remaining limits:** Source assessment only at the recorded date.

## RV-A-008: Workflow selection and contribution gate

[Open included artifact or verified source](https://github.com/node-and-norm/revocation-delegated-workflows/blob/c7eebe8e049d9379da323827d024f08c1c13a1cd/docs/decisions/2026-11-01-workflow-selection-and-contribution-gate.md)

**Version:** 2026-11-01

**Format:** Markdown

**Library reference:** https://github.com/node-and-norm/revocation-delegated-workflows/blob/c7eebe8e049d9379da323827d024f08c1c13a1cd/docs/decisions/2026-11-01-workflow-selection-and-contribution-gate.md

**First delivered UTC:** 

**Delivery message:** Prepared for this record; historical sources retain their original dates

**Relevant scope / section:** Source-qualified tutorial candidate; contribution HOLD

**Evidence / check status:** Historical source note preserved byte-for-byte

**SHA-256:** 6fcb58de885a5999153f9d344e49ae1c2e617258a615ff95398f70e64f84a5b6

**Bytes:** 10329

**Remaining limits:** No installation or runtime experiment occurred in this dated assessment.

## RV-A-009: Bounded integration pilot decision and evidence boundary

**Version:** 2026-11-03

**Format:** Markdown

**Library reference:** Prepared for docs/decisions/2026-11-03-bounded-integration-pilot.md in the private repository

**First delivered UTC:** 

**Delivery message:** Prepared for this record; historical sources retain their original dates

**Relevant scope / section:** Comparison delivered at 00:31:03 UTC; explicit pilot approval at 00:43:06 UTC; final bounded results

**Evidence / check status:** Dated decision summary reconciled with actual final results/review; no backdated protocol

**SHA-256:** f3bf58bc3a9da7adea9584b5b2ea77834eebb58ffda5d7c96e9d5fc628eb23ab

**Bytes:** 8321

**Remaining limits:** Canonical repository decision note. Current notebook summarizes its meaning; no unverified new-commit URL is invented.

## RV-A-010: Bounded integration conformance protocol

[Open included artifact or verified source](Attachments/revocation_integration_pilot_v03_20261103.zip)

**Version:** v0.3

**Format:** Markdown

**Library reference:** Included in pilot evidence package

**First delivered UTC:** 

**Delivery message:** Prepared for this record; historical sources retain their original dates

**Relevant scope / section:** Prospective qualification gates, eight measured cases and limits

**Evidence / check status:** Freeze recorded at 2026-11-03 00:47:30 UTC before measured collection; protocol hash agrees with final package metadata.

**SHA-256:** 6e17897c751167c5c23d148cc1c2397b84b223cbab4fe54e612ce08f3898a5be

**Bytes:** 6112

**Remaining limits:** Internal design freeze, not external preregistration. Gateway restart and arbitrary crash recovery excluded.

## RV-A-011: Supervisor/subagent integration conformance pilot

[Open included artifact or verified source](Attachments/revocation_integration_pilot_v03_20261103.zip)

**Version:** v0.3

**Format:** ZIP

**Library reference:** Prepared for approved private repository record

**First delivered UTC:** 

**Delivery message:** Prepared for this record; historical sources retain their original dates

**Relevant scope / section:** Code, exact dependencies, upstream/restart qualification, measured evidence, review and retained failures

**Evidence / check status:** Final bounded conformance pass, separately AI-reviewed. 140-file standalone archive includes unchanged historical gateway, protocol, exact sources/dependencies, raw eight-case evidence, 18 tests, failures and review. Extracted archive tests and saved-case regrade passed; no new measured collection.

**SHA-256:** b088613324c731e900e71317be725a8f2a8002d22a29bc40dcc4670ffb68f3c9

**Bytes:** 223536

**Remaining limits:** One scripted synthetic workflow and local atomic sink. No autonomous-model result, external mail, remote-provider guarantee, hostile-worker confinement, gateway restart, new mechanism or AGI-readiness claim.

## RV-A-012: Revocation AI Use and Research Decision Traceability

[Open included artifact or verified source](Attachments/Revocation_AI_Use_and_Research_Decision_Traceability_v0.2.xlsx)

**Version:** v0.2

**Format:** XLSX

**Library reference:** libfile_01667e154f648191af5bf2c9d624797b; replacement version pending save

**First delivered UTC:** 

**Delivery message:** Prepared for this record; historical sources retain their original dates

**Relevant scope / section:** Current editable five-sheet record, retaining original v0.1 rows

**Evidence / check status:** Final artifact-tool QA and checksum supplied separately

**SHA-256:** 

**Bytes:** 

**Remaining limits:** Same Space identity with version history. Current capture precedes later repository integration.

## RV-A-013: Revocation structured traceability record

[Open included artifact or verified source](Records/revocation_traceability_content_v02.json)

**Version:** v0.2

**Format:** JSON and CSV

**Library reference:** Included in current documentation package

**First delivered UTC:** 

**Delivery message:** Prepared for this record; historical sources retain their original dates

**Relevant scope / section:** Single shared source for workbook and Markdown views

**Evidence / check status:** Schema, prior-row preservation and export equality checked

**SHA-256:** 

**Bytes:** 

**Remaining limits:** Self-hash omitted to avoid circularity; external SHA256SUMS supplies file identity.

## RV-A-014: Revocation research notebook

[Open included artifact or verified source](START_HERE.md)

**Version:** v0.2

**Format:** Markdown notebook ZIP

**Library reference:** libfile_0617b9ba9c448191ade1b1cec0af45c3; replacement version pending save

**First delivered UTC:** 

**Delivery message:** Prepared for this record; historical sources retain their original dates

**Relevant scope / section:** Portable notes, immutable evidence attachments and identical current workbook

**Evidence / check status:** Relative links, Canvas targets, copied bytes and ZIP integrity checked

**SHA-256:** 

**Bytes:** 

**Remaining limits:** Not installed on a Mac or opened in Obsidian; no automatic synchronization.
