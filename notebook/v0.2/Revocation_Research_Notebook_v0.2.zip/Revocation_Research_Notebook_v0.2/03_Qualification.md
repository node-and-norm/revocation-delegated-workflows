# Frozen instrument qualifications

These earlier instruments remain unchanged. Their counts are not transferred into the v0.3 pilot’s measured cases or pooled into a statistical sample.

## Qualification v0.1

[Canonical package](Attachments/qualification_revocation_v01.zip), RV-A-002. Final attempt03 met ten finite arm-by-schedule expectations and 18 unit tests. Separate AI review recorded 74 oracle correction/deletion assertions and 36 direct-database/observer assertions. Those counts overlap.

Attempts01/02 retain their original evidence and four checker blind spots: duplicate without a prior effect, unmatched attempt 999, wrong preparation binding and boolean sequence numbers. Attempt03 corrects them and adds regressions. These were oracle defects, not demonstrated transaction-gate failures.

C2 was a controller-mediated handoff. Trusted workers could write the database. This was narrower than actual delegated gateway enforcement. The seeded admission-only race and successful detector controls do not establish novelty or safety in all schedules.

## Qualification v0.2

[Canonical package](Attachments/qualification_revocation_v02.zip), RV-A-003. Final attempt04 met 18 fixtures, nine schedules in two arms, with 19 current tests and 18 legacy tests separately. Reviewer counts were 349 semantic/database assertions and 36 real-IPC assertions. Discovery and direct invocation repeated the same 19 tests.

Three initial causal-treatment false qualifications were preserved and corrected: wrong denial cause, missing issued child grant and missing successful admission. Zero effects alone did not establish that revocation caused a stop. Endpoint classification remains separate from treatment qualification.

The parent requested a child-specific grant through its bound channel; the child used its own channel. The gateway owned write code and a separate read-only observer inspected the sink. Same-OS-user process separation was not hostile-process confinement. The result remained a finite trusted-host instrument qualification.

## What v0.3 adds

[The integration pilot](10_Integration_Pilot.md) exercises actual supervisor/subagent middleware and persistent checkpoint resumption in a fresh worker while retaining the existing gateway. It does not rewrite or expand these earlier results. Their canonical source, raw data, failed counterexamples and reviews remain inside their original archives.
