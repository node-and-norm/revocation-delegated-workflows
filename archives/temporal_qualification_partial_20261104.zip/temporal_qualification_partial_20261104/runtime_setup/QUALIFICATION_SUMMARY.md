# Temporal runtime setup qualification

Date: 4 November 2026 UTC. Development setup only; no Workflow or Activity execution and no measured study.

- Node v24.22.1; npm 11.9.0; Linux x86_64, Debian 13.
- Exact Temporal TypeScript SDK 1.25.0 installed from official npm registry, scripts disabled. Six selected SDK packages declare Node >=20.3.0 and MIT licenses. Native worker/testing imports succeeded.
- Lockfile contains 158 package entries (147 installed packages); all entries have integrity values and registry.npmjs.org resolved URLs. npm verifies integrity during fetch. Package-level license metadata is retained; this is not a complete third-party legal audit.
- CLI 1.10.0 official Linux amd64 archive matched both release asset digest and checksums.txt. Binary reports Server 1.32.2, UI 2.56.1. MIT license retained in bin/LICENSE.
- Local headless in-memory server bound to 127.0.0.1:17233 returned SERVING. It was terminated and process exit confirmed. No server is intentionally left running.
- First npm attempt failed at its default /home/agent/.npm cache path. Second attempt used an isolated workspace cache and succeeded; original failure log retained.

Paths, hashes, official source, and scope are in provenance/runtime-manifest.json. package-lock.json pins dependency resolution. This directory contains runtime support artifacts and is not intended for wholesale repository upload: exclude node_modules and .npm-cache from any research package.

Not established: Workflow lifecycle correctness, cancellation delivery, sink bridge conformance, native final-outcome mapping, or research results. These require separate development qualification and review.
