# Bridge and lifecycle qualification plan

4 November 2026 UTC. Mark Julius Banasihan. Proposed implementation qualification, not measured study.

## Verified reuse

Historical ZIP SHA256 adf5e66cb0ad90038cde189330ee46877fabda26f1d829d3ae9b734c44af827c independently verified. Extracted frozen_candidate_v02/gateway.py unchanged, SHA256 98445edd61af21bc5c740053f8a93f6c179e4c5efa7b28dd7363e779b8f059a9. It binds controller/parent/child identities to three distinct multiprocessing Pipe endpoints. Requests carry a claim that must match the channel. SQLite writes belong exclusively to the gateway.

## Bridge architecture

A Python supervisor creates gateway, parent and child pipes, obtains valid delegation/admission before cancellation, then transfers its child endpoint to a separate bridge process and closes its own child copy. Parent and controller endpoints never enter the bridge or Node process. A Unix-domain socket in the fresh case directory exposes one newline-delimited JSON execute request to the Node Activity. The bridge passes the approved request unchanged over its child-only pipe and returns the raw gateway response with a transport envelope naming the request ID. The ID is bridge correlation, not an echoed gateway receipt or cryptographic authentication.

The bridge has a strict one-operation schema and no caller-selectable actor routing, revoke, delegate, prepare, stop, SQL or file-read operations. It permits exactly one execute exchange per fresh case; transport failure after dispatch is recorded as an uncertain outcome and never retried. A trusted local actor could bypass filesystem boundaries; this is information-channel preservation, not hostile-worker confinement.

Test orchestration remains separate. The Python supervisor observes instrumentation and releases declared barriers or sends revocation through its controller pipe. It never sends privileged sink rows as Activity/Workflow results. Instrumentation is a trusted local record, not an independent attestation.

## Pinned lifecycle source

https://github.com/temporalio/sdk-typescript/blob/efafd16ef4533da24029277bd72caf564c7aa007/packages/workflow/src/cancellation-scope.ts

Directly inspected source specifies inherited cancellation and the shielding provided by nonCancellable. The Activity is started and awaited in the ordinary cancellable root. Only after its Workflow-side promise settles does a distinct nonCancellable scope wait for an observation-release signal or a finite timeout. The shield never encloses Activity scheduling. Catch records the native failure category without inferring Activity cessation; finally always enters the observation hold. A signal carries only an observation-cut identifier, never sink outcome.

TRY_CANCEL may enter the hold while the Activity still runs. WAIT enters after the native execution disposition. Activity cancellation observation, last instrumentation, bridge response, Worker settlement, native Activity terminal history and Workflow closure remain separate records.

The Activity cancellation notification must be explicitly observed while heartbeat delivery is active. In the bounded-continuation case it intentionally proceeds once after that observation. The cancellation-cooperative qualification exits instead. Timers outside the Workflow are harness controls, not native Workflow time. A withheld release yields observation timeout and invalid treatment, not a successful control result.

## Narrow qualification gates

Q0: source/hashes/versions verified; dependency install and server start separately recorded. SDK 1.25.0; CLI version/path/hash selected by runtime worker. No automatic CLI download. Record Node, Python, OS, architecture, package lock, server output/version and license references.

Q1: bridge contract tests with a fake pipe verify exact request preservation, rejection of forbidden op/extra fields/wrong actor/oversize frame, one dispatch, uncertain-response behavior and absence of auto-retry. These tests establish bridge behavior only.

Q2: live gateway controls in isolated directories: delegated/prepared child effect; pre-fenced child revoked denial. Inspect actual SQLite read-only after controlled shutdown. Actor-separation mutation cannot reach controller through bridge.

Q3: native delivery/lifecycle qualification for both modes with cooperative Activity: heartbeat receives cancellation, Activity reports observation, Workflow survives in hold, release closes it, history is exported before teardown. Verify no Activity scheduled from inside shield.

Q4: one bounded-continuation case per mode qualifies exact native mapping and instrumentation. Preserve all events even when unexpected. This does not freeze or collect the six-cell study. A later distinct decision is required for measured collection.

Stop on dependency ambiguity, unexpected download, absent cancellation, unintended retries, lost records, wrong actor, early Workflow closure, impossible causal order, invalid baseline or unclear native outcome. Preserve partial output and cleanup separately. No live model, paid API, external effect or production system.

## Pre-run review corrections

The supervisor uses spawn and explicitly closes gateway-side copies. Child bridge accepts only the fixed grant/ticket/scope/payload. Dispatch-attempt is recorded before send so partial-send failures remain uncertain. A Worker inbound interceptor records invocation settlement separately from Activity finally instrumentation. The runner waits for actual native terminal Activity history before releasing the Workflow; timeout is an invalid treatment. Released=false is a failure. Worker shutdown is bounded, and supervisor forced termination remains explicit cleanup outside primary observations.

The next code review found a gateway lifecycle dependency: EOF on any actor pipe terminates the historical gateway. The initial candidate closed the child endpoint too early. The revision keeps the cooperative endpoint open, and the bridge holds its child endpoint until a teardown Event after explicit gateway stop. The Event conveys cleanup timing only. The primary supervisor snapshot is now a distinct precleanup file. Native Activity history requires one schedule/start/terminal chain with attempt 1.
