# Independent AI-assisted bridge and lifecycle review

Date: 2026-11-04 UTC. Status: preliminary source/specification review. No experiment executed by this reviewer.

Reviewed BRIDGE_LIFECYCLE_SPEC_v01.md, the unchanged gateway source, and the preceding reviewed protocol/evidence contract.

## Initial findings

1. Preserve channel identity at operating-system descriptor level. A forked bridge can inherit parent/controller pipes even when its function arguments contain only the child endpoint. Prefer a spawn context, pass only the child endpoint, and close supervisor copies after transfer. This is a trusted-local channel constraint, not hostile-process isolation.
2. Validate fixed request values as well as field names: child claim, grant, ticket, scope and inert payload. Reject caller-selected routing and every non-execute operation. Establish at most one dispatch, bounded frame parsing, explicit failed/uncertain transport outcomes and no retry.
3. Qualify an Activity-start barrier before cancellation and a positive cancellation-observed barrier before controlled continuation. Heartbeat emission alone supplies neither observation.
4. Start the tested Activity in the cancellable root. Shield only the later observation hold; bounded timeout must invalidate the intended treatment. Keep Workflow-side settlement, worker instrumentation, server terminal history and effect ledger distinct.
5. WAIT completion through timeout/failure must retain that exact classification. A terminal event alone does not establish cooperative cancellation, revocation or absence of an effect.
6. Preserve the fixed rootR epoch7-to8 and single-outstanding-operation limitations. A bridge correlation ID cannot upgrade the historical gateway to an authenticated or request-bound receipt.

## Review gate

The design is suitable for implementation qualification subject to inspecting actual source, tests and exported native history. No code-conformance or runtime pass is asserted by this preliminary review. Measured collection remains a separate decision.

## First candidate source findings (00:06 UTC)

Reviewed source/bridge.py, workflows.ts, native_runner.cjs before execution. Sent builder these corrections:

- Set dispatch-attempted before calling pipe send. An exception during send can have an uncertain delivery outcome; recording not_dispatched after a partial send is unsound.
- The Activity finally flag marks an instrumented point only. Add a separate Worker invocation/interceptor settlement observation or leave that field unobserved.
- In TRY_CANCEL, Workflow settlement and Activity finally can precede the server terminal history record. Do not claim the terminal mapping until the matching native event is observed or explicitly unresolved at the cut.
- Require a successful matching observation release. A returned state with released=false is an invalid treatment, even when the Workflow completes.
- Bound shutdown and preserve precleanup history separately from cleanup observations.

Positive source checks: tested Activity is scheduled outside the shield; maximumAttempts=1 is explicit; child request keys and values are fixed; bridge accepts one connection and dispatch; parent/controller operations are rejected by schema. These are source observations, not executed conformance results.

## Blocking lifecycle finding (00:07 UTC)

The unchanged gateway waits on every pipe and treats EOF as a fatal exception. The first supervisor closed its child endpoint immediately in cooperative cases; the first bridge closed its endpoint immediately after a continuation response. Either action could terminate the gateway before the intended observation/cleanup boundary. Requested explicit child-endpoint lifetime through controller stop, with a separate bridge teardown signal carrying no controller operations, and positive normal-stop verification. No native run has been approved by this reviewer yet.

Also requested separately preserved primary and cleanup records rather than overwriting the primary record, plus native terminal linkage to the single scheduled Activity and attempt. Earlier send-uncertainty and observation-release corrections are present in the next candidate; their runtime behavior remains untested.

## Revised source gate (00:08 UTC)

Inspected revised supervisor, bridge and native runner. Spawn context prevents inherited privileged pipes; gateway-side copies are closed in supervisor; bridge receives only child endpoint and a teardown Event. Cooperative child endpoint remains alive; continuation bridge keeps its endpoint until explicit gateway stop. A separate supervisor_precleanup.json preserves the primary record. Native checks now require one schedule/start/terminal with matching scheduledEventId and attempt 1.

Requested final corrections: cleanup exceptions, forced gateway termination, nonzero gateway exit, and bridge teardown timeout must invalidate the run. Subject to these corrections and verified runtime pins, the source is suitable for attempting bounded Q1-Q4 qualification. This is a source review gate, not a runtime conformance pass, measured-study approval, independent human validation or hostile-process confinement assessment.

## First qualification attempt review (00:10 UTC)

Inspected logs/q1_schema.txt, logs/q2.txt and control source. Four schema test methods passed. They do not cover the planned fake-pipe transport cases; Q1 remains partial. Q2 was blocked by socket creation EPERM before dispatch. The socket was constructed outside the bridge's try/finally, bypassing its failure journal; subsequent controller cleanup failed with BrokenPipe after gateway EOF. No live-control pass or native lifecycle result follows.

Requested no-socket mock coverage for creation failure, partial-send uncertainty, response timeout/receive failure, malformed/oversized frames, one dispatch and no retry. The Q2 client's receive loop also needs EOF/size handling, as repeated empty reads otherwise loop indefinitely. A denied escalated rerun was reported by the builder; this reviewer did not retry or change execution route.
