"""Single-use trusted fixture bridge. Never accepts controller operations."""
import json, socket, time
MAX_FRAME=4096
FIXED={'op':'execute','claim':'childC','grant':'child-1','scope':'summary:task1','ticket':'ticket-1','payload':'inert summary'}

def validate(req):
    if not isinstance(req,dict) or set(req)!=set(FIXED)|{'id'}: raise ValueError('schema')
    if any(req[k]!=v for k,v in FIXED.items()): raise ValueError('binding')
    if not isinstance(req['id'],str) or not 1<=len(req['id'])<=128: raise ValueError('id')
    return req

def serve(path, child, log_path, teardown):
    def record(kind,**data):
        with open(log_path,'a') as f:
            f.write(json.dumps({'kind':kind,'monotonic_ns':time.monotonic_ns(),**data},sort_keys=True)+'\n'); f.flush()
    server=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
    dispatch_attempted=False;dispatched=False
    try:
        server.bind(path);server.listen(1);server.settimeout(40)
        record('ready')
        conn,_=server.accept()
        with conn:
            conn.settimeout(15);buf=b''
            while b'\n' not in buf:
                part=conn.recv(1024)
                if not part:raise ValueError('truncated_frame')
                buf+=part
                if len(buf)>MAX_FRAME:raise ValueError('oversize_frame')
            line,extra=buf.split(b'\n',1)
            if extra:raise ValueError('extra_frame')
            req=validate(json.loads(line));record('dispatch',request=req)
            dispatch_attempted=True
            child.send(req);dispatched=True
            if not child.poll(20):raise TimeoutError('gateway_response')
            result=child.recv();record('gateway_response',request_id=req['id'],result=result)
            conn.sendall((json.dumps({'request_id':req['id'],'gateway_result':result})+'\n').encode())
            record('transport_response_sent')
    except BaseException as e:
        record('failure',error=repr(e),dispatch_attempted=dispatch_attempted,dispatched=dispatched,outcome='uncertain' if dispatch_attempted else 'not_dispatched')
        raise
    finally:
        server.close();record('transport_closed_waiting_for_teardown')
        if not teardown.wait(100):record('teardown_timeout')
        child.close();record('closed')
