import unittest
from bridge import validate,FIXED
class SchemaTests(unittest.TestCase):
 def test_exact(self):
  req={'id':'case-execute',**FIXED};self.assertIs(validate(req),req)
 def test_forbidden_fields(self):
  for key,value in [('op','revoke'),('claim','controller'),('grant','parent-0'),('scope','other'),('ticket','bad'),('payload','real')]:
   with self.subTest(key=key),self.assertRaises(ValueError):validate({'id':'x',**FIXED,key:value})
 def test_extra(self):
  with self.assertRaises(ValueError):validate({'id':'x',**FIXED,'actor':'controller'})
 def test_id(self):
  for val in ['',1,None,'x'*129]:
   with self.assertRaises(ValueError):validate({'id':val,**FIXED})
if __name__=='__main__':unittest.main()
