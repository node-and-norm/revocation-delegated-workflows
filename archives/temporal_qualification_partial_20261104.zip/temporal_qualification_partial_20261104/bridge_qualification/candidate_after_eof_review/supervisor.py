"""Qualification controller, explicitly separate from measured collection."""
import json,multiprocessing as mp,subprocess,time,sys,traceback,socket,sqlite3
from pathlib import Path
from gateway import gateway_main
from bridge import serve
CTX=mp.get_context('spawn')
NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'

def call(ch,req):
    ch.send(req)
    if not ch.poll(20):raise TimeoutError('gateway reply')
    return ch.recv()
def wait_for(pred,label,deadline=35):
    end=time.monotonic()+deadline
    while not pred():
        if time.monotonic()>end:raise TimeoutError(label)
        time.sleep(.025)
def snapshot(db):
    with sqlite3.connect(f'file:{db}?mode=ro',uri=True) as c:
        c.row_factory=sqlite3.Row
        return {t:[dict(x) for x in c.execute('SELECT * FROM '+t)] for t in ('authority','grants','tickets','events','effects')}
def run(folder,mode,behavior,address):
    folder=Path(folder).resolve();folder.mkdir(exist_ok=False)
    control,cg=CTX.Pipe();parent,pg=CTX.Pipe();child,ch=CTX.Pipe()
    gateway=CTX.Process(target=gateway_main,args=(str(folder/'sink.sqlite'),'commit_fenced',cg,pg,ch));gateway.start()
    cg.close();pg.close();ch.close()
    teardown=CTX.Event()
    report={'kind':'qualification','mode':mode,'behavior':behavior,'errors':[]};bridge=None;node=None
    sock=str(folder/'child.sock')
    try:
        assert control.poll(20) and control.recv()=={'ok':True}
        report['grant']=call(parent,{'id':'delegate','op':'delegate','claim':'parentP','grant':'parent-0','scope':'summary:task1','child':'childC'})
        report['admission']=call(child,{'id':'prepare','op':'prepare','claim':'childC','grant':'child-1','scope':'summary:task1'})
        assert report['grant']['outcome']=='grant' and report['admission']['outcome']=='admission'
        if behavior!='cooperative':
            bridge=CTX.Process(target=serve,args=(sock,child,str(folder/'bridge_events.jsonl'),teardown));bridge.start()
            child.close();wait_for(lambda:Path(sock).exists(),'bridge_ready')
        # Cooperative control keeps the unused child endpoint alive through gateway stop.
        case_id=folder.name
        cfg={'dir':str(folder),'socket':sock,'caseId':case_id,'mode':mode,'behavior':behavior,'address':address}
        (folder/'config.json').write_text(json.dumps(cfg,indent=2))
        with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
            node=subprocess.Popen([NODE,str(Path(__file__).with_name('native_runner.cjs')),str(folder/'config.json')],stdout=out,stderr=err)
            wait_for(lambda:(folder/'cancel_observed').exists() or node.poll() is not None,'native_cancel_observation',50)
            if node.poll() is not None:raise RuntimeError('node ended before release')
            report['activity_observation_marker']=True
            if behavior!='cooperative':
                if behavior=='continue_fenced':
                    report['fence']=call(control,{'id':'withdrawal-1','op':'revoke','claim':'controller'})
                    assert report['fence']['outcome']=='revocation'
                report['before_release']=snapshot(folder/'sink.sqlite')
                (folder/'effect_release').write_text(case_id)
            report['node_exit']=node.wait(timeout=75)
            if report['node_exit']!=0:raise RuntimeError('node failed')
        if bridge and not bridge.is_alive():raise RuntimeError('bridge exited before teardown')
        report['sink']=snapshot(folder/'sink.sqlite')
        report['ok']=True
    except BaseException:
        report['ok']=False;report['errors'].append(traceback.format_exc())
    finally:
        try:report['sink']=snapshot(folder/'sink.sqlite')
        except BaseException:report['snapshot_error']=traceback.format_exc()
        # Primary record persists before any termination cleanup.
        (folder/'supervisor_precleanup.json').write_text(json.dumps(report,indent=2))
        if node and node.poll() is None:
            node.terminate()
            try:node.wait(10)
            except subprocess.TimeoutExpired:node.kill();node.wait()
            report['forced_node_cleanup']=True
        try:
            if gateway.is_alive():
                report['gateway_stop']=call(control,{'op':'stop'})
                if report['gateway_stop']!={'ok':True}:report['ok']=False;report['errors'].append('unexpected gateway stop response')
            else:report['ok']=False;report['errors'].append('gateway exited before stop')
            gateway.join(5)
        except BaseException:report['cleanup_error']=traceback.format_exc()
        if gateway.is_alive():gateway.terminate();gateway.join(5);report['forced_gateway_cleanup']=True
        report['gateway_exit']=gateway.exitcode
        teardown.set()
        if bridge:
            bridge.join(10)
            if bridge.is_alive():bridge.terminate();bridge.join(5);report['forced_bridge_cleanup']=True;report['ok']=False
            report['bridge_exit']=bridge.exitcode
            if bridge.exitcode!=0:report['ok']=False
        child.close();control.close();parent.close()
        (folder/'supervisor_record.json').write_text(json.dumps(report,indent=2))
    return report
if __name__=='__main__':
    r=run(*sys.argv[1:]);print(json.dumps({'ok':r['ok'],'errors':r['errors']}));sys.exit(0 if r['ok'] else 1)
