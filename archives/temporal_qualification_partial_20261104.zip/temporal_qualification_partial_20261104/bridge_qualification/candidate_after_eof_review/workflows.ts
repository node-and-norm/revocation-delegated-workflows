import { proxyActivities, ActivityCancellationType, CancellationScope, defineSignal, defineQuery, setHandler, condition } from '@temporalio/workflow';
const release = defineSignal<[string]>('observationRelease');
const status = defineQuery<any>('qualificationStatus');
export async function qualificationWorkflow(input: { mode: 'TRY_CANCEL' | 'WAIT_CANCELLATION_COMPLETED', caseId: string }): Promise<any> {
  let cut: string | undefined;
  const state: any = { mode: input.mode, activityScope: 'cancellable_root', settlement: 'pending', hold: false };
  setHandler(release, (value) => { if (value === input.caseId) cut = value; });
  setHandler(status, () => ({...state, cut}));
  const { protectedActivity } = proxyActivities<any>({
    startToCloseTimeout: '40 seconds', heartbeatTimeout: '10 seconds',
    retry: { maximumAttempts: 1 },
    cancellationType: ActivityCancellationType[input.mode],
  });
  try {
    // Deliberately outside the non-cancellable observation scope.
    const result = await protectedActivity(input.caseId);
    state.settlement = 'resolved'; state.result = result;
  } catch (e: any) {
    state.settlement = 'rejected';
    state.failure = { name: e?.name, message: e?.message, causeName: e?.cause?.name, causeMessage: e?.cause?.message };
  } finally {
    await CancellationScope.nonCancellable(async () => {
      state.hold = true;
      state.released = await condition(() => cut === input.caseId, '30 seconds');
      state.hold = false;
    });
  }
  return state;
}
