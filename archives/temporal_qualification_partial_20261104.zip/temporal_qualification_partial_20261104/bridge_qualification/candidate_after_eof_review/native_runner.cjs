const fs=require('node:fs'),path=require('node:path'),net=require('node:net');
const {Worker,NativeConnection}=require('@temporalio/worker');
const {Connection,Client}=require('@temporalio/client');
const {Context}=require('@temporalio/activity');
const EventType=require('@temporalio/proto').temporal.api.enums.v1.EventType;
const config=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const events=[];let ready=false,cancelObserved=false,activityFinished=false;
function record(kind,data={}) {const e={kind,...data};events.push(e);fs.appendFileSync(path.join(config.dir,'node_events.jsonl'),JSON.stringify(e)+'\n');}
function delay(ms){return new Promise(r=>setTimeout(r,ms));}
async function until(test,label,ms=25000){const end=Date.now()+ms;while(!test()){if(Date.now()>end)throw Error('timeout:'+label);await delay(25);}}
async function bridge(req){return new Promise((resolve,reject)=>{let buffer='';const s=net.createConnection(config.socket);s.setTimeout(20000);s.on('connect',()=>s.write(JSON.stringify(req)+'\n'));s.on('data',d=>{buffer+=d;if(buffer.length>4096){s.destroy();reject(Error('oversize_response'));}if(buffer.includes('\n')){s.end();try{const r=JSON.parse(buffer.split('\n')[0]);if(r.request_id!==req.id)throw Error('correlation');resolve(r);}catch(e){reject(e);}}});s.on('timeout',()=>{s.destroy();reject(Error('bridge_timeout_uncertain'));});s.on('error',reject);s.on('end',()=>{if(!buffer.includes('\n'))reject(Error('truncated_response_uncertain'));});});}
async function protectedActivity(caseId){
 const ctx=Context.current(); record('activity_started',{info:ctx.info});ready=true;
 const heartbeat=setInterval(()=>{try{ctx.heartbeat({caseId});}catch(e){record('heartbeat_error',{error:String(e)});}},100);
 try{
  try{await ctx.cancelled;}catch(e){record('activity_cancellation_observed',{name:e.name,message:e.message});cancelObserved=true;fs.writeFileSync(path.join(config.dir,'cancel_observed'),caseId);if(config.behavior==='cooperative')throw e;}
  await until(()=>fs.existsSync(path.join(config.dir,'effect_release')),'effect_release');
  const req={id:caseId+'-execute',op:'execute',claim:'childC',grant:'child-1',scope:'summary:task1',ticket:'ticket-1',payload:'inert summary'};
  record('bridge_call',{request:req});const result=await bridge(req);record('bridge_result',{result});return result;
 }finally{clearInterval(heartbeat);record('activity_final_instrumented_point');activityFinished=true;}
}
(async()=>{
 let nc,conn,worker,run,handle;
 try{
 nc=await NativeConnection.connect({address:config.address});conn=await Connection.connect({address:config.address});
 const client=new Client({connection:conn});
 worker=await Worker.create({connection:nc,taskQueue:config.caseId,workflowsPath:require.resolve('./workflows.ts'),activities:{protectedActivity},shutdownGraceTime:'2 seconds',shutdownForceTime:'5 seconds',interceptors:{activityInbound:[()=>({execute:async(input,next)=>{try{return await next(input);}finally{record('worker_invocation_settled');}}})]},maxHeartbeatThrottleInterval:'200 milliseconds',defaultHeartbeatThrottleInterval:'200 milliseconds'});
 run=worker.run();run.catch(()=>{});
 handle=await client.workflow.start('qualificationWorkflow',{taskQueue:config.caseId,workflowId:config.caseId,args:[{mode:config.mode,caseId:config.caseId}]});
 record('workflow_started',{workflowId:handle.workflowId,firstExecutionRunId:handle.firstExecutionRunId});
 await until(()=>ready,'activity_start');record('cancel_invoked');await handle.cancel();record('cancel_response_received');
 await until(()=>cancelObserved,'activity_cancellation_observed');
 await until(()=>activityFinished,'activity_final_instrumented_point');
 let state;
 const deadline=Date.now()+20000;
 do{state=await handle.query('qualificationStatus');if(state.hold)break;if(Date.now()>deadline)throw Error('timeout:hold');await delay(25);}while(true);
 record('workflow_hold_observed',{state});
 // Wait for actual server terminal Activity history, separately from instrumentation.
 let terminalHistory, terminalEvents;
 const terminalDeadline=Date.now()+20000;
 do {
   terminalHistory=await handle.fetchHistory();
   terminalEvents=(terminalHistory.events||[]).filter(e=>[12,13,14,16].includes(e.eventType));
   if(terminalEvents.length)break;
   if(Date.now()>terminalDeadline)throw Error('unresolved:activity_native_terminal');
   await delay(50);
 }while(true);
 const schedules=(terminalHistory.events||[]).filter(e=>e.eventType===10);
 const starts=(terminalHistory.events||[]).filter(e=>e.eventType===11);
 if(schedules.length!==1||starts.length!==1||terminalEvents.length!==1)throw Error('invalid_activity_cardinality');
 const scheduleId=String(schedules[0].eventId);
 const startAttrs=starts[0].activityTaskStartedEventAttributes;
 const attrs=terminalEvents[0].activityTaskCompletedEventAttributes||terminalEvents[0].activityTaskFailedEventAttributes||terminalEvents[0].activityTaskTimedOutEventAttributes||terminalEvents[0].activityTaskCanceledEventAttributes;
 if(String(startAttrs.scheduledEventId)!==scheduleId||String(attrs.scheduledEventId)!==scheduleId)throw Error('activity_history_linkage');
 if(startAttrs.attempt!==1)throw Error('unexpected_activity_attempt');
 record('native_activity_terminal',{events:terminalEvents.map(e=>({eventId:String(e.eventId),type:EventType[e.eventType]}))});
 if(terminalEvents.some(e=>e.eventType===14))throw Error('invalid_treatment:activity_timed_out');
 fs.writeFileSync(path.join(config.dir,'event_type_mapping.json'),JSON.stringify(EventType,null,2));
 // Held-open history is preserved before releasing the Workflow.
 fs.writeFileSync(path.join(config.dir,'history_before_release.json'),JSON.stringify(await handle.fetchHistory(),null,2));
 await handle.signal('observationRelease',config.caseId);record('release_signal_response');
 const result=await handle.result();record('workflow_result',{result});if(result.released!==true)throw Error('invalid_treatment:observation_not_released');
 fs.writeFileSync(path.join(config.dir,'history_final.json'),JSON.stringify(await handle.fetchHistory(),null,2));
 fs.writeFileSync(path.join(config.dir,'native_result.json'),JSON.stringify({ok:true,result},null,2));
 }catch(e){record('runner_failure',{error:e.stack||String(e)});fs.writeFileSync(path.join(config.dir,'native_result.json'),JSON.stringify({ok:false,error:e.stack||String(e)},null,2));if(handle){try{fs.writeFileSync(path.join(config.dir,'history_failure.json'),JSON.stringify(await handle.fetchHistory(),null,2));}catch(h){record('history_export_failure',{error:String(h)});}}process.exitCode=1;
 }finally{if(worker){worker.shutdown();try{await run;}catch(e){record('worker_shutdown_error',{error:String(e)});}}if(conn)await conn.close();if(nc)await nc.close();}
})();
