import json,multiprocessing as mp,socket,sys,time
from pathlib import Path
from gateway import gateway_main
from bridge import serve,FIXED
from supervisor import call,snapshot,wait_for
CTX=mp.get_context('spawn')
def run(root,fenced):
 root.mkdir();control,cg=CTX.Pipe();parent,pg=CTX.Pipe();child,ch=CTX.Pipe();teardown=CTX.Event()
 g=CTX.Process(target=gateway_main,args=(str(root/'sink.sqlite'),'commit_fenced',cg,pg,ch));g.start();cg.close();pg.close();ch.close()
 assert control.poll(20) and control.recv()=={'ok':True}
 assert call(parent,{'id':'delegate','op':'delegate','claim':'parentP','grant':'parent-0','scope':'summary:task1','child':'childC'})['outcome']=='grant'
 assert call(child,{'id':'prepare','op':'prepare','claim':'childC','grant':'child-1','scope':'summary:task1'})['outcome']=='admission'
 b=CTX.Process(target=serve,args=(str(root/'b.sock'),child,str(root/'bridge.jsonl'),teardown));b.start();child.close()
 try:
  wait_for(lambda:(root/'b.sock').exists(),'bridge_ready')
  if fenced:assert call(control,{'id':'withdrawal','op':'revoke','claim':'controller'})['outcome']=='revocation'
  with socket.socket(socket.AF_UNIX) as s:
   s.settimeout(25);s.connect(str(root/'b.sock'));s.sendall((json.dumps({'id':'execute',**FIXED})+'\n').encode());buf=b''
   while b'\n' not in buf:buf+=s.recv(1024)
  response=json.loads(buf);state=snapshot(root/'sink.sqlite')
  (root/'record.json').write_text(json.dumps({'response':response,'sink':state},indent=2))
  assert response['gateway_result']==({'outcome':'denied','reason':'revoked'} if fenced else {'outcome':'effect','effect_key':'summary:task1','payload':'inert summary','root':'rootR','epoch':7})
  assert len(state['effects'])==(0 if fenced else 1)
 finally:
  stop=call(control,{'op':'stop'});g.join(5);teardown.set();b.join(5)
  (root/'cleanup.json').write_text(json.dumps({'stop':stop,'gateway_exit':g.exitcode,'bridge_exit':b.exitcode},indent=2))
  if g.is_alive():g.terminate();g.join()
  if b.is_alive():b.terminate();b.join()
  assert stop=={'ok':True} and g.exitcode==0 and b.exitcode==0
  control.close();parent.close()
if __name__=='__main__':
 root=Path(sys.argv[1]).resolve();root.mkdir(exist_ok=False)
 for name,fenced in [('live',False),('fenced',True)]:run(root/name,fenced)
 print('Two gateway/bridge qualification controls matched expected effects and denials.')
