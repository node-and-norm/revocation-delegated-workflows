# Qualification corrections

All entries concern instrument development. No measured study collection has occurred.

1. Initial design conflated request receipt, durable fencing and caller completion. Independent design review required fixed authority scope, one outstanding request, isolated caller observations, volatile acceptance, authoritative barriers, a fixed direct/framework matrix and a non-tautological target.
2. Initial direct qualification called the gateway without the same action adapter used by the framework. The independent source reviewer identified this mismatch. Corrected direct calls now use the unchanged historical `workflow.execute`, preserving trace and binding. `direct01` is retained as disqualified diagnostic evidence. `direct02` uses the corrected path.
3. Initial harness preserved complete evidence only on success and could mask original exceptions during cleanup. Corrected harness persists partial observations first, records primary and cleanup exceptions separately, and bounds shutdown. A deliberate transport-failure regression verifies preservation.
4. Python dictionary equality accepted floating-point epoch values as equal to integers. Added strict integer shape validation. Review found that relay completion could still emit a previously rejected float response; the completion check now repeats strict validation. Regression verifies rejected delivery cannot produce completion.
5. Updated stale protocol status to distinguish implemented qualification from measured collection. Initial design and pre-correction source snapshots remain preserved.
6. The candidate source was copied before direct02 and framework02. The independent checker was still under development and changed after that snapshot. This is disclosed in source_preservation02.json. No claim of a frozen measured campaign is made.
