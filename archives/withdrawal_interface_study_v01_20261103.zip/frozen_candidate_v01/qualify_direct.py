"""Direct instrument qualification only. Not measured framework campaign."""
import json,multiprocessing as mp,sqlite3,sys,traceback
from pathlib import Path
from gateway import gateway_main
from caller import Caller
from relay import Relay
CTX=mp.get_context('spawn')
def call(pipe,req):
    pipe.send(req)
    if not pipe.poll(20):raise TimeoutError(req)
    return pipe.recv()
def snapshot(path):
    with sqlite3.connect(f'file:{path}?mode=ro',uri=True) as c:
        c.row_factory=sqlite3.Row
        d={t:[dict(r) for r in c.execute('SELECT * FROM '+t)] for t in ('authority','grants','tickets','events','effects')}
    for e in d['events']:e['data']=json.loads(e['data'])
    return d

def spawn_worker(db,phase,pending,child):
    from workflow import worker
    out,inside=CTX.Pipe(); proc=CTX.Process(target=worker,args=(str(db),phase,pending,child,inside));proc.start()
    if not out.poll(60):
        proc.terminate();proc.join();raise TimeoutError("framework worker")
    result=out.recv();proc.join(15)
    if proc.is_alive():proc.terminate();proc.join()
    result["exitcode"]=proc.exitcode
    (db.parent/f"worker_{phase}.json").write_text(json.dumps(result,indent=2))
    assert result["ok"] and proc.exitcode==0,result
    return result

def run(folder,schedule,path="direct"):
    folder.mkdir(); control,cg=CTX.Pipe();parent,pg=CTX.Pipe();child,ch=CTX.Pipe()
    proc=CTX.Process(target=gateway_main,args=(str(folder/'sink.sqlite'),'commit_fenced',cg,pg,ch));proc.start()
    caller=Caller();relay=Relay();barriers=[]
    record={'kind':'qualification','schedule':schedule,'path':path,'prior_effect':False,'workers':[],'adapter_trace':[]}
    def barrier(name):
        snap=snapshot(folder/'sink.sqlite')
        barriers.append({'name':name,'committed_events':snap['events'],'effects':snap['effects'],'caller_state':caller.state})
    try:
        assert control.poll(20) and control.recv()=={'ok':True}
        record['grant']=call(parent,{'id':'delegate','op':'delegate','claim':'parentP','grant':'parent-0','scope':'summary:task1','child':'childC'})
        record['admission']=call(child,{'id':'prepare','op':'prepare','claim':'childC','grant':'child-1','scope':'summary:task1'})
        assert record['grant']['outcome']=='grant' and record['admission']['outcome']=='admission'
        pending=[]
        if path=='framework':
            initial=spawn_worker(folder/'checkpoint.sqlite','pause',None,child);record['workers'].append(initial);pending=initial['pending']
            assert pending and not snapshot(folder/'sink.sqlite')['effects']
        if schedule!='S0':
            caller.accept({'kind':'issue','request_id':'withdrawal-1'});caller.accept(relay.submit('withdrawal-1'));barrier('accepted')
        if schedule in ('S1','S3','S4'):
            relay.deliver(control);barrier('fence_installed')
        if schedule=='S1':caller.accept(relay.completion());barrier('completion_observed')
        req={'id':'execute-1','op':'execute','claim':'childC','grant':'child-1','scope':'summary:task1','ticket':'ticket-1','payload':'inert summary'}
        if path=='framework':
            resumed=spawn_worker(folder/'checkpoint.sqlite','resume',pending,child);record['workers'].append(resumed)
            results=[e['result'] for e in resumed['trace'] if e.get('kind')=='tool_response']
            assert len(results)==1,results
            record['execute_response']=results[0]
        else:
            from workflow import execute,ARGS,BINDING
            record['binding']=BINDING
            record['execute_response']=json.loads(execute(child,ARGS,'execute-1',record['adapter_trace']))
        barrier('execute_terminal')
        if schedule=='S2':relay.deliver(control);barrier('fence_installed')
        if schedule in ('S2','S3'):caller.accept(relay.completion());barrier('completion_observed')
        if schedule in ('S4','S5'):caller.accept({'kind':'observation_end'})
        barrier('terminal_observation')
        record.update(caller_trace=caller.trace,caller_state=caller.state,relay_trace=relay.trace,barriers=barriers,sink=snapshot(folder/'sink.sqlite'))
    except BaseException:
        record['execution_error']=traceback.format_exc()
        raise
    finally:
        # Preserve partial evidence before cleanup. Cleanup must never mask the initial failure.
        record.update(caller_trace=caller.trace,caller_state=caller.state,relay_trace=relay.trace,barriers=barriers)
        try: record['sink']=snapshot(folder/'sink.sqlite')
        except BaseException: record['snapshot_error']=traceback.format_exc()
        (folder/'record.json').write_text(json.dumps(record,indent=2))
        try:
            if proc.is_alive(): record['shutdown']=call(control,{'op':'stop'})
            proc.join(10)
            if proc.is_alive():
                proc.terminate();proc.join(5);record['forced_cleanup']=True
        except BaseException:
            record['cleanup_error']=traceback.format_exc()
            if proc.is_alive():proc.terminate();proc.join(5)
        record['gateway_exitcode']=proc.exitcode
        (folder/'record.json').write_text(json.dumps(record,indent=2))
    return record
if __name__=='__main__':
    root=Path(sys.argv[1]);root.mkdir(exist_ok=False)
    path=sys.argv[2] if len(sys.argv)>2 else 'direct'
    schedules=sys.argv[3:] or ['S0','S1','S2','S3','S4','S5']
    for s in schedules:run(root/s,s,path)
