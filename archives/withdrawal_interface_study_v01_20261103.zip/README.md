# Withdrawal interface instrument qualification

Status: local instrument development and qualification, 2026-11-03. Independent checking is pending. No measured campaign or new general research finding is reported.

The caller sees only relay acceptance and completion messages. The scheduler and later checker separately inspect the trusted local sink. The gateway and framework workflow are exact copies of the historical v0.2/v0.3 implementations. Historical source and results remain unchanged.

## Current checks

- `qualification_logs/direct01`: six direct qualification schedules executed.
- `qualification_logs/modules01.log`: 11 module tests passed (some include multiple subcases; do not add those as independent experiments).
- `qualification_logs/framework01`: one native framework smoke case, S4, executed through a fresh resumed worker.
- Source snapshots are preserved with each qualification batch. They were captured after these development runs; they are not a precollection freeze.

`PROTOCOL.md` is the reviewed implementation design. A measured 12-case matrix remains a proposed next stage, contingent on qualification and independent review.

No paid model API, actual email, remote service, user data, participant recruitment or autonomous-model behavior is involved.

## Corrected qualification status

- `qualification_logs/direct02` and `framework02`: six schedules each through the common action adapter. The independent checker currently accepts all 12 records against read-only sink databases.
- `qualification_logs/modules03.log`: 14 module/failure-preservation tests passed.
- `qualification_logs/independent_mutations01.json`: independently authored semantic mutation checks; see reviewer report for final counts and scope.
- `CORRECTIONS.md` preserves defects and repairs. Direct01 is a diagnostic run predating the shared-adapter correction.
- Final independent review remains pending. The checker was authored during qualification and will require a separate freeze before measured collection.

## Final qualification review

The independent review passed for the 12 corrected qualification cases and rejected 40 targeted semantic mutations. Native checkpoint identities were found in the saved checkpoint databases. See `INDEPENDENT_REVIEW.md`.

`frozen_candidate_v01/FREEZE.json` freezes implementation, independent checker, tests, protocol and historical dependency locks after qualification. No measured collection has begun.

## Measured collection complete

The authorized fixed 12-case campaign completed through `frozen_candidate_v02`. The frozen checker and separate post-run audit both passed all 12 cases. See `measured01/INDEPENDENT_POSTRUN_REVIEW.md` and `measured01/RUN_MANIFEST.json`.

Each arm preserved six distinct schedule results: live effect; denied after confirmed fencing; pre-fence effect despite accepted request; denial before the caller receives completion; denial with caller unconfirmed; and effect while withdrawal delivery remains withheld. No old-authority effect followed the recorded local fence. These are deterministic conformance results for this fixed trusted-local setup.

No security vulnerability, deployment reliability, distributed closure, autonomous-model behavior or new revocation principle is established.
