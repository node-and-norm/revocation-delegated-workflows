# Independent qualification review

Review date: 2026-11-03. This document records development qualification, not measured collection or deployment approval.

## Evidence and scope

The review inspected DESIGN.md, its superseding implementation contract, candidate caller.py, relay.py, qualify_direct.py, the unchanged historical gateway and workflow, raw qualification records and the authoritative SQLite databases. The independent checker imports only Python standard-library modules, not the caller, relay, scheduler, gateway or workflow. Its four verdicts separately assess caller knowledge, sink effects, framework path evidence and completeness.

The reviewer authored independent_checker.py and test_independent_checker.py. Workflow execution remained with the implementation worker. This is separate implementation and review, not organizational independence or hostile-process isolation.

## Findings and corrections

1. The initial direct path issued a raw gateway request while the framework used the immutable-action adapter. This contradicted the promised shared adapter. Corrected direct02 invokes the byte-identical workflow.execute, records its exact action binding and tool entry/response, and uses the registered direct execute-1 request ID. Native execution requires resume-execute. Old direct01 traces are preserved and are not credited as common-adapter qualifications.
2. The initial runner populated caller, relay and barrier artifacts only after successful execution; cleanup could mask the original exception. The revised runner captures partial artifacts and original error before cleanup, bounds cleanup, records cleanup errors separately and preserves final process state. The implementation worker supplied an injected execution-plus-cleanup failure test, recorded in modules03.log.
3. Numeric dict equality admitted floating-point epochs. Strict integer validation was added. Review found a second hole: rejected relay delivery had already stored the invalid response, so completion could still emit an envelope. The relay completion guard was tightened and a regression test verifies that rejected delivery cannot complete.
4. The first independent checker invocation expected a workers field in old direct records and rejected those six records for missing schema. This initial output is preserved in independent_trace_review01.json. Historical direct handling was then made explicit, while common-adapter trace and binding are required for accepted direct qualifications. independent_trace_review02.json retains the six old direct failures and the passing native smoke.
5. The protocol initially retained an obsolete no-execution status. Its current status identifies implementation qualification and explicitly excludes measured collection.

## Checks performed

The checker independently replays caller-visible inputs, checks each before/after state, requires exact response/request/scope identity, verifies relay response provenance and forwarding sequence, and separately evaluates fixed schedule expectations. It does not infer caller knowledge from the private sink database.

For effects it reads sink.sqlite read-only and compares the complete record snapshot, including grants, tickets, authority, ordered receipts, outcomes and effects. It validates path-specific execute identity, single-execute liveness, exact terminal response, pre-fence versus post-fence order, monotone committed barrier prefixes and terminal observation cutoff.

For native execution it validates distinct pause/resume process IDs, successful exits, exact action bindings, checkpoint identity, restored interrupt identity and arguments, no early execution, exactly one tool entry and matching response, no remaining interrupt and exact structured result in final supervisor output. The deterministic native workflow is not a live model or actual external mail execution.

Caller isolation was structurally reviewed: caller.py imports deepcopy only, accepts messages and holds its own state; it receives no scenario, sink handle, private relay object, workflow result or expected outcome. All components remain in a trusted local fixture. This is information-flow discipline, not an OS-enforced sandbox guarantee.

## Qualification results so far

- Corrected direct02: S0 through S5 pass all four independent verdicts against authoritative SQLite. See qualification_logs/independent_direct02.json.
- Historical native framework01/S4 smoke passes all four verdicts. Final caller state is unconfirmed at observation end, the resumed attempt is denied as revoked, and the sink has zero effects. Corrected framework02 S0 through S5 subsequently pass all four independent verdicts; see independent_framework02.json. All recorded initial/final checkpoint IDs are present in their read-only checkpoint SQLite databases (independent_checkpoint02.json).
- Offline mutations: 40 of 40 are rejected, including incorrect caller completion/identity/scope, malformed epoch types, missing relay evidence, missing or wrong execute receipts, altered authority/ticket bindings, inserted post-fence effect, missing or corrupted framework output, incorrect worker/checkpoint/interrupt identity, altered action, missing barrier, wrong observation cutoff and erased live effects. Consistent wrong-root and wrong-epoch changes across duplicated evidence are also rejected without relying on a database mismatch. See independent_mutations03.json and the executable mutation definitions.
- The mutation suite first verifies its native and corrected direct baselines pass. Layer-focused mutations must fail the intended verdict, avoiding rejection merely because of an unrelated missing field.

## Source correspondence

SHA-256 for both copied and historical gateway.py:
98445edd61af21bc5c740053f8a93f6c179e4c5efa7b28dd7363e779b8f059a9

SHA-256 for both copied and historical workflow.py:
c60b8c2013663ad65cbb90055f9e8652af6b5a789ca66683b1293b2308741397

## Remaining gate

The corrected native and direct qualification matrix is complete (12/12 passing). Candidate source files match the pre-run source_before_direct02 snapshot. The independent checker was still being authored during qualification; this is not a frozen measured collection. Before measured collection, freeze the protocol, candidate, independent checker and tests with source hashes. No measured campaign is authorized by this review document. Report only bounded conformance of this caller/workflow/local-sink fixture: not production latency, exposure probability, arbitrary crash recovery, global quiescence, generic authority targeting, new revocation mechanism or deployment readiness.
