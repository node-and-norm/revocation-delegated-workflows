"""Independent trace oracle. Imports no candidate implementation modules."""
import json, sqlite3, sys, copy, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
GOOD={'outcome':'revocation','root':'rootR','withdrawn_epoch':7,'new_epoch':8}
ARGS={'to':['synthetic@example.invalid'],'subject':'Synthetic summary','body':'inert summary','cc':[]}
BINDING={'principal':'childC','grant':'child-1','parent_grant':'parent-0','parent_principal':'parentP','root':'rootR','epoch':7,'scope':'summary:task1','ticket':'ticket-1','action':'send_email','args':ARGS}
EFFECT={'outcome':'effect','effect_key':'summary:task1','payload':'inert summary','root':'rootR','epoch':7}
DENIED={'outcome':'denied','reason':'revoked'}
def same(a,b):
    return json.dumps(a,sort_keys=True,separators=(',',':'))==json.dumps(b,sort_keys=True,separators=(',',':'))
def read_db(path):
    with sqlite3.connect(f'file:{path}?mode=ro',uri=True) as c:
        c.row_factory=sqlite3.Row
        out={t:[dict(r) for r in c.execute('SELECT * FROM '+t)] for t in ('authority','grants','tickets','events','effects')}
    for e in out['events']:e['data']=json.loads(e['data'])
    return out

def check(d,db=None):
    errs={k:[] for k in ('caller_knowledge','sink_effect','framework_path','completeness')}
    def ck(ok,group,msg):
        if not ok:errs[group].append(msg)
    try:
        s=d['schedule']; path=d['path']; ck(s in ['S'+str(i) for i in range(6)],'completeness','unknown schedule')
        ck(path in ('direct','framework'),'completeness','unknown path')
        fenced=s in ('S1','S2','S3','S4'); live=s in ('S0','S2','S5'); completed=s in ('S1','S2','S3')
        expected_state='IDLE' if s=='S0' else 'INSTALLED_CONFIRMED' if completed else 'UNCONFIRMED_AT_OBSERVATION_END'
        envelope={'kind':'completion','request_id':'withdrawal-1','root':'rootR','withdrawn_epoch':7,'new_epoch':8,'status':'installed','scope':'single_local_sink','gateway_response':GOOD}
        # Evidence-derived caller replay is independent of schedule expectations.
        state='IDLE'; rid=None; visible=[]
        for t in d['caller_trace']:
            m=t['input']; ck(t['before']==state,'caller_knowledge','incorrect transition before state')
            old=state; kind=m.get('kind');visible.append(m)
            if state not in ('IDLE','PENDING'):raise ValueError('caller trace continues after terminal state')
            if state=='IDLE' and kind=='issue' and isinstance(m.get('request_id'),str) and m['request_id']:
                rid=m['request_id']; state='PENDING'
            elif state=='PENDING' and same(m,{'kind':'accepted_volatile','request_id':rid}):pass
            elif state=='PENDING' and kind=='completion':
                exp=dict(envelope,request_id=rid);state='INSTALLED_CONFIRMED' if same(m,exp) else 'INVALID_RESPONSE'
            elif state=='PENDING' and same(m,{'kind':'observation_end'}):state='UNCONFIRMED_AT_OBSERVATION_END'
            else:state='INVALID_RESPONSE'
            ck(t['after']==state,'caller_knowledge','unsupported caller transition '+old+' -> '+str(t['after']))
        ck(state==d['caller_state'],'caller_knowledge','stored state differs from replay')
        ck(state==expected_state,'caller_knowledge','schedule terminal state mismatch')
        exp_visible=[] if s=='S0' else [{'kind':'issue','request_id':'withdrawal-1'},{'kind':'accepted_volatile','request_id':'withdrawal-1'},envelope if completed else {'kind':'observation_end'}]
        ck(same(visible,exp_visible),'caller_knowledge','caller input sequence or fields mismatch')
        rt=[] if s=='S0' else [{'event':'accepted_volatile','request_id':'withdrawal-1'}]
        if fenced:rt += [{'event':'send_intent','request':{'id':'withdrawal-1','op':'revoke','claim':'controller'}},{'event':'gateway_response_received','response':GOOD}]
        if completed:rt += [{'event':'completion_forwarded','message':envelope}]
        ck(same(d['relay_trace'],rt),'caller_knowledge','relay provenance/sequence mismatch')
        sink=d['sink'];ev=sink['events']; ef=sink['effects']
        if db is not None:ck(same(sink,db),'sink_effect','record differs from read-only authoritative database')
        ck(d['prior_effect'] is False,'completeness','prior effect is not excluded')
        ck([e['seq'] for e in ev]==list(range(1,len(ev)+1)),'sink_effect','non-contiguous event sequence')
        execute_id='resume-execute' if path=='framework' else 'execute-1'
        reqs=[('parentP',{'id':'delegate','op':'delegate','claim':'parentP','grant':'parent-0','scope':'summary:task1','child':'childC'}),('childC',{'id':'prepare','op':'prepare','claim':'childC','grant':'child-1','scope':'summary:task1'})]
        ex=('childC',{'id':execute_id,'op':'execute','claim':'childC','grant':'child-1','scope':'summary:task1','ticket':'ticket-1','payload':'inert summary'})
        rev=('controller',{'id':'withdrawal-1','op':'revoke','claim':'controller'})
        reqs += ([rev,ex] if s in ('S1','S3','S4') else [ex,rev] if s=='S2' else [ex])
        expected_receipts=[{'actor':a,'request':r} for a,r in reqs]
        ck(same([e['data'] for e in ev if e['kind']=='receipt'],expected_receipts),'sink_effect','gateway receipt identity/count/order/binding mismatch')
        ck(len(ev)==1+2*len(reqs),'sink_effect','gateway event count mismatch')
        outcomes={}
        for i,(actor,req) in enumerate(reqs):
            receipt,outcome=ev[1+i*2:3+i*2]
            ck(receipt['kind']=='receipt' and same(receipt['data'],expected_receipts[i]),'sink_effect','receipt pairing mismatch')
            ck(outcome['data']['request_id']==req['id'],'sink_effect','terminal request identity mismatch')
            result=outcome['data']['result']; outcomes[req['op']]=outcome
            ck(outcome['kind']==result['outcome'],'sink_effect','outcome kind mismatch')
        ck(same(outcomes['execute']['data']['result'],EFFECT if live else DENIED),'sink_effect','wrong execute terminal result')
        ck(same(d['execute_response'],outcomes['execute']['data']['result']),'sink_effect','returned execute result differs from gateway')
        if fenced:ck(same(outcomes['revoke']['data']['result'],GOOD),'sink_effect','invalid committed revocation')
        ck(same(d['grant'],outcomes['delegate']['data']['result']) and same(d['admission'],outcomes['prepare']['data']['result']),'sink_effect','setup outcome mismatch')
        expected_effects=[] if not live else [{'event_seq':outcomes['execute']['seq'],'effect_key':'summary:task1','payload':'inert summary','root':'rootR','epoch':7}]
        ck(same(ef,expected_effects),'sink_effect','effect history/count/binding mismatch')
        if fenced:ck(all(x['event_seq']<outcomes['revoke']['seq'] for x in ef),'sink_effect','post-fence old-authority effect')
        ck(same(sink['authority'],[{'root':'rootR','epoch':8 if fenced else 7,'active':0 if fenced else 1}]),'sink_effect','authority state mismatch')
        ck(same(sink['grants'],[{'token':'parent-0','owner':'parentP','root':'rootR','epoch':7,'scope':'summary:task1','can_delegate':1},{'token':'child-1','owner':'childC','root':'rootR','epoch':7,'scope':'summary:task1','can_delegate':0}]),'sink_effect','grant lineage mismatch')
        ck(same(sink['tickets'],[{'token':'ticket-1','grant_token':'child-1','owner':'childC','scope':'summary:task1'}]),'sink_effect','ticket binding mismatch')
        names={'S0':['execute_terminal','terminal_observation'],'S1':['accepted','fence_installed','completion_observed','execute_terminal','terminal_observation'],'S2':['accepted','execute_terminal','fence_installed','completion_observed','terminal_observation'],'S3':['accepted','fence_installed','execute_terminal','completion_observed','terminal_observation'],'S4':['accepted','fence_installed','execute_terminal','terminal_observation'],'S5':['accepted','execute_terminal','terminal_observation']}[s]
        bars=d['barriers'];ck([b['name'] for b in bars]==names,'completeness','barrier order/cutoff mismatch')
        last=0
        for b in bars:
            events=b['committed_events'];n=len(events)
            ck(n>=last and same(events,ev[:n]),'completeness','barrier is not monotone committed prefix');last=n
            ck(same(b['effects'],[x for x in ef if x['event_seq']<=n]),'sink_effect','barrier effect snapshot mismatch')
            name=b['name']; expected_n=5 if name=='accepted' else outcomes['execute']['seq'] if name=='execute_terminal' else outcomes['revoke']['seq'] if name=='fence_installed' else len(ev) if name=='terminal_observation' else (outcomes['revoke']['seq'] if s=='S1' else len(ev))
            ck(n==expected_n,'completeness','wrong committed cutoff at '+name)
            expected_cs=expected_state if name=='terminal_observation' else 'IDLE' if s=='S0' else 'INSTALLED_CONFIRMED' if name=='completion_observed' or (s=='S1' and name=='execute_terminal') else 'PENDING'
            ck(b['caller_state']==expected_cs,'caller_knowledge','caller state at barrier '+name)
        ck(same(bars[-1]['committed_events'],ev),'completeness','terminal cutoff differs from final sink')
        ck(d['gateway_exitcode']==0 and d['shutdown']=={'ok':True},'completeness','gateway cleanup incomplete')
        ws=d['workers']
        if path=='direct':ck(ws==[],'framework_path','unexpected direct workers')
        else:
            ck(len(ws)==2,'framework_path','missing pause/resume worker');a,b=ws
            ck(a['phase']=='pause' and b['phase']=='resume' and a['pid']!=b['pid'],'framework_path','fresh worker process evidence invalid')
            ck(all(w['ok'] is True and w['exitcode']==0 and same(w['binding'],BINDING) for w in ws),'framework_path','worker/binding failure')
            ck(a['checkpoint_after']==b['checkpoint_before']==b['restored_state']['config'],'framework_path','checkpoint not restored')
            ck(a['pending']==b['restored_interrupts'] and len(a['pending'])==1,'framework_path','pending interrupt mismatch')
            action=a['pending'][0]['value']['action_requests'];ck(len(action)==1 and action[0]['name']=='send_email' and same(action[0]['args'],ARGS),'framework_path','restored action mismatch')
            ck(b['pending']==[],'framework_path','resume still interrupted')
            ck(not [t for t in a['trace'] if t.get('kind') in ('tool_entry','tool_response')],'framework_path','execute occurred before pause')
            entries=[t for t in b['trace'] if t.get('kind')=='tool_entry'];responses=[t for t in b['trace'] if t.get('kind')=='tool_response']
            ck(len(entries)==1 and same(entries[0],{'kind':'tool_entry','action':'send_email','args':ARGS,'binding':BINDING}),'framework_path','tool entry missing or unbound')
            ck(len(responses)==1 and same(responses[0]['request'],ex[1]) and same(responses[0]['result'],d['execute_response']),'framework_path','tool response identity/result mismatch')
            final=b['result']['messages'][-1];ck(final['type']=='ai' and same(json.loads(final['content']),d['execute_response']),'framework_path','final supervisor output does not propagate exact result')
            ck(bool(a['models']) and bool(b['models']),'framework_path','missing model trace')
    except (KeyError,ValueError,TypeError,IndexError) as e:errs['completeness'].append('malformed or missing evidence: '+repr(e))
    return {'passed':not any(errs.values()),'verdicts':{k:not v for k,v in errs.items()},'errors':errs}

if __name__=='__main__':
    results=[]
    for arg in sys.argv[1:]:
        p=Path(arg);d=json.loads(p.read_text());r=check(d,read_db(p.parent/'sink.sqlite'));r['record']=str(p);results.append(r)
    print(json.dumps(results,indent=2));sys.exit(0 if results and all(r['passed'] for r in results) else 1)
