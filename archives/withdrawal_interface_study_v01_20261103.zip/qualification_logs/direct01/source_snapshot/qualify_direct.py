"""Direct instrument qualification only. Not measured framework campaign."""
import json,multiprocessing as mp,sqlite3,sys
from pathlib import Path
from gateway import gateway_main
from caller import Caller
from relay import Relay
CTX=mp.get_context('spawn')
def call(pipe,req):
    pipe.send(req)
    if not pipe.poll(20):raise TimeoutError(req)
    return pipe.recv()
def snapshot(path):
    with sqlite3.connect(f'file:{path}?mode=ro',uri=True) as c:
        c.row_factory=sqlite3.Row
        d={t:[dict(r) for r in c.execute('SELECT * FROM '+t)] for t in ('authority','grants','tickets','events','effects')}
    for e in d['events']:e['data']=json.loads(e['data'])
    return d

def run(folder,schedule):
    folder.mkdir(); control,cg=CTX.Pipe();parent,pg=CTX.Pipe();child,ch=CTX.Pipe()
    proc=CTX.Process(target=gateway_main,args=(str(folder/'sink.sqlite'),'commit_fenced',cg,pg,ch));proc.start()
    assert control.poll(20) and control.recv()=={'ok':True}
    caller=Caller();relay=Relay();barriers=[]
    record={'kind':'qualification','schedule':schedule,'path':'direct','prior_effect':False}
    def barrier(name):
        snap=snapshot(folder/'sink.sqlite')
        barriers.append({'name':name,'committed_events':snap['events'],'effects':snap['effects'],'caller_state':caller.state})
    try:
        record['grant']=call(parent,{'id':'delegate','op':'delegate','claim':'parentP','grant':'parent-0','scope':'summary:task1','child':'childC'})
        record['admission']=call(child,{'id':'prepare','op':'prepare','claim':'childC','grant':'child-1','scope':'summary:task1'})
        assert record['grant']['outcome']=='grant' and record['admission']['outcome']=='admission'
        if schedule!='S0':
            caller.accept({'kind':'issue','request_id':'withdrawal-1'});caller.accept(relay.submit('withdrawal-1'));barrier('accepted')
        if schedule in ('S1','S3','S4'):
            relay.deliver(control);barrier('fence_installed')
        if schedule=='S1':caller.accept(relay.completion());barrier('completion_observed')
        req={'id':'execute-1','op':'execute','claim':'childC','grant':'child-1','scope':'summary:task1','ticket':'ticket-1','payload':'inert summary'}
        record['execute_response']=call(child,req);barrier('execute_terminal')
        if schedule=='S2':relay.deliver(control);barrier('fence_installed')
        if schedule in ('S2','S3'):caller.accept(relay.completion());barrier('completion_observed')
        if schedule in ('S4','S5'):caller.accept({'kind':'observation_end'})
        barrier('terminal_observation')
        record.update(caller_trace=caller.trace,caller_state=caller.state,relay_trace=relay.trace,barriers=barriers,sink=snapshot(folder/'sink.sqlite'))
    finally:
        record['shutdown']=call(control,{'op':'stop'});proc.join(10);record['gateway_exitcode']=proc.exitcode
        (folder/'record.json').write_text(json.dumps(record,indent=2))
    return record
if __name__=='__main__':
    root=Path(sys.argv[1]);root.mkdir(exist_ok=False)
    for s in ('S0','S1','S2','S3','S4','S5'):run(root/s,s)
