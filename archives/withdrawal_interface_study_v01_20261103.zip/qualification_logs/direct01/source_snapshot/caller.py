"""Caller knows only its request and messages received from relay."""
from copy import deepcopy

class Caller:
    def __init__(self):
        self.state='IDLE'; self.request_id=None; self.trace=[]
    def accept(self, message):
        before=self.state; m=deepcopy(message)
        if self.state in ('INSTALLED_CONFIRMED','UNCONFIRMED_AT_OBSERVATION_END','INVALID_RESPONSE'):
            raise ValueError('terminal state: late messages excluded')
        kind=m.get('kind')
        if kind=='issue' and self.state=='IDLE' and isinstance(m.get('request_id'),str) and m['request_id']:
            self.request_id=m['request_id']; self.state='PENDING'
        elif kind=='accepted_volatile' and self.state=='PENDING' and m=={'kind':'accepted_volatile','request_id':self.request_id}:
            pass
        elif kind=='completion' and self.state=='PENDING':
            expected={'kind':'completion','request_id':self.request_id,'root':'rootR','withdrawn_epoch':7,'new_epoch':8,'status':'installed','scope':'single_local_sink','gateway_response':{'outcome':'revocation','root':'rootR','withdrawn_epoch':7,'new_epoch':8}}
            self.state='INSTALLED_CONFIRMED' if m==expected else 'INVALID_RESPONSE'
        elif kind=='observation_end' and self.state=='PENDING' and m=={'kind':'observation_end'}:
            self.state='UNCONFIRMED_AT_OBSERVATION_END'
        else:
            self.state='INVALID_RESPONSE'
        self.trace.append({'input':m,'before':before,'after':self.state})
        return self.state
