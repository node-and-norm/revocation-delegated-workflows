# Node & Norm Q1: deterministic revocation instrument qualification

Version 0.1.0. This is **instrument qualification, not a new research finding**, not a SOUNDGATE replication, and not evidence that an existing source, model, framework, or deployed system is safe or vulnerable.

## Observed result

The final source in `runs/attempt03/source/` passed 18 unit/control tests and ten finite arm × schedule fixtures matched their declared expectations. Exact source SHA-256 hashes are in `runs/attempt03/runtime.json` and `qualification_summary.json`. The intentionally defective admission-only arm produced a newly committed protected effect after revocation in C1, C2 and C3. The commit-fenced arm produced no protected effects in those schedules. Both arms produced one effect in the no-revocation positive control and the legitimate pre-fence / late-ack control. These are fixture counts, not estimated failure rates, confidence intervals, or independent population samples. C3 is a continuation of one prepared job, not three samples.

## Boundary and mechanism

One synthetic task, root authority `rootR`, and grant epoch 7 authorize one logical effect `summary:task1` with the inert payload `inert summary`. Full revocation atomically changes authority to inactive and advances its epoch to 8. There is no regrant, alternate root, external sink, actual user data, model API, network action, or installation.

The endpoint is **no new protected SQLite commit after the revocation commit**, not “no attempt” or “no late acknowledgement.” Both implementations receive the same prepared ticket, payload, effect key, and causal schedule. Admission-only uses its earlier admission result without revalidation: this is a seeded conventional stale-authority race. Commit-fenced takes a SQLite `BEGIN IMMEDIATE` write transaction, reads active authority and epoch, and inserts the effect in that same transaction. Revocation uses `BEGIN IMMEDIATE` on the same database. SQLite write serialization supplies the common transaction domain; this says nothing about nontransactional or remote effects.

Each event is stored transactionally. The effect event and sink row are in the same transaction; the revocation event and authority update are in the same transaction. Thus their event sequence numbers establish committed order within this fixture. Attempt and acknowledgement events are separate transactions. Admission and preparation are distinct events in one transaction. A unique sink effect key enforces one logical effect, so retries cannot create extra rows.

## Prepared schedules

| Case | Causal schedule | Expected admission-only | Expected commit-fenced |
|---|---|---|---|
| C0 | Admit → prepare → attempt → effect → ack, no revoke | 1 effect, no violation | 1 effect, no violation |
| C1 | Admit → prepare → revoke commit → single-worker attempt → outcome → ack | 1 post-fence effect | Denied, 0 effects |
| C2 | Admit/prepare in worker A → worker A exits → ticket transfers to worker B → revoke commit → attempt → outcome → ack | 1 post-fence effect | Denied, 0 effects |
| C3 | Admit → prepare → revoke commit → three sequential attempts with same ticket/key, each followed by ack | 1 post-fence effect, then 2 duplicate outcomes | 3 denials, 0 effects |
| C4 | Admit → prepare → attempt → effect commit → revoke commit → late ack | 1 legitimate pre-fence effect | 1 legitimate pre-fence effect |

Multiprocessing `spawn` creates workers and a separate read-only observer. Bidirectional pipe request/response barriers order operations. There are no sleep-based race assumptions. Ten-second bounds detect infrastructure hangs, not causal timing. The observer snapshots actual committed database rows after each relevant barrier using a read transaction and a read-only database connection. It does not call or import the enforcement predicate. `oracle.py` separately evaluates final observed event order, sink/event agreement, completeness, authority state and the post-fence endpoint. It does not call gate code. The observer and oracle are not a trusted-hardware or tamper-proof monitor; same-host malicious interference is outside scope.

C2 is a controller-mediated process handoff, not a descendant delegation topology. Worker enforcement code is trusted and has direct database access; it is not an adversarial, separately confined actor. The source design’s external gateway and no-direct-worker-credentials conditions are not implemented. This is narrower transaction/oracle qualification, not full specification conformance or external-mediation validation.

## Controls and failure accounting

`test_oracle.py` supplies hand-derived traces with expected **semantic labels**, not merely matching hashes: a positive violation, denial, positive liveness, pre-fence effect with late ack, missing ack, duplicate event, reordered fence, missing sink event, unlogged sink row, wrong payload and missing fence. Synthetic timeout and observer-error injections must return `INCOMPLETE` and exit nonzero, never a pass. They test error propagation, not all OS failure modes. The process timeout is bounded; failure and incomplete status do not establish safety.

A `QUALIFIED` run means expected failures were detected as well as expected permitted behavior. A seeded `VIOLATION` is therefore a successful detector control, not a successful safety test. Actual exceptions, missing evidence and unexpected outcomes fail qualification or make it incomplete. Every real run uses a fresh output directory; earlier runs cannot be overwritten. Every run stores exact source snapshots and source hashes with runtime metadata. No initial execution/test failures occurred in attempt01. Separate AI-assisted review (not independent human validation) then exposed oracle false passes for duplicate-without-prior-effect, unknown attempt outcomes, wrong prepared binding, and boolean sequence numbers. Those counterexamples and the original source are preserved; attempt03 adds strict schema, count, binding and duplicate-provenance checks plus regression tests. A subsequent defensive cleanup change ensures all child processes are considered for termination even if one cleanup fails; the original passing source and results remain preserved in attempt01. Attempt02 preserves the pre-review cleanup revision; attempt03 is the post-review source verification. Synthetic failure-injection stack traces in test logs are intentional controls, not hidden failed runs.

## Reproduce

Use installed Python 3 with its standard-library SQLite and multiprocessing support. No dependency install is needed. From this directory:

```sh
python -m unittest -v
python harness.py --output runs/your_unique_run_name
```

The output path must not exist. Exit 0 means all declared fixture expectations matched. Inspect `results.json`, `runtime.json`, the individual fixture JSON files (final observer trace and intermediate snapshots), and SQLite databases. Exact interpreter/SQLite/platform versions are recorded per run. Run-to-run OS identifiers and runtime metadata need not be byte-identical; expected event semantics are deterministic.

`MANIFEST.sha256` records packaged file hashes (excluding itself, the ZIP, and Python bytecode). Hashes provide artifact integrity, not correctness. The package contains no research claims beyond this bounded qualification.

## Limits and stopping condition

This finite deterministic qualification is complete after execution, oracle controls, independent review, and packaging. It does not exhaust thread interleavings, crash durability scenarios, partitions, remote services, hostile principals, admission-denial cases, delegated authority hierarchies, mixed roots, partial revocation, lease expiry, regrant, adaptive models, or distributed revocation. No failure-rate or universal full-mediation claim is warranted. Future research requires separate design and authorization; this harness is not an autonomous continuation into those experiments.

## Separate AI-assisted review

`independent_review/REVIEW.md` clears the corrected finite qualification, preserving four initial oracle counterexamples, old replay output, corrected replay, scripts and checks. The corrected review ran 18 unit tests, ten fixtures, 74 oracle correction/deletion assertions, and 36 direct-database/observer assertions. These overlapping engineering counts are not independent samples or human validation.

Reviewer scripts originally ran in a sibling directory. Their source is preserved unchanged. In this self-contained package, run them from the package root with the root on `PYTHONPATH`, for example:

```sh
PYTHONPATH="$PWD" PYTHONDONTWRITEBYTECODE=1 python independent_review/recheck_oracle.py
```

The source-import fallback works through `PYTHONPATH`; raw review fixtures remain relative to each review script. Historical logs retain original execution paths and original source hashes.
