"""Independent source/replay review; standard library, finite fixtures only."""
import json
import multiprocessing as mp
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'qualification_revocation_v01'))
import harness

def main():
    checks = []
    def check(name, value):
        checks.append({'check': name, 'passed': bool(value)})
    for p in sorted((ROOT/'replay01').glob('*.sqlite3')):
        arm, case = p.stem.rsplit('_', 1)
        c = sqlite3.connect(f'file:{p}?mode=ro', uri=True)
        rows = c.execute('SELECT event_seq,effect_key,payload,root,epoch FROM effects').fetchall()
        fence = c.execute("SELECT seq FROM events WHERE kind='revocation'").fetchall()
        expected = 0 if arm == 'commit_fenced' and case in ('C1','C2','C3') else 1
        check(p.stem + ': independently counted sink rows', len(rows) == expected)
        post = [r for r in rows if fence and r[0] > fence[0][0]]
        check(p.stem + ': post-fence sink effects', len(post) == (1 if arm == 'admission_only' and case in ('C1','C2','C3') else 0))
        check(p.stem + ': exact inert payload and one logical key', all(r[1:] == ('summary:task1','inert summary','rootR',7) for r in rows))
        if case == 'C4':
            ack = c.execute("SELECT seq FROM events WHERE kind='ack'").fetchone()[0]
            check(p.stem + ': effect before fence before ack', rows[0][0] < fence[0][0] < ack)
        c.close()
    missing = ROOT/'missing_observer.sqlite3'
    check('missing database precondition', not missing.exists())
    ctx = mp.get_context('spawn')
    p, pipe = harness.launch(ctx, harness.observer, missing)
    check('missing database observer responds', pipe.poll(5))
    response = pipe.recv()
    check('missing database observer explicitly errors', response.get('ok') is False and 'OperationalError' in response.get('error',''))
    p.join(5)
    check('failed observer terminates', not p.is_alive())
    pipe.close()
    (ROOT/'independent_checks.json').write_text(json.dumps({'checks':checks,'passed':sum(x['passed'] for x in checks),'total':len(checks)},indent=2)+'\n')
    print(json.dumps({'passed':sum(x['passed'] for x in checks),'total':len(checks)}))
    return 0 if all(x['passed'] for x in checks) else 1

if __name__ == '__main__':
    raise SystemExit(main())
