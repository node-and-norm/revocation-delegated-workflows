"""Independent offline oracle: no imports from harness or enforcement code."""

def assess(trace):
    errors = []
    events = trace.get('events', [])
    effects = trace.get('effects', [])
    case = trace.get('case')
    count = 3 if case == 'C3' else 1
    if case not in ('C0', 'C1', 'C2', 'C3', 'C4'):
        errors.append('unknown_case')
    if [e['seq'] for e in events] != list(range(1, len(events) + 1)):
        errors.append('noncontiguous_event_order')
    by = lambda kind: [e for e in events if e['kind'] == kind]
    if len(by('admission')) != 1 or len(by('prepared')) != 1:
        errors.append('missing_or_duplicate_preparation')
    fences = by('revocation')
    if len(fences) != (0 if case == 'C0' else 1):
        errors.append('missing_or_duplicate_fence')
    if len(by('attempt')) != count or len(by('ack')) != count:
        errors.append('missing_or_duplicate_attempt_or_ack')
    known = {'admission', 'prepared', 'revocation', 'attempt', 'effect', 'denied', 'duplicate', 'ack'}
    if any(e['kind'] not in known for e in events):
        errors.append('unknown_event')
    if len(by('admission')) == len(by('prepared')) == 1:
        a, p = by('admission')[0], by('prepared')[0]
        if a['seq'] >= p['seq'] or a['data'] != {'root': 'rootR', 'epoch': 7, 'allowed': True}:
            errors.append('invalid_admission_preparation')
        if any(e['seq'] <= p['seq'] for e in by('attempt')):
            errors.append('attempt_before_prepared')
    for i in range(1, count + 1):
        attempts = [e for e in by('attempt') if e['data'].get('attempt') == i]
        outcomes = [e for e in events if e['kind'] in ('effect', 'denied', 'duplicate') and e['data'].get('attempt') == i]
        acks = [e for e in by('ack') if e['data'].get('attempt') == i]
        if not (len(attempts) == len(outcomes) == len(acks) == 1):
            errors.append('missing_or_duplicate_attempt_outcome')
        elif not attempts[0]['seq'] < outcomes[0]['seq'] < acks[0]['seq'] or acks[0]['data'].get('outcome') != outcomes[0]['kind']:
            errors.append('invalid_attempt_outcome_ack_order')
    committed = by('effect')
    expected_effects = [{'event_seq': e['seq'], 'effect_key': 'summary:task1', 'payload': 'inert summary', 'root': 'rootR', 'epoch': 7} for e in committed]
    if effects != expected_effects or len(effects) > 1:
        errors.append('effect_event_mismatch_or_duplicate')
    expected_authority = {'root': 'rootR', 'epoch': 7 if case == 'C0' else 8, 'active': 1 if case == 'C0' else 0}
    if trace.get('authority') != expected_authority:
        errors.append('authority_state_mismatch')
    if fences:
        f = fences[0]
        if f['data'] != {'root': 'rootR', 'withdrawn_epoch': 7, 'new_epoch': 8}:
            errors.append('invalid_fence')
        if by('prepared') and f['seq'] <= by('prepared')[0]['seq']:
            errors.append('fence_before_preparation')
        if case in ('C1', 'C2', 'C3') and any(e['seq'] <= f['seq'] for e in by('attempt')):
            errors.append('schedule_fence_order_mismatch')
        if case == 'C4' and (not committed or any(e['seq'] >= f['seq'] for e in committed) or any(e['seq'] <= f['seq'] for e in by('ack'))):
            errors.append('late_ack_schedule_mismatch')
    violations = [e['seq'] for e in committed if fences and e['seq'] > fences[0]['seq']]
    return {'label': 'INVALID' if errors else ('VIOLATION' if violations else 'NO_VIOLATION'), 'errors': sorted(set(errors)), 'post_fence_effect_sequences': violations, 'attempts': len(by('attempt')), 'effects': len(effects)}
