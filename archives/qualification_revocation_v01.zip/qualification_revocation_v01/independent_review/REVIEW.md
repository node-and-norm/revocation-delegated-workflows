# Independent AI review: deterministic revocation qualification

## Decision

**No remaining blocker for the stated finite instrument qualification after correction.** This is not a finding about a deployed framework, hostile AI, distributed revocation, statistical safety, or universal full mediation. The reviewer did not modify implementer files. No installation, network action, model API, or external effect was used.

## What was checked

Source inspection confirms the commit-fenced arm begins `BEGIN IMMEDIATE`, reads the authority epoch/active flag, and inserts the protected effect inside that same transaction. Revocation updates the authority and records its event in another `BEGIN IMMEDIATE` transaction on the same SQLite database. Therefore write serialization establishes the relevant commit order in this trusted local fixture. The effect event and effect row are atomic together. Admission, attempted execution, final committed effect and acknowledgement are distinct records; an acknowledgement after revocation is not counted as a post-revocation effect.

Pipe request/response barriers wait for transaction completion before advancing the prepared schedule; there are no sleep-derived ordering assumptions. The observer is a separate process with a read-only connection and a snapshot transaction. It reads actual sink rows rather than accepting worker success reports. Its code does not invoke the enforcement predicate. The offline oracle is separately implemented, but all components remain same-host trusted fixture code, not authenticated or independently anchored evidence.

## Initial findings and preserved failures

Initial independent replay reproduced the 10 expected arm-by-schedule results and all 13 original tests. Independent adversarial controls then found four admissibility false passes, preserved verbatim in `counterexamples01.json`:

1. A duplicate outcome without any previous effect returned NO_VIOLATION with zero effects, which could satisfy the fenced qualification's label/count check.
2. An extra unmatched denial with attempt ID 999 was accepted.
3. A preparation record naming the wrong key/payload was accepted.
4. Boolean `True` was accepted as event sequence integer 1.

These are defects in the finite evidence oracle, **not demonstrated failures of the transaction gate**. The implementer corrected schema/type validation, preparation binding, outcome/attempt coverage, duplicate prerequisites and sequential retry order. Earlier source snapshots and passing runs remain preserved and must not be described as having passed these later controls.

## Correction verification

On the corrected source:

- **18/18 implementer unit tests** passed, including known-positive violation, no-revocation liveness, late acknowledgement, malformed/missing evidence and mocked timeout/observer-error propagation.
- **10/10 arm × prepared-schedule fixtures** matched expected labels/effect counts in a new reviewer run (`replay02`). Admission-only generated the seeded post-revocation effect in C1/C2/C3. Commit-fenced generated none there. Both arms generated one legitimate effect in C0 and C4.
- **74/74 reviewer oracle checks** passed: four preserved false-pass examples now INVALID, plus 70 single-event deletions with event sequences renumbered. These latter controls retain original sink rows and test completeness of each declared finite schedule; they are not exhaustive corruption detection.
- **36/36 reviewer checks** passed: direct read-only SQLite inspection of ten saved sink results and their order, exact inert payloads/key, both C4 effect-before-fence-before-ack cases, plus an actual separate observer process given a nonexistent database. The failed observer explicitly returned OperationalError and terminated. This supplements, but does not replace, the mocked pipeline-error controls.
- Re-running the saved reviewer oracle script reproduced the saved correction report byte-for-byte.

Counts overlap and are engineering assertions, **not independent research samples**, statistical estimates, or additional case populations. C3 has three attempts of one logical operation; it is not three independent observations. Replay confirms deterministically prepared schedules, not unexplored concurrent interleavings.

## Commands and artifacts

Executed from `/workspace/scratch/c5555b5962f8` unless noted:

```sh
# Initial and corrected runs, respectively; executed from qualification_revocation_v01:
PYTHONDONTWRITEBYTECODE=1 python -m unittest -v > ../qualification_revocation_review/upstream_tests.log 2>&1
PYTHONDONTWRITEBYTECODE=1 python harness.py --output ../qualification_revocation_review/replay01 > ../qualification_revocation_review/replay01.log 2>&1
PYTHONDONTWRITEBYTECODE=1 python -m unittest -v > ../qualification_revocation_review/corrected_tests.log 2>&1
PYTHONDONTWRITEBYTECODE=1 python harness.py --output ../qualification_revocation_review/replay02 > ../qualification_revocation_review/replay02.log 2>&1

# Reviewer scripts from workspace root:
PYTHONDONTWRITEBYTECODE=1 python qualification_revocation_review/review_checks.py
PYTHONDONTWRITEBYTECODE=1 python qualification_revocation_review/review_checks_corrected.py
PYTHONDONTWRITEBYTECODE=1 python qualification_revocation_review/recheck_oracle.py > qualification_revocation_review/correction_reproduction.json
cmp qualification_revocation_review/correction_checks.json qualification_revocation_review/correction_reproduction.json
```

Source SHA-256 for final reviewer replay (`replay02/source`):

- harness.py: `30278f4c3a4e019f9dfc4ed970c22796a1eb224ebe6b521088a39c87b780fc0b`
- oracle.py: `fdb3f6e4532684a79d36adb1317f1f282929d3a34733cddd968a6b17c0dc5497`
- test_oracle.py: `3037ce22b4c8684107ca16b2d314872f869b2dd857b8f70213682aed85af7c58`

## Essential limitations

C2 is a **controller-mediated process handoff**, not an actual descendant spawning/delegation topology. The trusted worker contains the gate and has write access to the database: this does not establish containment of a malicious worker or an external non-bypassable reference monitor. The protected effect is an inert SQLite row, not a remote API, financial transaction or physical action. There is one root, no regrant, one effect key and no partial revocation. Missing/corrupt observer evidence is not a clean safety result. End-to-end crashes, storage failures and all timeout modes are untested. An observer and offline oracle cannot independently authenticate a coherently falsified same-host database; that adversary is out of scope.

The intentional admission-only defect is a seeded conventional stale-authority example, not a discovered vulnerability or AI-specific failure. Review is separate AI-assisted source/testing work, not independent human validation. Stop at qualification and correction verification; subsequent research requires its own question and design.
