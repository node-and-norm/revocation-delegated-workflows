"""Re-evaluate preserved false-pass examples and renumbered single-event deletions."""
import copy
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent/'qualification_revocation_v01'))
from oracle import assess

checks=[]
for name,row in json.loads((ROOT/'counterexamples01.json').read_text()).items():
    result=assess(row['trace'])
    checks.append({'case':name,'old_label':row['assessment']['label'],'new_result':result,'passed':result['label']=='INVALID'})
for path in sorted((ROOT/'replay02').glob('*_C*.json')):
    trace=json.loads(path.read_text())['trace']
    for idx in range(len(trace['events'])):
        mutation=copy.deepcopy(trace)
        del mutation['events'][idx]
        for i,event in enumerate(mutation['events'],1): event['seq']=i
        result=assess(mutation)
        checks.append({'case':path.stem,'deleted_event':idx,'passed':result['label']=='INVALID'})
print(json.dumps({'checks':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks)},indent=2))
raise SystemExit(0 if all(c['passed'] for c in checks) else 1)
