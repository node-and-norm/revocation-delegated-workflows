# Integration pilot package

Extract this archive into an empty directory for a standalone runnable layout, or into the repository root to restore the raw evidence omitted from its compact source view. See `integration/v0.3/README.md` for environment setup, reproduction and limitations.

The package contains `integration/v0.3` source, protocol, qualification evidence, measured records, dependency locks/licenses and reviewer evidence. Tests depend on the included `integration/v0.3/evidence/restart_qualification01` fixture. `qualification/v0.2/gateway.py` is the byte-identical historical standard-library-only gateway dependency; this package does not claim to provide or rerun the complete old v0.2 qualification suite. No repository root README is overwritten.

The historical gateway remains alive during worker restarts. This package establishes only the documented bounded synthetic integration conformance. Existing measured source, protocol and result bytes are preserved. Packaging verification reruns tests and regrades recorded evidence; it does not add experimental runs.
