"""Independent real-IPC boundary controls for the finite trusted gateway."""
import json
import multiprocessing as mp
import sqlite3
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'qualification_revocation_v02'))
from gateway import gateway_main

def main():
    checks=[]
    def check(name,got,expected):checks.append({'name':name,'got':got,'expected':expected,'passed':got==expected})
    def recv(c):
        if not c.poll(10):raise TimeoutError('review IPC response missing')
        return c.recv()
    def rpc(c,r):c.send(r);return recv(c)
    out=ROOT/'ipc01';out.mkdir(exist_ok=False)
    for arm in ('admission_only','commit_fenced'):
        ctx=mp.get_context('spawn');gc,gs=ctx.Pipe();pc,ps=ctx.Pipe();cc,cs=ctx.Pipe();path=out/(arm+'.sqlite3')
        p=ctx.Process(target=gateway_main,args=(path,arm,gs,ps,cs));p.start()
        try:
            check(arm+': gateway ready',recv(gc),{'ok':True})
            def call(name,c,req,expected):check(arm+': '+name,rpc(c,{'id':name,**req}),expected)
            deny=lambda reason:{'outcome':'denied','reason':reason}
            call('child cannot invoke controller revoke',cc,{'op':'revoke','claim':'childC'},deny('operation_forbidden'))
            call('child cannot claim controller',cc,{'op':'revoke','claim':'controller'},deny('caller_mismatch'))
            call('child cannot use parent grant',cc,{'op':'prepare','claim':'childC','grant':'parent-0','scope':'summary:task1'},deny('foreign_grant'))
            call('unknown grant',cc,{'op':'prepare','claim':'childC','grant':'absent','scope':'summary:task1'},deny('unknown_grant'))
            call('parent cannot delegate different recipient',pc,{'op':'delegate','claim':'parentP','grant':'parent-0','scope':'summary:task1','child':'other'},deny('delegation_forbidden'))
            call('parent delegates child',pc,{'op':'delegate','claim':'parentP','grant':'parent-0','scope':'summary:task1','child':'childC'},{'outcome':'grant','grant':'child-1','owner':'childC','root':'rootR','epoch':7,'scope':'summary:task1','parent_grant':'parent-0'})
            call('parent cannot use child grant',pc,{'op':'prepare','claim':'parentP','grant':'child-1','scope':'summary:task1'},deny('foreign_grant'))
            call('child lacks redelegation right',cc,{'op':'delegate','claim':'childC','grant':'child-1','scope':'summary:task1','child':'childC'},deny('delegation_forbidden'))
            call('valid child admission',cc,{'op':'prepare','claim':'childC','grant':'child-1','scope':'summary:task1'},{'outcome':'admission','ticket':'ticket-1','grant':'child-1','root':'rootR','epoch':7,'scope':'summary:task1'})
            execute={'op':'execute','claim':'childC','grant':'child-1','scope':'summary:task1','ticket':'ticket-1','payload':'inert summary'}
            call('changed payload',cc,{**execute,'payload':'other'},deny('scope_expansion'))
            call('foreign ticket',cc,{**execute,'ticket':'other'},deny('invalid_ticket'))
            call('root revocation',gc,{'op':'revoke','claim':'controller'},{'outcome':'revocation','root':'rootR','withdrawn_epoch':7,'new_epoch':8})
            call('post-revoke new child grant rejected',pc,{'op':'delegate','claim':'parentP','grant':'parent-0','scope':'summary:task1','child':'childC'},deny('revoked'))
            call('stale child final effect',cc,execute,deny('revoked') if arm=='commit_fenced' else {'outcome':'effect','effect_key':'summary:task1','payload':'inert summary','root':'rootR','epoch':7})
            call('shutdown',gc,{'op':'stop'},{'ok':True});p.join(10);check(arm+': process exit',p.exitcode,0)
            c=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)
            check(arm+': independently counted sink rows',c.execute('SELECT COUNT(*) FROM effects').fetchone()[0],0 if arm=='commit_fenced' else 1);c.close()
        finally:
            if p.is_alive():p.terminate();p.join(10)
            for c in (gc,gs,pc,ps,cc,cs):c.close()
    result={'checks':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks)}
    (ROOT/'ipc_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'passed':result['passed'],'total':result['total']}))
    return 0 if all(c['passed'] for c in checks) else 1
if __name__=='__main__':raise SystemExit(main())
