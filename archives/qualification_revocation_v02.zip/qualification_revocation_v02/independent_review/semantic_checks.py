"""Independent finite evidence mutations and SQLite checks; no gate predicate reuse."""
import copy
import json
import sqlite3
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'qualification_revocation_v02'))
from oracle import assess, qualify

checks=[]
def check(name,passed,detail=None): checks.append({'name':name,'passed':bool(passed),'detail':detail})
for name,row in json.loads((ROOT/'counterexamples01.json').read_text()).items():
    result=qualify(row['trace'])
    check('preserved counterexample:'+name,not result['qualified'],result)
for p in sorted((ROOT/'replay02').glob('*_C*.json')):
    t=json.loads(p.read_text())['trace'];key=p.stem
    for i in range(len(t['snapshot']['events'])):
        x=copy.deepcopy(t);del x['snapshot']['events'][i]
        for n,e in enumerate(x['snapshot']['events'],1):e['seq']=n
        check(key+f':deleted event {i}',not qualify(x)['qualified'])
    x=copy.deepcopy(t);x['snapshot']['events'].append({'seq':len(x['snapshot']['events'])+1,'kind':'denied','data':{'request_id':'extra','result':{'outcome':'denied','reason':'revoked'}}})
    check(key+':extra event',not qualify(x)['qualified'])
    for field,value in [('epoch',True),('owner','other'),('scope','other:key')]:
        x=copy.deepcopy(t);x['snapshot']['grants'][0][field]=value
        check(key+':grant '+field,not qualify(x)['qualified'])
    x=copy.deepcopy(t);x['workers']['childC']=[]
    if t['case'] not in ('C7','C8'):check(key+':missing child evidence',not qualify(x)['qualified'])
    x=copy.deepcopy(t);x['snapshot']['events'][0]['seq']=True
    check(key+':boolean sequence',not qualify(x)['qualified'])
    c=sqlite3.connect('file:'+str(p.with_suffix('.sqlite3'))+'?mode=ro',uri=True)
    effects=c.execute('SELECT event_seq,effect_key,payload,root,epoch FROM effects').fetchall()
    fences=c.execute("SELECT seq FROM events WHERE kind='revocation'").fetchall()
    expected=1 if t['case'] in ('C0','C2') or (t['arm']=='admission_only' and t['case'] in ('C1','C3')) else 0
    check(key+':raw sink row count',len(effects)==expected)
    post=[e for e in effects if fences and e[0]>fences[0][0]]
    check(key+':raw post-fence effect count',len(post)==(1 if t['arm']=='admission_only' and t['case'] in ('C1','C3') else 0))
    check(key+':raw payload and ancestry',all(e[1:]==('summary:task1','inert summary','rootR',7) for e in effects))
    grants=c.execute('SELECT owner,epoch,scope,can_delegate FROM grants WHERE token=?',('child-1',)).fetchall()
    check(key+':raw child grant',grants==([] if t['case'] in ('C7','C8') else [('childC',7,'summary:task1',0)]))
    c.close()
print(json.dumps({'checks':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks)},indent=2))
raise SystemExit(0 if all(c['passed'] for c in checks) else 1)
