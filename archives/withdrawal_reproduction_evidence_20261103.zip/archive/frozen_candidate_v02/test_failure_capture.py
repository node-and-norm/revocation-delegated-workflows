"""Qualification of failure preservation; no measured run."""
import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import qualify_direct
class Capture(unittest.TestCase):
    def test_primary_and_cleanup_failure_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'case'
            with patch.object(qualify_direct,'call',side_effect=RuntimeError('injected transport failure')):
                with self.assertRaisesRegex(RuntimeError,'injected transport failure'):
                    qualify_direct.run(p,'S0')
            r=json.loads((p/'record.json').read_text())
            self.assertIn('injected transport failure',r['execution_error'])
            self.assertIn('injected transport failure',r['cleanup_error'])
            self.assertIn('caller_trace',r)
            self.assertIn('relay_trace',r)
            self.assertIn('sink',r)
            self.assertIsNotNone(r['gateway_exitcode'])
if __name__=='__main__':unittest.main()
