"""Mutation qualification: offline copies only; no workflow execution."""
import copy,json
from pathlib import Path
from independent_checker import check
ROOT=Path(__file__).resolve().parent
native=json.loads((ROOT/'qualification_logs/framework02/S4/record.json').read_text())
directs={s:json.loads((ROOT/f'qualification_logs/direct02/{s}/record.json').read_text()) for s in ('S0','S1','S2','S3','S4','S5')}
results=[]
def mutate(name,base,fn):
    d=copy.deepcopy(base);fn(d);r=check(d);results.append({'mutation':name,'rejected':not r['passed'],'errors':r['errors']})
def replace_all(d,key,value):
    if isinstance(d,dict):
        for k in d:
            if k==key:d[k]=value
            else:replace_all(d[k],key,value)
    elif isinstance(d,list):
        for x in d:replace_all(x,key,value)
assert check(native)['passed']
mutate('early completion on acceptance',native,lambda d:d['caller_trace'][1].update(after='INSTALLED_CONFIRMED'))
mutate('unknown overwritten as complete',native,lambda d:d.update(caller_state='INSTALLED_CONFIRMED'))
mutate('missing end observation',native,lambda d:d['caller_trace'].pop())
mutate('privileged caller input',native,lambda d:d['caller_trace'][0]['input'].update(sink=d['sink']))
mutate('missing relay response',native,lambda d:d['relay_trace'].pop())
mutate('wrong relay root',native,lambda d:d['relay_trace'][-1]['response'].update(root='other'))
mutate('float relay epoch',native,lambda d:d['relay_trace'][-1]['response'].update(withdrawn_epoch=7.0))
mutate('missing execute receipt',native,lambda d:d['sink']['events'].pop(-2))
mutate('wrong exact framework execute ID',native,lambda d:d['sink']['events'][-2]['data']['request'].update(id='execute-1'))
mutate('wrong ticket binding',native,lambda d:d['sink']['tickets'][0].update(owner='other'))
mutate('wrong authority state',native,lambda d:d['sink']['authority'][0].update(active=1))
mutate('post-fence effect',native,lambda d:d['sink']['effects'].append({'event_seq':10,'effect_key':'summary:task1','payload':'inert summary','root':'rootR','epoch':7}))
mutate('missing framework output',native,lambda d:d['workers'][1].pop('result'))
mutate('false final successful output',native,lambda d:d['workers'][1]['result']['messages'][-1].update(content='{"outcome":"sent"}'))
mutate('same worker PID',native,lambda d:d['workers'][1].update(pid=d['workers'][0]['pid']))
mutate('wrong restored checkpoint',native,lambda d:d['workers'][1]['checkpoint_before']['configurable'].update(checkpoint_id='other'))
mutate('missing restored interrupt',native,lambda d:d['workers'][1].update(restored_interrupts=[]))
mutate('mutated framework action',native,lambda d:d['workers'][1]['trace'][1]['args'].update(subject='other'))
mutate('missing framework tool response',native,lambda d:d['workers'][1]['trace'].pop())
mutate('missing barrier',native,lambda d:d['barriers'].pop(1))
mutate('wrong terminal cutoff',native,lambda d:d['barriers'][-1]['committed_events'].pop())
mutate('claimed confirmed before completion',native,lambda d:d['barriers'][-2].update(caller_state='INSTALLED_CONFIRMED'))
mutate('execution error despite complete trace',native,lambda d:d.update(execution_error='injected'))
# Consistent mutations across duplicate evidence still must fail without a DB comparison.
mutate('consistent wrong root across all evidence',native,lambda d:replace_all(d,'root','other'))
mutate('consistent wrong epoch across all evidence',native,lambda d:replace_all(d,'epoch',6))
# Direct02 uses the corrected shared adapter. Require clean baselines before mutations.
assert all(check(d)['passed'] for d in directs.values())
# Focused verdicts additionally check the intended evidence layer rejects its mutation.
def focused(name,base,fn,category):
    d=copy.deepcopy(base);fn(d);r=check(d);results.append({'mutation':name,'category':category,'rejected':not r['verdicts'][category],'errors':r['errors'][category]})
for field,value in [('root','other'),('request_id','other'),('withdrawn_epoch',6),('new_epoch',9),('scope','global'),('status','accepted'),('withdrawn_epoch',7.0)]:
    focused('completion invalid '+field+' '+repr(value),directs['S1'],lambda d,k=field,v=value:d['caller_trace'][-1]['input'].update({k:v}),'caller_knowledge')
for s in ('S0','S2','S5'):
    focused('missing live effect '+s,directs[s],lambda d:d['sink'].update(effects=[]),'sink_effect')
focused('pre-fence effect erased at later fence',directs['S2'],lambda d:d['barriers'][-1].update(effects=[]),'sink_effect')
focused('missing direct adapter trace',directs['S0'],lambda d:d.pop('adapter_trace'),'framework_path')
focused('wrong direct adapter binding',directs['S0'],lambda d:d['binding'].update(root='other'),'framework_path')
focused('wrong exact direct execute ID',directs['S0'],lambda d:d['sink']['events'][-2]['data']['request'].update(id='resume-execute'),'sink_effect')
focused('duplicate direct execute attempt',directs['S0'],lambda d:d['sink']['events'].extend(copy.deepcopy(d['sink']['events'][-2:])),'sink_effect')
report={'baseline_native_passed':True,'mutation_count':len(results),'all_rejected':all(x['rejected'] for x in results),'mutations':results,'scope':'Offline semantic mutation qualification. Caller access isolation additionally needs source review. Corrected direct02 records are the accepted direct baselines.'}
out=ROOT/'qualification_logs/independent_mutations03.json';out.write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='mutations'},indent=2));assert report['all_rejected'],[x for x in results if not x['rejected']]
