"""Single outstanding request, volatile acceptance, trusted local transport."""
from copy import deepcopy
class Relay:
    def __init__(self):
        self.request_id=None;self.delivered=False;self.response=None;self.forwarded=False;self.trace=[]
    def submit(self,request_id):
        if self.request_id is not None:raise ValueError('one outstanding request only')
        if not isinstance(request_id,str) or not request_id:raise ValueError('invalid request id')
        self.request_id=request_id;self.trace.append({'event':'accepted_volatile','request_id':request_id})
        return {'kind':'accepted_volatile','request_id':request_id}
    def deliver(self,control):
        if self.request_id is None or self.delivered:raise ValueError('invalid delivery state')
        req={'id':self.request_id,'op':'revoke','claim':'controller'}
        control.send(req); self.delivered=True; self.trace.append({'event':'send_intent','request':req})
        if not control.poll(20): raise TimeoutError('gateway response unavailable')
        response=control.recv();self.response=deepcopy(response);self.trace.append({'event':'gateway_response_received','response':deepcopy(response)})
        expected={'outcome':'revocation','root':'rootR','withdrawn_epoch':7,'new_epoch':8}
        if response!=expected or not all(type(response.get(k)) is int for k in ('withdrawn_epoch','new_epoch')):raise ValueError('invalid gateway completion response')
    def completion(self):
        expected={'outcome':'revocation','root':'rootR','withdrawn_epoch':7,'new_epoch':8}
        if self.response!=expected or not all(type(self.response.get(k)) is int for k in ('withdrawn_epoch','new_epoch')) or self.forwarded:raise ValueError('no valid unforwarded response')
        self.forwarded=True
        result={'kind':'completion','request_id':self.request_id,'root':'rootR','withdrawn_epoch':7,'new_epoch':8,'status':'installed','scope':'single_local_sink','gateway_response':deepcopy(self.response)}
        self.trace.append({'event':'completion_forwarded','message':deepcopy(result)})
        return result
