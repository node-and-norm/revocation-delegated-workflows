import unittest,copy
from caller import Caller
from relay import Relay
GOOD={'outcome':'revocation','root':'rootR','withdrawn_epoch':7,'new_epoch':8}
class Pipe:
    def __init__(self,result):self.result=result;self.sent=[]
    def send(self,x):self.sent.append(x)
    def poll(self,n):return True
    def recv(self):return self.result
class Tests(unittest.TestCase):
    def pending(self):
        c=Caller();c.accept({'kind':'issue','request_id':'r'});return c
    def envelope(self):
        r=Relay();r.submit('r');r.deliver(Pipe(GOOD));return r.completion()
    def test_acceptance_pending(self):
        c=self.pending();self.assertEqual(c.accept({'kind':'accepted_volatile','request_id':'r'}),'PENDING')
    def test_completion(self):self.assertEqual(self.pending().accept(self.envelope()),'INSTALLED_CONFIRMED')
    def test_observation_end(self):self.assertEqual(self.pending().accept({'kind':'observation_end'}),'UNCONFIRMED_AT_OBSERVATION_END')
    def test_invalid_completion_fields(self):
        for key,value in [('request_id','other'),('root','other'),('withdrawn_epoch',6),('new_epoch',9),('scope','global'),('status','accepted')]:
            with self.subTest(key=key):
                m=self.envelope();m[key]=value;self.assertEqual(self.pending().accept(m),'INVALID_RESPONSE')
    def test_invalid_raw_response(self):
        m=self.envelope();m['gateway_response']['root']='wrong';self.assertEqual(self.pending().accept(m),'INVALID_RESPONSE')
    def test_strict_epoch_types(self):
        for key in ('withdrawn_epoch','new_epoch'):
            m=self.envelope();m[key]=float(m[key]);self.assertEqual(self.pending().accept(m),'INVALID_RESPONSE')
            m=self.envelope();m['gateway_response'][key]=float(m['gateway_response'][key]);self.assertEqual(self.pending().accept(m),'INVALID_RESPONSE')
    def test_absorbing_terminal(self):
        for message in [self.envelope(),{'kind':'observation_end'},{'kind':'invalid'}]:
            c=self.pending();c.accept(message)
            with self.assertRaises(ValueError):c.accept(self.envelope())
    def test_no_completion_without_receipt(self):
        r=Relay();r.submit('r')
        with self.assertRaises(ValueError):r.completion()
    def test_one_outstanding(self):
        r=Relay();r.submit('r')
        with self.assertRaises(ValueError):r.submit('s')
    def test_bad_gateway_response(self):
        r=Relay();r.submit('r')
        with self.assertRaises(ValueError):r.deliver(Pipe({'outcome':'revocation','root':'wrong'}))
    def test_rejected_delivery_cannot_complete(self):
        r=Relay();r.submit('r');response=dict(GOOD);response['withdrawn_epoch']=7.0
        with self.assertRaises(ValueError):r.deliver(Pipe(response))
        with self.assertRaises(ValueError):r.completion()
    def test_no_duplicate_forward(self):
        r=Relay();r.submit('r');r.deliver(Pipe(GOOD));r.completion()
        with self.assertRaises(ValueError):r.completion()
    def test_issue_missing_id(self):self.assertEqual(Caller().accept({'kind':'issue'}),'INVALID_RESPONSE')
if __name__=='__main__':unittest.main()
