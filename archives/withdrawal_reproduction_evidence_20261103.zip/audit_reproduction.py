import json,pathlib,sqlite3,hashlib,sys,datetime,subprocess,os
ROOT=pathlib.Path(__file__).resolve().parent; E=ROOT/'evidence'; rows=[]
for p in sorted((ROOT/'reproduced').glob('*/S*/record.json')):
 d=json.loads(p.read_text()); old=json.loads((ROOT/'archive/measured01'/p.relative_to(ROOT/'reproduced')).read_text())
 fields=['kind','schedule','path','prior_effect','grant','admission','execute_response','caller_trace','caller_state','relay_trace','barriers','sink','gateway_exitcode','shutdown']
 if d['path']=='direct':fields+=['binding','adapter_trace','workers']
 matches={k:d[k]==old[k] for k in fields}
 row={'path':d['path'],'schedule':d['schedule'],'matched_fields':matches,'caller_state':d['caller_state'],'outcome':d['execute_response'],'effects':len(d['sink']['effects'])}
 fences=[x['seq'] for x in d['sink']['events'] if x['kind']=='revocation']
 row['fence_event_sequences']=fences;row['effect_event_sequences']=[x['event_seq'] for x in d['sink']['effects']]
 row['post_fence_effects']=sum(x['event_seq']>min(fences) for x in d['sink']['effects']) if fences else 0
 if d['path']=='framework':
  a,b=d['workers'];cfg=a['checkpoint_after']['configurable'];tup=tuple(cfg[k] for k in ['thread_id','checkpoint_ns','checkpoint_id'])
  with sqlite3.connect(f'file:{p.parent}/checkpoint.sqlite?mode=ro',uri=True) as c:
   ids=c.execute('SELECT thread_id, checkpoint_ns, checkpoint_id FROM checkpoints').fetchall()
  row['native_checkpoint']={'paused_config':cfg,'pause_resume_identity_match':a['checkpoint_after']==b['checkpoint_before'],'identity_present_in_sqlite':tup in ids,'worker_pids':[a['pid'],b['pid']],'distinct_pids':a['pid']!=b['pid'],'worker_files_match_record':all(json.loads((p.parent/f'worker_{w["phase"]}.json').read_text())==w for w in [a,b])}
 rows.append(row)
 if not all(matches.values()) or (d['path']=='framework' and not all(row['native_checkpoint'][k] for k in ['pause_resume_identity_match','identity_present_in_sqlite','distinct_pids','worker_files_match_record'])):
  (E/'comparison.json').write_text(json.dumps(rows,indent=2));sys.exit('STOP: mismatch')
(E/'comparison.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_semantic_fields_match':True,'rows':rows},indent=2))
# Fresh module and failure-preservation qualification without running the mutation script,
# which would rewrite a historical artifact within the extraction.
cmd=[str(ROOT/'.venv/bin/python'),'-m','unittest','-v','test_modules','test_failure_capture']
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',LANGSMITH_TRACING='false',LANGCHAIN_TRACING_V2='false')
r=subprocess.run(cmd,cwd=ROOT/'archive/frozen_candidate_v02',env=env,capture_output=True)
(E/'module_tests.stdout').write_bytes(r.stdout);(E/'module_tests.stderr').write_bytes(r.stderr)
(E/'module_test_command.json').write_text(json.dumps({'argv':cmd,'cwd':str(ROOT/'archive/frozen_candidate_v02'),'exit_code':r.returncode},indent=2))
print('12 cases match archived deterministic evidence; all 6 checkpoint identities verified; tests exit',r.returncode)
sys.exit(r.returncode)
