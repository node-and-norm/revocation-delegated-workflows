import subprocess, pathlib, json, datetime, hashlib, sys, os
ROOT=pathlib.Path(__file__).resolve().parent
ARC=ROOT/'archive'; E=ROOT/'evidence'; SRC=ARC/'frozen_candidate_v02'; PY=ROOT/'.venv/bin/python'
manifest=[]
def run(label,args,cwd=ROOT):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PIP_NO_INDEX='1', PIP_DISABLE_PIP_VERSION_CHECK='1', LANGSMITH_TRACING='false', LANGCHAIN_TRACING_V2='false')
    r=subprocess.run([str(x) for x in args],cwd=cwd,env=env,capture_output=True)
    (E/f'{label}.stdout').write_bytes(r.stdout);(E/f'{label}.stderr').write_bytes(r.stderr)
    manifest.append({'label':label,'argv':list(map(str,args)),'cwd':str(cwd),'started_utc':start,'exit_code':r.returncode,'stdout':f'{label}.stdout','stderr':f'{label}.stderr'})
    (E/'commands.json').write_text(json.dumps(manifest,indent=2))
    print(label, r.returncode,flush=True)
    if r.returncode:sys.exit(r.returncode)
run('archive_hash',['sha256sum',ROOT.parent/'withdrawal_interface_study_v01_20261103.zip'])
run('archive_integrity',['sha256sum','-c','SHA256SUMS'],ARC)
freeze=json.loads((SRC/'FREEZE.json').read_text()); mismatches=[n for n,h in freeze['files'].items() if hashlib.sha256((SRC/n).read_bytes()).hexdigest()!=h]
(E/'freeze_verification.json').write_text(json.dumps({'files_checked':len(freeze['files']),'mismatches':mismatches},indent=2))
if mismatches:sys.exit(1)
run('create_venv',[sys.executable,'-m','venv',ROOT/'.venv'])
run('install_offline',[PY,'-m','pip','install','--no-index','--no-cache-dir','--require-hashes','--find-links',ROOT.parent/'revocation_integration_pilot_20261103/integration/v0.3/wheelhouse','-r',SRC/'requirements.hashed.txt'])
run('runtime',[PY,'-c','import sys,platform,sqlite3,json;print(json.dumps(dict(executable=sys.executable,python=sys.version,platform=platform.platform(),sqlite=sqlite3.sqlite_version),indent=2))'])
run('packages',[PY,'-m','pip','freeze'])
run('dependency_check',[PY,'-m','pip','check'])
run('archived_checker',[PY,SRC/'independent_checker.py',*sorted((ARC/'measured01').glob('*/S*/record.json'))])
(ROOT/'reproduced').mkdir()
run('direct',[PY,SRC/'qualify_direct.py',ROOT/'reproduced/direct','direct','--measured'])
run('direct_checker',[PY,SRC/'independent_checker.py',*sorted((ROOT/'reproduced/direct').glob('S*/record.json'))])
run('framework',[PY,SRC/'qualify_direct.py',ROOT/'reproduced/framework','framework','--measured'])
run('reproduced_checker',[PY,SRC/'independent_checker.py',*sorted((ROOT/'reproduced').glob('*/S*/record.json'))])
run('archive_integrity_after',['sha256sum','-c','SHA256SUMS'],ARC)
run('archive_hash_after',['sha256sum',ROOT.parent/'withdrawal_interface_study_v01_20261103.zip'])
