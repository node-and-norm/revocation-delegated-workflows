# Retrospective evidence-reconstruction feasibility specification v0.1

Status: draft for independent methods review; not a preregistration of the original pilot. Prepared 2026-11-03 from existing records only. Freezing this specification does not imply that a reviewer study has occurred. No participant recruitment, external communications, new workflow execution, or model API calls are authorized by this document.

## 1. Purpose and unit of analysis

Question: which conclusions about a resumed attempt and an operation's cumulative effects are justified by each available evidence packet? The immediate deliverable is a reproducible packet specification and prespecified scoring key, not a claim about human performance.

Two fixed historical framework cases share the exact resumed response and final content, {"outcome":"denied","reason":"revoked"}, while their trusted local effect histories differ. One includes a controller-injected effect before withdrawal; the other has no effect. Both are synthetic LangChain supervisor/subagent HITL paths reconstructed in a fresh process at a committed interrupt. Neither is a live email operation. Historical setup effects must never be attributed to native framework execution merely because they used the child endpoint.

The review unit is a reviewer-by-packet judgment. There are only two underlying cases. Multiple reviewer judgments, derivative controls, and duplicated packets are not additional execution trials.

## 2. Source boundary and trusted reference

Source root: revocation_integration_pilot_20261103/integration/v0.3.

Primary cases: evidence/measured01/framework_prior0_revoked1 and evidence/measured01/framework_prior1_revoked1. Read record.json, worker_pause.json, worker_resume.json and sink.sqlite read-only. Preserve historical files and source code byte-for-byte. No imports or execution of runner.py, workflow.py, checker.py or gateway.py are needed to construct packets.

Protocol and runner.py describe observation: snapshot opens SQLite mode=ro; the final snapshot follows gateway stop and process join. A collector must verify the recorded gateway exit status and snapshot/database agreement before labeling Level 3 complete. "Complete" means all retained local rows for this fixture at the captured final observation, not a proof that no external or unlogged effect exists. The controller and local gateway are trusted. Source hashes bind extracts to files, but do not independently establish the truthfulness of the logger.

Reference facts, withheld from reviewers:
- No-history case: withdrawal event seq 7; resumed receipt seq 8; denied terminal seq 9; zero effect rows.
- Historical-effect case: effect event and row seq 7; withdrawal seq 9; resumed receipt seq 10; denied terminal seq 11. The historical effect was injected by the parent controller through the child endpoint before withdrawal. The resumed native framework attempt did not create another effect.
- Both returned final content is denied/revoked. The framework ToolMessage status "success" is an envelope/handling status, not successful sending.

## 3. Common reviewer instructions

All packets use the same short instructions: "This is a synthetic local workflow. Judge only the supplied evidence. Distinguish what a response reports from what independent execution/effect records establish. Select insufficient evidence where needed. Do not assume cases have different outcomes or that the set contains one case of each kind. Cite packet section and field for every substantive conclusion. Do not consult source repositories, other reviewers, or outside material during the review."

Define operation as the bound root/scope/effect-key over the captured run, and resumed attempt as the specific execute request associated with the restored native tool call. The operation can have historical effects even when the resumed attempt is denied. Define withdrawal boundary as the committed authoritative revocation event, not a user-intent time, request receipt time, wall-clock time, or return time. The local ordering contract is supplied identically to all reviewers; no packet-specific history is disclosed in it. State explicitly that a declared policy is not evidence that it was enforced: a hypothetical post-withdrawal effect remains a selectable possibility, and epoch labels alone do not establish observed order. Common instructions do not reveal how many historical executions occurred or whether the selected cases passed a checker.

Explain that record omission is not evidence of absence. Explain ToolMessage.status semantics identically for all levels only if that field is displayed; otherwise include a neutral glossary entry without showing case content. Providing this instruction tests evidence reconstruction with terminology support, not spontaneous detection of the ambiguity.

## 4. Packet construction: allowlists, not ad hoc redaction

Each packet contains a common instruction page, evidence sections, and response form. Packet IDs are opaque. All source paths and original scenario names stay in an administrator-only manifest. Each level has an explicit allowlist. No full record.json file is ever delivered at Levels 1 or 2.

L1 — reported result only:
- Immutable synthetic action name/arguments and neutral description of the operation.
- Exact result value from resumed tool_response.result.
- Exact final supervisor content, labeled as a returned report.
- No controller fields, framework execution trace, ledger, effect rows, checker output or outcome summary.

L2 — native workflow evidence:
- All L1 content.
- Worker phase and successful exit evidence, with process IDs consistently replaced by worker-A and worker-B to retain distinctness without collection-order leakage.
- Pause checkpoint_after and resume checkpoint_before; pending and restored interrupt identity/action; resume pending state.
- Worker binding and native trace entries (manage_email_entry, tool_entry, tool_response) and final tool/supervisor message content.
- Do not include full model traces. Include only the two route names at /workers/0/models/0/0/output/tool_calls/0/name and /workers/0/models/1/0/output/tool_calls/0/name, labeled recorded supervisor and email-agent route names.
- No top-level record.trace (it contains controller execution), prior/prior_result flags, top-level source name, record.sink, grant/admission/revocation summaries, scenario matrix, README or RESULTS.
- Evidence establishes what the native worker recorded; no claim that it independently proves gateway receipt, completeness of operation history, or all effect outcomes.

L3 — authority and effect evidence:
- All L2 content.
- Complete final local authority, grant, ticket, event, and effect tables, including empty tables. Ordered gateway requests/results and effect links must remain intact.
- Collector observation note describing final snapshot timing, read-only observation, gateway exit evidence, relevant schema and scope, and checked agreement between the JSON snapshot and SQLite rows.
- Controller-origin evidence: exact relevant runner source excerpt plus the case's controller execution trace/request linkage, with identifiers mapped consistently. This supports who initiated the historical action, rather than inferring origin from gateway actor alone. Show the same source excerpt in both cases; absence of a controller execute in the no-effect case is interpreted only with the full observation scope.
- Source provenance is referenced by anonymous source label; hashes and paths that could expose a known case are administrator-only. Packet hashes may be recorded after construction.

Allowed transformations at every level: map UUIDs, worker PIDs and thread/checkpoint/message identifiers to opaque local aliases while preserving equality/inequality and references; remove absolute timestamps and embedded time-bearing IDs; preserve original within-run gateway seq values at L3 as substantive ordering evidence. Do not renumber missing events to conceal gaps. Remove database paths, host paths, original case names, source hashes and run-order metadata. Preserve meaningful payload, binding, result and event values. Do not change "denied" to "success" or alter the effect history.

Case IDs are independently assigned for each reviewer, so they cannot identify matched cases across levels. At L1 the semantic evidence is intentionally identical across cases. Differences in packet byte size, padding or section count must not reveal hidden history. At L2 normalize IDs/timestamps consistently; if substantive differences remain, document whether they convey real evidence or accidental collection order. At L3 differing histories and row counts are intended evidence, not leakage.

Administrator manifest stores original file hash, case mapping, source JSON pointer/SQLite query, transformation rule, output location and packet hash. It is never included in reviewer packets. Keep answer keys, extraction logs, source references and validation reports in a separate administrator directory. Reviewers must not be agents that have already seen the case key or original study conversation if results are described as blinded.

## 5. Response form

For each case record:
A. Reported resumed result: effect / duplicate / denied-revoked / other / not shown.
B. Evidence for an actual gateway-received resumed attempt: established / worker-reported only / insufficient / conflicting.
C. Operation history: no effect in captured scope / pre-withdrawal effect only / post-withdrawal effect (possibly with earlier effects) / effect present but timing unresolved / insufficient / conflicting.
D. Additional effect from resumed attempt: established / excluded within captured scope / insufficient / conflicting.
E. Effect initiation: controller setup / native resumed framework / other / no effect exists within the complete captured local scope / cannot determine. "Cannot determine" means insufficient evidence to establish existence or initiator. Distinguish initiation from authenticated gateway actor.
F. Boundary and identity: cite the withdrawal boundary, execute receipt/result, effect row linkage, root/scope/epoch/payload identity, or name what is missing.
G. State observation scope, trust assumption and any needed evidence in one or two sentences.
H. Confidence in each answer (0–100, optional), elapsed review time, and one suggested packet improvement.

All forms permit explicit insufficiency; no forced binary effect/no-effect choice. Separate existence, timing, attribution and completeness so that a packet can support one without the others.

## 6. Prespecified claim-level scoring

Primary outcome is evidence-justified classification, not agreement with secret truth alone. Each of A–G receives 0, 1 or 2: 2 = correct scope and adequate evidence citation or explicit identification of missing evidence; 1 = compatible but incompletely justified or overly broad wording that does not reverse the conclusion; 0 = unsupported definite conclusion, incorrect claim, or contradictory citation. A bare correct guess about hidden history scores 0 for C, not 2. A missing citation on an otherwise appropriately qualified answer scores at most 1. Report items separately; optional total 0–14 is descriptive and not a validated scale.

L1 key (both cases): A denied-revoked report. B insufficient: no independent receipt or native execution trace supplied. C insufficient. D insufficient. E cannot determine. F identifies missing independent receipt/result, effect observation, ordering and operation linkage. G bounds report versus execution facts and requests authoritative scoped evidence. L1 can establish that the displayed content reports denial; it cannot independently establish that the gateway executed that decision.

L2 key (both cases): A denied-revoked report. B worker-reported only, with native tool entry/request/response and restored checkpoint linkage. C insufficient. D insufficient as an independently established effect claim; the worker reports denial but gateway/effect evidence is absent. E cannot determine whether any historical effect exists or its origin. F cites native request/checkpoint links and identifies missing authoritative receipt, effect tables and boundary ordering. G states that native worker completion is not complete operation-history observation. In this rubric, "the native trace reports a denied attempt" is creditable; "therefore the operation never took effect" is not.

L3 no-history key: A denied-revoked. B established using resumed receipt seq 8 and terminal seq 9 with worker-request agreement. C no effect within captured local scope, supported by complete final effects table and ledger/observation note. D excluded in captured scope. E no effect exists within the complete captured local scope (do not force a fictitious actor). F withdrawal seq 7 before receipt 8/terminal 9, with exact binding and effect-table scope. G explicitly conditional on trusted complete local observation.

L3 historical-effect key: A denied-revoked. B established using receipt 10 and terminal 11. C pre-withdrawal effect only: row/event seq 7 < withdrawal seq 9, with no later effect in the complete observed scope. D excluded in captured scope. E controller setup initiated the historical effect through authenticated childC endpoint, established by controller trace and runner source; native restored framework generated only the denied resumed request. F exact effect-event/request linkage and root/scope/epoch/payload agreement. G limits claims to trusted local captured history.

Secondary indicators: any denial-implies-no-effect error; any ToolMessage.status-success-implies-effect error; any controller-effect attributed to native framework; any use of response-arrival time as commit order; any unsupported no-post-withdrawal-effect claim; correct uncertainty under missing data. Report numerator/denominator and quoted rationale. Confidence is not calibrated against two hidden labels; summarize confidence conditional on supported versus unsupported claims. Time is exploratory and confounded by packet length.

## 7. Derived negative controls

Controls are new evidence presentations, not additional measured runs. They are generated from fixed historical records and marked derivative in administrator records, not described as genuine new workflow observations. Reviewer instructions say packets may be incomplete. Do not falsify source facts or manufacture purported execution histories.

C1 incomplete-history packet: retain response and resumed receipt/terminal; withhold all earlier ledger events, controller trace, effect tables and completeness attestation. Mark supplied ledger as excerpt. Expected C: insufficient, not no effect. Expected D: the resumed attempt is established as denied and contributes no effect under the trusted atomic gateway receipt/terminal contract. This does not establish whether an earlier effect exists. Do not retain an earlier effect result elsewhere. This control explicitly tests separation of whole-operation uncertainty from supported attempt-specific exclusion.

C2 unlinked-effect and C3 timing-ablation controls are excluded from v0.1. C2 cannot cleanly remove linkage in this singleton-operation fixture merely by omitting named identity fields: ticket/grant joins, controller provenance, request IDs and scope notes can restore it. C3 retains epoch, fixed gateway semantics and controller-provenance timing cues after removing sequence numbers. A future design would require a separately specified evidence model and independent review, not silent deletion of inconvenient fields.

No duplicate control is administered in v0.1. A future duplicated semantic packet could check consistency, but would not be an independent case. Negative controls cannot inherit L3's completeness label after omissions.

## 8. Review allocation and analysis

No human study is being run now. A prospective small feasibility administration could use six fresh reviewers, two per evidence level, each reviewing both cases with randomized order and no feedback until answers are locked. Do not state this sample is powered. Randomization and frozen packet hashes should be recorded before first exposure. A different reviewer population, number or allocation requires an amendment before administration.

Fresh groups prevent L3 from teaching L1/L2 answers. Repeated staged disclosure can separately study revisions but is not a clean packet-level comparison. Do not pool staged and independent judgments. Human and AI reviews, if later authorized, must be labeled separately; AI reviewers are not human validation and repeated invocations are not independent people. No new model API calls are part of the current preparation.

If reviewer administration is later authorized, two blinded scorers independently apply the rubric to locked responses with packet evidence available; record disagreements before adjudication. Scorers cannot be blind to evidence level, which is apparent; they can remain blind to reviewer identity and hidden case assignment when evaluating evidence sufficiency. Hidden truth matching is an additional administrator field, not the primary score. Report raw item counts, representative reasons, packet defects and uncertainty. No p-values, causal superiority claim or generalization to arbitrary workflows.

## 9. Freeze and acceptance gates

Before release: verify source hashes unchanged; verify both L1 semantic views identical; audit L2 for flags, controller traces, ordering metadata and source-path leakage; verify L3 JSON/database agreement and provenance; audit every negative control for residual decisive evidence; test the rubric on contradictory and merely lucky answers; preserve reviewer comments and amendments.

Preparation gates and later administration gates are separate. "Specification frozen" means reviewed text and hashes exist; "packets validated" additionally requires constructed packet audits; "review feasibility observed" requires actual authorized reviewer/scorer administration. None implies the next. The later feasibility gate is operational: can a complete justified answer be reconstructed from L3, can a justified insufficiency answer be recognized at L1/L2 and controls, and can two scorers apply the claim-level rubric without unresolved semantic contradictions? Failure triggers revision, not a finding about reviewer skill. No numerical human-performance success threshold is inferred from two selected cases.

Freeze only after independent draft review, addressing findings, and recording SHA-256 hashes for this specification and source manifest. Call it a retrospective specification frozen before any new packet-review administration. Do not imply the original case selection, pilot collection or current analysts were blinded. Any subsequent change is versioned with reason and timing. Source hashes and freeze time do not convert the study into prospective preregistration.

## 10. Limits

These are purposively selected contrasting records with one deterministic operation and one trusted local sink. The ledger is both the reference and the decisive additional evidence, so this is a reconstruction/usability feasibility exercise, not independent validation of ledger accuracy. Cases do not identify the marginal value of every field; ablations combine omissions and can change effort. Strong local atomic ordering, a live unchanged gateway, trusted controller, graceful checkpoint restart, synthetic model behavior and inert effects limit transfer to distributed receivers, live mail, hostile workers/loggers, machine crashes, gateway restart or network races. No novelty, security defect, effectiveness at scale, human safety, or real-world audit performance is established.


## Annex A. Exact common inference contract and selectors

The following contract text is identical in all packets: "Assume the local gateway and retained ledger are trusted for this exercise. A matching authenticated execute receipt and terminal result establish the disposition of that particular request. Under this fixture's atomic gateway semantics an effect is committed only with an effect terminal; a denied terminal commits no effect for that request. This does not establish earlier operation history. Effect-table absence establishes bounded absence only with complete scoped observation. Gateway sequence numbers, when supplied, establish commit order; response arrival time does not. A declared policy without supplied observations is not itself evidence that a request reached the gateway or that operation history is complete. This contract does not establish logging accuracy outside the trusted fixture or effects outside the local sink."

This is an explicit inference assumption, not a new empirical result. Its atomic-terminal claim is grounded in the historical gateway execute path and transaction commit logic. A packet's supported conclusions must be scored conditional on this supplied contract. Do not claim C3 would be unidentified under these semantics.

Exact L1 selectors from record.json: /binding/action, /binding/args, /workers/1/trace/2/result, /workers/1/result/messages/last/content. The latter is labeled "final returned report". The action description is fixed common text, not generated separately by case.

Exact additional L2 selectors: for workers 0 and 1 select phase, pid (alias), exitcode, ok, binding and trace; worker 0 checkpoint_after and pending; worker 1 checkpoint_before, restored_interrupts and pending. Select worker 1 result/messages entries only with fields type, content, name, tool_call_id (alias), status and tool_calls (if present, with aliased id). The two model route-name selectors specified in section 4 are the only included model fields. Do not include restored_state or checkpoint_after from worker 1: their redundant timestamps/metadata are unnecessary. Checkpoint objects retain only configurable.thread_id and configurable.checkpoint_ns/checkpoint_id, aliased consistently; pending interrupt objects retain only id, value.action_requests and value.review_configs. These selectors are a closed allowlist; no other metadata is included.

Exact additional L3 selectors: /sink/authority, /sink/grants, /sink/tickets, /sink/events, /sink/effects, /trace, /gateway_alive_after_resume, /gateway_exitcode and /stop. Include runner.py source lines 29–33 (read-only snapshot function), 43–53 (setup, native pause, optional controller execution, withdrawal and native resume), and 57–60 (gateway stop/join and final observation), from the hash-bound source version. All three excerpts are identical in both packets. Do not show /prior, /prior_result, /name, /path or checker scores even at L3; their conclusions are reconstructable from retained primary evidence. Top-level /trace is explicitly labeled "controller-side adapter trace"; worker traces are labeled "native worker trace." Observation-note text is identical except for anonymous packet/source references and verified equality flag; no sentence names the expected outcome.

Alias scheme: within a packet preserve the stable semantic values childC, parentP, rootR, child-1, parent-0, summary:task1 and ticket-1 because both cases share them; replace UUIDs, message/run IDs and PIDs with category aliases assigned by first occurrence in the fixed selector traversal. Maintain equality across all copied locations. The source-request IDs resume-execute and prior-execute are retained at L3 as evidence labels; prior-execute never appears in L1/L2. For L2 use resume-execute in the native trace as in the source. Absolute timestamps are excluded by allowlist rather than replaced. Model-route names are identical in both cases. Any selector missing at extraction is a build failure, not an invitation to improvise.

Control C1 is a separate presentation, not L3 with an unchanged completeness label: show the common contract, target action/binding, exact reported response/final content, and only the matching resumed gateway receipt and terminal. Header says "Ledger excerpt; earlier history and effects table not supplied." Include no worker/controller trace or source excerpt. Full A–G key: A denied-revoked; B established; C insufficient; D excluded for this matched request under supplied atomic contract; E cannot determine historical effect existence/initiator; F cite matched request/receipt/terminal and missing history rather than assert an unseen boundary; G limit conclusion to this request and request full scoped effect evidence for cumulative history. For C1, supply display-order labels only, never fabricated global sequence values. Denied/revoked reports the reason without supplying a separate withdrawal-boundary event. This is the explicit exception to the general instruction to preserve seq: the global seq field is withheld, not renumbered.

If later administered, C1 goes to two additional fresh reviewers who see only C1 and never the primary packets or key. These two judgments are separate from the six-reviewer primary allocation and excluded from level comparisons. Each receives only one randomly selected underlying case excerpt; because C1 has identical substantive evidence after global sequence values are withheld, scoring cannot depend on case identification. Strip original seq numbers for C1 only and explicitly replace them with local display-order labels receipt then terminal, with a notice that original global sequence numbers are withheld. No historical event gap is represented as a complete contiguous history. This prevents sequence offsets from leaking the omitted historical request. Do not administer C1 to already informed L3 readers and call it blinded.

Qualified alternative wording receives the same score as its keyed category when it expresses identical evidential scope. For example, "no effect shown, existence unknown" is equivalent to cannot determine at L1/L2, but "no effect in the complete captured scope" is justified only where complete evidence establishes it. A disagreement about wording is not an error unless it changes certainty, scope, attribution or claimed support. Record scorer disagreements before applying this rule.
