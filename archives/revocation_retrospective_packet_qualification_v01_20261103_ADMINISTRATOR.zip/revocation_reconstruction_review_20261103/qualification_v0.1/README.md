# Local derivative-packet qualification v0.1

Eight JSON packets were extracted from two existing historical records using the frozen retrospective specification. No historical workflow/checker or model API was executed. No participants were recruited, and no reviewer-performance findings exist.

- reviewer_packets/: neutral packet files. Deliver only the assigned file to an actual reviewer, not this whole folder: pairs and richer packets would contaminate blinding.
- administrator/: builder, source/case/alias map, validation script and results. This directory contains answers and source identifiers and must never be supplied to blinded reviewers.

Three evidence levels and one missing-history control were built for each case. L1, L2 and C1 each have identical semantic content across the pair after removal of packet_id. L3 preserves the distinct complete local histories. This is expected information equivalence, not evidence that any reviewer inferred the correct answer.

The qualification scripts run only local JSON/file comparisons; they do not invoke historical pilot machinery. Independent methods review is separate from the mechanical checks. The frozen specification remains unchanged; any correction requiring a new method must be a versioned amendment rather than silently changing its text.
