"""Read-only packet validation. Does not run historical code or invoke models."""
import hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parents[1]
m=json.loads((ROOT/'administrator/extraction_manifest.json').read_text());checks=[]
def check(label,condition):checks.append({'check':label,'passed':bool(condition)})
pairs={}
for p in m['packets']:
 f=ROOT/p['path'];d=json.loads(f.read_text());check(p['packet_id']+' packet hash',hashlib.sha256(f.read_bytes()).hexdigest()==p['sha256']);pairs.setdefault(p['level'],[]).append(d)
 s=json.dumps(d)
 check(p['packet_id']+' no original case or source path',not any(x in s for x in ['framework_prior','measured01','/workspace/','record.json','RESULTS.json']))
 check(p['packet_id']+' no UUID or absolute timestamp',not re.search(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|2026-11-03T',s))
 if p['level'] in ['L1','L2','C1']:
  check(p['packet_id']+' no outcome-revealing fields',not any('"'+x+'"' in s for x in ['prior','prior_result','sink','effects','final_local_tables','controller_side_adapter_trace','controller_source_excerpts']))
  check(p['packet_id']+' no historical execute ID','prior-execute' not in s)
 if p['level']=='C1':
  check(p['packet_id']+' no global seq','"seq"' not in s and '"event_seq"' not in s)
 if p['level']=='L3':
  r=json.loads((BASE/'revocation_integration_pilot_20261103/integration/v0.3/evidence/measured01'/p['historical_case']/'record.json').read_text())
  check(p['packet_id']+' exact local tables',d['evidence']['final_local_tables']==r['sink'])
for level in ['L1','L2','C1']:
 a,b=pairs[level];a=dict(a);b=dict(b);a.pop('packet_id');b.pop('packet_id');check(level+' semantic pair equality',a==b)
for source,sha in m['sources'].items():check('source preserved '+source,hashlib.sha256((BASE/source).read_bytes()).hexdigest()==sha)
freeze=json.loads((BASE/'revocation_reconstruction_review_20261103/SPECIFICATION_FREEZE_v0.1.json').read_text())
for source in freeze['source_files_unchanged']:
 old=json.loads((BASE/'revocation_reconstruction_review_20261103/SOURCE_INSPECTION_v0.1.json').read_text())['files'][source]
 check('historical preserved '+source,hashlib.sha256((BASE/source).read_bytes()).hexdigest()==old)
result={'status':'passed' if all(x['passed'] for x in checks) else 'failed','checks':checks,'limits':'Structural extraction qualification, not independent blind review or human/model performance. Semantic inference requires methods review.'}
(ROOT/'administrator/validation_report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'checks':len(checks),'failures':[x for x in checks if not x['passed']]},indent=2))
