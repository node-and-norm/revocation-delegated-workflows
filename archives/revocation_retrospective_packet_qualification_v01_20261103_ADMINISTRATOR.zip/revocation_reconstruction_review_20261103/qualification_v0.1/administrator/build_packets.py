"""Derivative packet extraction only. Never imports or executes historical pilot code."""
import copy,hashlib,json,re,sqlite3
from pathlib import Path
BASE=Path(__file__).resolve().parents[3]
SRC=BASE/'revocation_integration_pilot_20261103/integration/v0.3'
OUT=Path(__file__).resolve().parents[1]
CONTRACT="Assume the local gateway and retained ledger are trusted for this exercise. A matching authenticated execute receipt and terminal result establish the disposition of that particular request. Under this fixture's atomic gateway semantics an effect is committed only with an effect terminal; a denied terminal commits no effect for that request. This does not establish earlier operation history. Effect-table absence establishes bounded absence only with complete scoped observation. Gateway sequence numbers, when supplied, establish commit order; response arrival time does not. A declared policy without supplied observations is not itself evidence that a request reached the gateway or that operation history is complete. This contract does not establish logging accuracy outside the trusted fixture or effects outside the local sink."
INSTRUCTIONS="This is a synthetic local workflow. Judge only the supplied evidence. Distinguish what a response reports from what independent execution/effect records establish. Select insufficient evidence where needed. Do not assume cases have different outcomes or that the set contains one case of each kind. Cite packet section and field for every substantive conclusion. Do not consult source repositories, other reviewers, or outside material during the review."
FORM={"A":"Reported resumed result: effect / duplicate / denied-revoked / other / not shown.","B":"Gateway-received resumed attempt: established / worker-reported only / insufficient / conflicting.","C":"Operation history: no effect in captured scope / pre-withdrawal effect only / post-withdrawal effect (possibly with earlier effects) / effect present but timing unresolved / insufficient / conflicting.","D":"Additional effect from resumed attempt: established / excluded within captured scope / insufficient / conflicting.","E":"Effect initiation: controller setup / native resumed framework / other / no effect exists within the complete captured local scope / cannot determine.","F":"Cite boundary, receipt/result, effect linkage and operation identity, or state what is missing.","G":"State observation scope, trust assumption and needed evidence.","H":"Optional confidence 0–100 per answer, elapsed time and one packet improvement."}
GLOSSARY={"operation":"The bound root/scope/effect-key over the captured run, including any historical effects.","resumed_attempt":"The specific execute request associated with the restored native tool call.","withdrawal_boundary":"The committed authoritative revocation event, not request receipt, user-intent time or response time.","ToolMessage.status":"Framework envelope/handling status; success does not by itself mean a business effect occurred.","cannot_determine":"Insufficient evidence to establish effect existence or initiator.","omission":"Omission of a record is not evidence of absence."}
IDS={'framework_prior0_revoked1':{'L1':'P-7D2','L2':'P-6B8','L3':'P-9A4','C1':'P-3F5'},'framework_prior1_revoked1':{'L1':'P-8C1','L2':'P-2E6','L3':'P-4D9','C1':'P-5A7'}}

def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def checkpoint(x):return {'configurable':{k:x['configurable'][k] for k in ['thread_id','checkpoint_ns','checkpoint_id']}}
def interrupts(xs):return [{'id':x['id'],'value':{k:x['value'][k] for k in ['action_requests','review_configs']}} for x in xs]
def alias_all(x):
 maps={};counters={}
 def alias(v,cat):
  if v in (None,''):return v
  key=(cat,str(v))
  if key not in maps:
   counters[cat]=counters.get(cat,0)+1;maps[key]=(f'worker-{chr(64+counters[cat])}' if cat=='worker' else f'{cat}-{counters[cat]}')
  return maps[key]
 def walk(v,k=''):
  if isinstance(v,dict):return {a:walk(b,a) for a,b in v.items()}
  if isinstance(v,list):return [walk(a,k) for a in v]
  if k=='pid':return alias(v,'worker')
  if k in ['checkpoint_id','thread_id']:return alias(v,k.removesuffix('_id'))
  if k in ['id','tool_call_id'] and v not in ['resume-execute','prior-execute','prepare','delegate','revoke']:
   return alias(v,'reference')
  return v
 return walk(x),{f'{k[0]}:{k[1]}':v for k,v in maps.items()}
manifest={'purpose':'Packet extraction qualification, not reviewer performance','sources':{},'packets':[]}
manifest['specification']={'path':'revocation_reconstruction_review_20261103/RETROSPECTIVE_PACKET_SPEC_v0.1_FROZEN.md','sha256':h(BASE/'revocation_reconstruction_review_20261103/RETROSPECTIVE_PACKET_SPEC_v0.1_FROZEN.md')}
selectors={
 'L1':{'/evidence/action':'/binding/action','/evidence/arguments':'/binding/args','/evidence/resumed_tool_report':'/workers/1/trace/2/result','/evidence/final_returned_report':'/workers/1/result/messages/last/content'},
 'L2':{'/evidence/native_worker_traces/0':'/workers/0 restricted to phase,pid,exitcode,ok,binding,trace,checkpoint_after,pending','/evidence/native_worker_traces/1':'/workers/1 restricted to phase,pid,exitcode,ok,binding,trace,checkpoint_before,restored_interrupts,pending','/evidence/final_messages':'/workers/1/result/messages/* restricted to type,content,name,tool_call_id,status,tool_calls','/evidence/recorded_route_names/supervisor':'/workers/0/models/0/0/output/tool_calls/0/name','/evidence/recorded_route_names/email_agent':'/workers/0/models/1/0/output/tool_calls/0/name'},
 'L3':{'/evidence/final_local_tables':'/sink (all five tables)','/evidence/controller_side_adapter_trace':'/trace','/evidence/gateway_observation':'/gateway_alive_after_resume,/gateway_exitcode,/stop','/evidence/controller_source_excerpts':'runner.py lines 29–33,43–53,57–60','/evidence/snapshot_database_agreement_checked':'computed equality of /sink and read-only SELECT * from each retained SQLite table','/evidence/observation_note':'common frozen-spec observation text; emitted only after equality validation'},
 'C1':{'/evidence/action':'/binding/action','/evidence/arguments':'/binding/args','/evidence/target_binding':'/binding','/evidence/resumed_tool_report':'/workers/1/trace/2/result','/evidence/final_returned_report':'/workers/1/result/messages/last/content','/evidence/resumed_gateway_excerpt':'/sink/events filtered by request.id or request_id == resume-execute; retain kind,data; omit seq and add explicitly non-source display_label','/evidence/header':'common frozen-spec excerpt notice'}
}
transformations={'checkpoint':'retain configurable.thread_id,checkpoint_ns,checkpoint_id only','interrupt':'retain id,value.action_requests,value.review_configs only','identifiers':'category aliases preserving equality/inequality, mapping stored per packet','timestamps':'excluded by closed allowlist','semantic_values':'unchanged','common_fields':'instructions,inference_contract,glossary,response_form and neutral labels derive from frozen specification, not historical case data','C1_sequence':'global seq omitted; non-source receipt/terminal display labels supplied'}

source_lines=(SRC/'runner.py').read_text().splitlines()
source_excerpts=[{'source_label':'controller-source','line_range':[a,b],'text':'\n'.join(source_lines[a-1:b])} for a,b in [(29,33),(43,53),(57,60)]]
for case,ids in IDS.items():
 source=SRC/'evidence/measured01'/case/'record.json';r=json.loads(source.read_text());manifest['sources'][str(source.relative_to(BASE))]=h(source)
 db=source.parent/'sink.sqlite'
 with sqlite3.connect(f'file:{db}?mode=ro&immutable=1',uri=True) as con:
  con.row_factory=sqlite3.Row
  tables={t:[dict(x) for x in con.execute('SELECT * FROM '+t)] for t in ['authority','grants','tickets','events','effects']}
 for event in tables['events']:event['data']=json.loads(event['data'])
 snapshot_verified=tables==r['sink']
 if not snapshot_verified:raise ValueError('Snapshot/database disagreement; refuse to attest complete extraction: '+case)
 manifest['sources'][str(db.relative_to(BASE))]=h(db)
 a,b=r['workers'];assert len(a['trace'])==1 and len(b['trace'])==3
 l1={'action':r['binding']['action'],'arguments':r['binding']['args'],'resumed_tool_report':b['trace'][2]['result'],'final_returned_report':b['result']['messages'][-1]['content']}
 native=[]
 for idx,w in enumerate([a,b]):
  entry={k:w[k] for k in ['phase','pid','exitcode','ok','binding','trace']}
  if idx==0:entry.update(checkpoint_after=checkpoint(w['checkpoint_after']),pending=interrupts(w['pending']))
  else:entry.update(checkpoint_before=checkpoint(w['checkpoint_before']),restored_interrupts=interrupts(w['restored_interrupts']),pending=interrupts(w['pending']))
  native.append(entry)
 messages=[{k:m[k] for k in ['type','content','name','tool_call_id','status','tool_calls'] if k in m} for m in b['result']['messages']]
 l2={**l1,'native_worker_traces':native,'final_messages':messages,'recorded_route_names':{'supervisor':a['models'][0][0]['output']['tool_calls'][0]['name'],'email_agent':a['models'][1][0]['output']['tool_calls'][0]['name']}}
 l3={**l2,'final_local_tables':r['sink'],'controller_side_adapter_trace':r['trace'],'gateway_observation':{k:r[k] for k in ['gateway_alive_after_resume','gateway_exitcode','stop']},'observation_note':"The final read-only local snapshot followed gateway stop and process join. The collector checked agreement of all five JSON tables against the retained SQLite tables. Complete here means all retained local rows for this fixture at that final observation, not any external or unlogged effect. The controller and gateway are trusted.",'snapshot_database_agreement_checked':snapshot_verified,'controller_source_excerpts':source_excerpts}
 events=[e for e in r['sink']['events'] if (e['kind']=='receipt' and e['data']['request']['id']=='resume-execute') or e['data'].get('request_id')=='resume-execute'];assert len(events)==2
 c1={'header':'Ledger excerpt; earlier history and effects table not supplied. Original global sequence values are withheld; display labels below are not source sequence numbers.','action':r['binding']['action'],'arguments':r['binding']['args'],'target_binding':r['binding'],'resumed_tool_report':b['trace'][2]['result'],'final_returned_report':b['result']['messages'][-1]['content'],'resumed_gateway_excerpt':[{'display_label':label,'kind':e['kind'],'data':e['data']} for label,e in zip(['receipt','terminal'],events)]}
 for level,evidence in [('L1',l1),('L2',l2),('L3',l3),('C1',c1)]:
  evidence,mapping=alias_all(copy.deepcopy(evidence));packet={'packet_id':ids[level],'instructions':INSTRUCTIONS,'inference_contract':CONTRACT,'glossary':GLOSSARY,'evidence':evidence,'response_form':FORM};target=OUT/'reviewer_packets'/f'{ids[level]}.json';dump(target,packet)
  field_map=dict(selectors['L1']) if level in ['L1','L2','L3'] else {}
  if level in ['L2','L3']:field_map.update(selectors['L2'])
  if level=='L3':field_map.update(selectors['L3'])
  if level=='C1':field_map.update(selectors['C1'])
  manifest['packets'].append({'field_sources':field_map,'transformations':transformations,'sqlite_queries':['SELECT * FROM '+t for t in ['authority','grants','tickets','events','effects']],'packet_id':ids[level],'level':level,'historical_case':case,'path':str(target.relative_to(OUT)),'sha256':h(target),'aliases':mapping})
manifest['sources'][str((SRC/'runner.py').relative_to(BASE))]=h(SRC/'runner.py')
dump(OUT/'administrator/extraction_manifest.json',manifest)
print(json.dumps({'packets':len(manifest['packets']),'output':str(OUT)},indent=2))
