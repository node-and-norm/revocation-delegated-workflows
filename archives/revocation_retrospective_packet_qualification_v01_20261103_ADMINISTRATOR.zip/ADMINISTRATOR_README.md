# Administrator archive: retrospective evidence-packet qualification

This archive contains answer keys, historical case names, aliases and richer evidence packets. Restrict it to study administration. A blinded reviewer must receive only the individually assigned packet through a separately prepared delivery. Repository access and this complete archive would compromise that separation. No reviewer evaluation has been conducted.

The archive preserves 23 source files exactly as captured on November 3, 2026. They include the initial draft, frozen specification, edge-case rubric, source inspection, specification review decisions, packet builder, validator, extraction manifest, mechanical checks, separate AI-assisted qualification, and eight derivative packets. The final qualification records 62 structural checks, deterministic rebuilding and rejection of a deliberately corrupted snapshot copy with zero packets emitted. Those checks qualify extraction artifacts; they do not estimate reviewer performance.

The freeze record captures an earlier stage and correctly states that packet validation had not occurred then. Later qualification records document subsequent work. Both remain unchanged. Separate AI review does not establish independent human validation.

## Inspect or reproduce extraction

Read the frozen specification and qualification README first. Reproduction requires the historical full pilot archive already preserved in this repository. In a fresh working directory:

1. Extract this administrator archive. It creates revocation_reconstruction_review_20261103/.
2. Create the sibling directory revocation_integration_pilot_20261103/ and extract the repository's revocation_integration_pilot_v03_20261103.zip inside it. Its integration/ and qualification/ folders must sit immediately below that directory.
3. Preserve an untouched copy of the derivative packets and administrator reports before any authorized rerun. The scripts write into qualification_v0.1/.
4. The builder and validator use Python standard-library file/JSON operations and read-only SQLite. They depend on this sibling layout. They never import or execute the historical workflow/checker and make no model calls.

The repository upload verified byte preservation and stored hashes. It did not rerun the extraction or the historical pilot. Any further execution follows the research lead's applicable approval.

Only recorded research artifacts are included. The separate execution-grounded study continues under its own protocol and decisions.
