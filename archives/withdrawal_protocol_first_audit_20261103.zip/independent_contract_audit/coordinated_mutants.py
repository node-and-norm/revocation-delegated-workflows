"""Independently authored coordinated negative controls to avoid snapshot-only rejection."""
import copy,json,pathlib
from check_contract import BASE,database,audit

def load(case):
 p=BASE/'input/measured01'/case/'record.json';return json.loads(p.read_text()),database(p.with_name('sink.sqlite'))
def synchronize(d,b):
 for barrier in d['barriers']:
  cutoff=barrier['committed_events'][-1]['seq'] if barrier['committed_events'] else 0
  barrier['committed_events']=copy.deepcopy([e for e in b['events'] if e['seq']<=cutoff])
  barrier['effects']=copy.deepcopy([e for e in b['effects'] if e['event_seq']<=cutoff])
 d['sink']=copy.deepcopy(b)
results=[]
def run(name,case,change):
 d,b=load(case);change(d,b);synchronize(d,b);r=audit(d,b)
 results.append({'name':name,'case':case,'detected':not r['pass'],'errors':r['errors'],'snapshot_equality_passes':'record snapshot equals actual SQLite tables' not in r['errors']})
for s in ['S0','S2','S5']:
 run('coordinated missing required effect '+s,'direct/'+s,lambda d,b:b['effects'].clear())
run('coordinated missing execute receipt','direct/S1',lambda d,b:b['events'].__setitem__(slice(None),[e for e in b['events'] if not(e['kind']=='receipt' and e['data']['request']['op']=='execute')]))
def late(d,b):
 effect=b['effects'][0];old=effect['event_seq'];effect['event_seq']=10
 for e in b['events']:
  if e['seq']==old:e['seq']=10
 b['events'].sort(key=lambda e:e['seq'])
 # Terminal observation must include the inserted late effect; otherwise a mere cutoff mismatch also rejects.
 d['barriers'][-1]['committed_events']=copy.deepcopy(b['events'])
run('coordinated effect moved after fence','direct/S2',late)
(BASE/'coordinated_mutants.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
