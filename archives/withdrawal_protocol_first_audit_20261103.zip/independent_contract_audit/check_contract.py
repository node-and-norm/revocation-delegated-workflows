#!/usr/bin/env python3
"""Independent protocol-first audit. stdlib only; no study code imports or execution."""
import json, sqlite3, pathlib, hashlib, copy
BASE=pathlib.Path(__file__).resolve().parent
REV={'outcome':'revocation','root':'rootR','withdrawn_epoch':7,'new_epoch':8}
TERMINAL={'INSTALLED_CONFIRMED','UNCONFIRMED_AT_OBSERVATION_END','INVALID_RESPONSE'}
def database(p):
    with sqlite3.connect(p.resolve().as_uri()+'?mode=ro&immutable=1',uri=True) as c:
        c.row_factory=sqlite3.Row
        out={t:[dict(r) for r in c.execute('SELECT * FROM '+t)] for t in ['authority','grants','tickets','events','effects']}
    for e in out['events']: e['data']=json.loads(e['data'])
    out['events'].sort(key=lambda e:e['seq'])
    return out

def audit(d, db):
    errors=[]; checks=[]
    def ck(ok,label):
        checks.append(label)
        if not ok: errors.append(label)
    s=d['schedule']; path=d['path'];ev=db['events'];effects=db['effects']
    ck(d['sink']==db,'record snapshot equals actual SQLite tables')
    ck(not d['prior_effect'],'no declared prior effect')
    # Evidence-derived caller replay, before consulting schedule expectations.
    state='IDLE';rid=None;completions=[]
    allowed={'issue':{'kind','request_id'},'accepted_volatile':{'kind','request_id'},'observation_end':{'kind'},'completion':{'kind','request_id','root','withdrawn_epoch','new_epoch','status','scope','gateway_response'}}
    for i,t in enumerate(d['caller_trace']):
        m=t['input'];k=m.get('kind');ck(t['before']==state,f'caller before {i}')
        ck(k in allowed and set(m)<=allowed.get(k,set()),f'caller input boundary {i}')
        if state in TERMINAL: pass
        elif k=='issue':
            ck(state=='IDLE' and bool(m.get('request_id')),f'one valid issue {i}');rid=m.get('request_id');state='PENDING'
        elif k=='accepted_volatile':
            ck(state=='PENDING' and m.get('request_id')==rid,f'acceptance correlation {i}')
        elif k=='observation_end':
            if state=='PENDING':state='UNCONFIRMED_AT_OBSERVATION_END'
        elif k=='completion':
            completions.append(m)
            valid=(state=='PENDING' and m.get('request_id')==rid and m.get('root')=='rootR' and m.get('withdrawn_epoch')==7 and m.get('new_epoch')==8 and m.get('status')=='installed' and m.get('scope')=='single_local_sink' and m.get('gateway_response')==REV)
            state='INSTALLED_CONFIRMED' if valid else 'INVALID_RESPONSE'
        else:state='INVALID_RESPONSE'
        ck(t['after']==state,f'caller after {i}')
    ck(d['caller_state']==state,'caller final evidence-derived state')
    # Match committed receipts and outcomes, not pipe sends or stored verdicts.
    receipts=[e for e in ev if e['kind']=='receipt'];rs={}
    for r in receipts:
        req=r['data']['request'];key=req['id'];ck(key not in rs,'unique receipt '+key);rs[key]=r
    outcomes=[e for e in ev if e['kind'] not in ['bootstrap','receipt']]
    for o in outcomes:
        key=o['data'].get('request_id');r=rs.get(key)
        ck(r is not None and r['seq']<o['seq'],'matched prior receipt '+str(key))
    executes=[r for r in receipts if r['data']['request'].get('op')=='execute']
    revs=[e for e in ev if e['kind']=='revocation']; rev_receipts=[r for r in receipts if r['data']['request'].get('op')=='revoke']
    ck(len(executes)==1,'exactly one committed execute receipt');ck(len(revs)<=1 and len(rev_receipts)==len(revs),'at most one complete revocation pair')
    ex=executes[0] if executes else None
    exouts=[o for o in outcomes if ex and o['data'].get('request_id')==ex['data']['request']['id']]
    ck(len(exouts)==1,'exactly one execute terminal outcome')
    result=exouts[0]['data']['result'] if exouts else None
    ck(result==d['execute_response'],'execute response equals SQLite outcome')
    if revs:
        ck(revs[0]['data']['result']==REV,'exact revocation response')
        ck(revs[0]['data']['request_id']==rid,'revoke correlated to caller request')
    ck(db['authority']==[{'root':'rootR','epoch':8 if revs else 7,'active':0 if revs else 1}],'authority agrees with fence evidence')
    effect_events=[e for e in ev if e['kind']=='effect']
    ck(len(effect_events)==len(effects),'effect table and event counts agree')
    for e in effects:
        match=[x for x in effect_events if x['seq']==e['event_seq']]
        ck(len(match)==1,'effect has exact event link')
        if match:ck(match[0]['data']['result']==dict(outcome='effect',**{k:v for k,v in e.items() if k!='event_seq'}),'effect row contents agree with event')
        ck(not revs or e['event_seq']<revs[0]['seq'],'no committed post-fence effect')
    ck(len(db['grants'])==2 and len(db['tickets'])==1,'one child grant and ticket')
    for typ,key in [('grant','grant'),('admission','admission')]:
        a=[o for o in outcomes if o['kind']==typ];ck(len(a)==1 and a[0]['data']['result']==d[key],typ+' actual result correlation')
    # Privileged snapshot boundaries must be exact prefixes of persisted database.
    bs=d['barriers'];names=[b['name'] for b in bs];prev=0
    for b in bs:
        n=len(b['committed_events']);ck(prev<=n and b['committed_events']==ev[:n],'committed prefix '+b['name']);prev=n
        cutoff=b['committed_events'][-1]['seq'] if n else 0
        ck(b['effects']==[e for e in effects if e['event_seq']<=cutoff],'effect snapshot '+b['name'])
    ck(bool(bs) and bs[-1]['name']=='terminal_observation' and bs[-1]['committed_events']==ev and bs[-1]['effects']==effects and bs[-1]['caller_state']==state,'terminal observation exactly matches database and caller')
    bmap={b['name']:b for b in bs}
    if 'fence_installed' in bmap:ck(bool(revs) and revs[0] in bmap['fence_installed']['committed_events'],'fence barrier contains matched committed revocation')
    if 'execute_terminal' in bmap:ck(bool(exouts) and exouts[0] in bmap['execute_terminal']['committed_events'],'execute barrier contains committed terminal')
    # Relay envelope provenance, independently from caller interpretation.
    relay=d['relay_trace'];recv=[x['response'] for x in relay if x['event']=='gateway_response_received'];fwd=[x['message'] for x in relay if x['event']=='completion_forwarded']
    ck(fwd==completions,'forwarded envelopes equal caller-visible completions')
    ck(recv==[r['data']['result'] for r in revs],'relay response equals actual committed revocation')
    if fwd:ck([x['event'] for x in relay].index('gateway_response_received')<[x['event'] for x in relay].index('completion_forwarded'),'receive precedes completion forwarding')
    # Frozen schedule contracts, kept separate from evidence-derived state/outcome.
    required={'S0':['execute_terminal','terminal_observation'],'S1':['accepted','fence_installed','completion_observed','execute_terminal','terminal_observation'],'S2':['accepted','execute_terminal','fence_installed','completion_observed','terminal_observation'],'S3':['accepted','fence_installed','execute_terminal','completion_observed','terminal_observation'],'S4':['accepted','fence_installed','execute_terminal','terminal_observation'],'S5':['accepted','execute_terminal','terminal_observation']}
    ck(names==required[s],'schedule barrier order')
    ck(len(effects)==(1 if s in ['S0','S2','S5'] else 0),'schedule required effect count')
    ck(len(revs)==(0 if s in ['S0','S5'] else 1),'schedule required fence count')
    expected_state='IDLE' if s=='S0' else 'UNCONFIRMED_AT_OBSERVATION_END' if s in ['S4','S5'] else 'INSTALLED_CONFIRMED'
    ck(state==expected_state,'schedule caller state')
    if exouts:ck(result.get('outcome')==('effect' if s in ['S0','S2','S5'] else 'denied') and (s in ['S0','S2','S5'] or result=={'outcome':'denied','reason':'revoked'}),'schedule exact execute classification')
    if ex and revs:ck((exouts[0]['seq']<revs[0]['seq']) if s=='S2' else (revs[0]['seq']<ex['seq']),'schedule committed order')
    if s!='S0':ck(bmap.get('execute_terminal',{}).get('caller_state')==('INSTALLED_CONFIRMED' if s=='S1' else 'PENDING'),'caller knowledge at execution')
    # Exact propagation through resumed framework outputs, not worker ok flags.
    traces=d['adapter_trace'] if path=='direct' else [t for w in d['workers'] for t in w['trace']]
    replies=[t for t in traces if t.get('kind')=='tool_response']
    ck(len(replies)==1 and replies[0]['result']==result and ex is not None and replies[0]['request']==ex['data']['request'],'adapter response and request match SQLite')
    if path=='framework':
        workers=d['workers'];ck(len(workers)==2,'pause and resume worker records')
        if len(workers)==2:
            pause,resume=workers;ck(pause['pid']!=resume['pid'],'distinct worker processes')
            ck(pause['checkpoint_after']==resume['checkpoint_before'],'checkpoint reference continuity')
            ck(bool(pause['pending']) and bool(resume['restored_interrupts']) and not resume['pending'],'interrupt persisted then consumed')
            ms=resume.get('result',{}).get('messages',[]);tool=[m for m in ms if m.get('type')=='tool'];ais=[m for m in ms if m.get('type')=='ai' and not m.get('tool_calls')]
            for label,messages in [('tool',tool),('final assistant',ais)]:
                decoded=[]
                for m in messages:
                    try:decoded.append(json.loads(m['content']))
                    except (ValueError,TypeError):pass
                ck(result in decoded,'framework '+label+' exact outcome')
    return {'case':path+'/'+s,'pass':not errors,'checks':len(checks),'errors':errors,'derived_state':state,'effect_count':len(effects),'revocation_count':len(revs)}

def main():
    results=[];inputs={}
    for p in sorted((BASE/'input/measured01').glob('*/*/record.json')):
        d=json.loads(p.read_text());db=database(p.with_name('sink.sqlite'));inputs[d['path']+'/'+d['schedule']]=(d,db);results.append(audit(d,db))
    mutants=[]
    def mutant(name,case,change):
        d,b=copy.deepcopy(inputs[case]);change(d,b);r=audit(d,b);mutants.append({'name':name,'case':case,'detected':not r['pass'],'errors':r['errors']})
    mutant('premature confirmation on acceptance','direct/S4',lambda d,b:d['caller_trace'][1].update(after='INSTALLED_CONFIRMED'))
    for field,value in [('root','wrong'),('withdrawn_epoch',6),('new_epoch',9),('request_id','unknown'),('status','accepted'),('gateway_response',{})]:
        mutant('invalid completion '+field,'direct/S1',lambda d,b,f=field,v=value:d['caller_trace'][2]['input'].update({f:v}))
    mutant('privileged caller input','direct/S1',lambda d,b:d['caller_trace'][1]['input'].update(sink_database='private'))
    mutant('missing execute receipt','direct/S1',lambda d,b:b['events'].__setitem__(slice(None),[e for e in b['events'] if not(e['kind']=='receipt' and e['data']['request']['op']=='execute')]))
    for s in ['S0','S2','S5']:mutant('missing required effect '+s,'direct/'+s,lambda d,b:b['effects'].clear())
    mutant('post-fence inserted effect','direct/S1',lambda d,b:b['effects'].append({'event_seq':10,'effect_key':'bad','payload':'bad','root':'rootR','epoch':7}))
    mutant('dropped framework outputs','framework/S1',lambda d,b:d['workers'][1]['result'].update(messages=[]))
    mutant('mismatched observation cutoff','direct/S2',lambda d,b:d['barriers'][-1]['committed_events'].pop())
    report={'implementation':'protocol-first stdlib independent checker; no original source code read/imported','cases':results,'all_cases_pass':len(results)==12 and all(r['pass'] for r in results),'mutants':mutants,'all_mutants_detected':all(m['detected'] for m in mutants)}
    (BASE/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
