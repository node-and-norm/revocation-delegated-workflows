"""Protocol validity and independent raw worker-record consistency checks, added after baseline."""
import json
from check_contract import BASE,database
out=[]
for p in sorted((BASE/'input/measured01').glob('*/*/record.json')):
 d=json.loads(p.read_text());b=database(p.with_name('sink.sqlite'));a=d['admission'];g=d['grant'];checks={}
 children=[r for r in b['grants'] if r['token']==a['grant']]
 tickets=[r for r in b['tickets'] if r['token']==a['ticket']]
 parents=[r for r in b['grants'] if r['token']==g['parent_grant']]
 checks['one child and matching parent']=len(children)==len(parents)==1 and children[0]['root']==parents[0]['root']=='rootR' and children[0]['epoch']==parents[0]['epoch']==7 and parents[0]['can_delegate']==1
 checks['admitted ticket binds child grant']=len(tickets)==1 and tickets[0]['grant_token']==g['grant']==a['grant'] and tickets[0]['owner']==g['owner'] and tickets[0]['scope']==g['scope']==a['scope']
 ex=[e['data']['request'] for e in b['events'] if e['kind']=='receipt' and e['data']['request']['op']=='execute'][0]
 checks['execute uses admitted ticket and owner']=ex['ticket']==a['ticket'] and ex['grant']==a['grant'] and ex['claim']==g['owner'] and ex['scope']==a['scope']
 checks['single child grant matches row']=children[0]['token']==g['grant'] and children[0]['owner']==g['owner'] and children[0]['scope']==g['scope']
 if d['path']=='framework':
  for phase,w in zip(['pause','resume'],d['workers']):checks['raw worker '+phase+' exactly equals embedded record']=json.loads(p.with_name('worker_'+phase+'.json').read_text())==w
  checks['pause has no protected execution'] = not any(t.get('kind')=='tool_response' for t in d['workers'][0]['trace'])
 checks['caller input schedule pattern']= [t['input']['kind'] for t in d['caller_trace']] == ([] if d['schedule']=='S0' else ['issue','accepted_volatile','observation_end' if d['schedule'] in ['S4','S5'] else 'completion'])
 out.append({'case':d['path']+'/'+d['schedule'],'checks':checks,'pass':all(checks.values())})
(BASE/'supplemental_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
